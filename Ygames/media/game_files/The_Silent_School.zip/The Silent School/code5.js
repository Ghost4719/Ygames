gdjs.WonCode = {};
gdjs.WonCode.localVariables = [];
gdjs.WonCode.GDE_9595buttonObjects2_1final = [];

gdjs.WonCode.GDE_9595buttonObjects3_1final = [];

gdjs.WonCode.GDJoystickObjects2_1final = [];

gdjs.WonCode.GDNewSpriteObjects1= [];
gdjs.WonCode.GDNewSpriteObjects2= [];
gdjs.WonCode.GDNewSpriteObjects3= [];
gdjs.WonCode.GDNewSpriteObjects4= [];
gdjs.WonCode.GDtext_9595boxObjects1= [];
gdjs.WonCode.GDtext_9595boxObjects2= [];
gdjs.WonCode.GDtext_9595boxObjects3= [];
gdjs.WonCode.GDtext_9595boxObjects4= [];
gdjs.WonCode.GDtipObjects1= [];
gdjs.WonCode.GDtipObjects2= [];
gdjs.WonCode.GDtipObjects3= [];
gdjs.WonCode.GDtipObjects4= [];
gdjs.WonCode.GDNameObjects1= [];
gdjs.WonCode.GDNameObjects2= [];
gdjs.WonCode.GDNameObjects3= [];
gdjs.WonCode.GDNameObjects4= [];
gdjs.WonCode.GDDialogeObjects1= [];
gdjs.WonCode.GDDialogeObjects2= [];
gdjs.WonCode.GDDialogeObjects3= [];
gdjs.WonCode.GDDialogeObjects4= [];
gdjs.WonCode.GDcharecters2Objects1= [];
gdjs.WonCode.GDcharecters2Objects2= [];
gdjs.WonCode.GDcharecters2Objects3= [];
gdjs.WonCode.GDcharecters2Objects4= [];
gdjs.WonCode.GDfireObjects1= [];
gdjs.WonCode.GDfireObjects2= [];
gdjs.WonCode.GDfireObjects3= [];
gdjs.WonCode.GDfireObjects4= [];
gdjs.WonCode.GDPixelFlameObjects1= [];
gdjs.WonCode.GDPixelFlameObjects2= [];
gdjs.WonCode.GDPixelFlameObjects3= [];
gdjs.WonCode.GDPixelFlameObjects4= [];
gdjs.WonCode.GDPixelSmokeObjects1= [];
gdjs.WonCode.GDPixelSmokeObjects2= [];
gdjs.WonCode.GDPixelSmokeObjects3= [];
gdjs.WonCode.GDPixelSmokeObjects4= [];
gdjs.WonCode.GDRoomsObjects1= [];
gdjs.WonCode.GDRoomsObjects2= [];
gdjs.WonCode.GDRoomsObjects3= [];
gdjs.WonCode.GDRoomsObjects4= [];
gdjs.WonCode.GDWallObjects1= [];
gdjs.WonCode.GDWallObjects2= [];
gdjs.WonCode.GDWallObjects3= [];
gdjs.WonCode.GDWallObjects4= [];
gdjs.WonCode.GDfloorObjects1= [];
gdjs.WonCode.GDfloorObjects2= [];
gdjs.WonCode.GDfloorObjects3= [];
gdjs.WonCode.GDfloorObjects4= [];
gdjs.WonCode.GDdoorsObjects1= [];
gdjs.WonCode.GDdoorsObjects2= [];
gdjs.WonCode.GDdoorsObjects3= [];
gdjs.WonCode.GDdoorsObjects4= [];
gdjs.WonCode.GDobjectsObjects1= [];
gdjs.WonCode.GDobjectsObjects2= [];
gdjs.WonCode.GDobjectsObjects3= [];
gdjs.WonCode.GDobjectsObjects4= [];
gdjs.WonCode.GDwallobjectObjects1= [];
gdjs.WonCode.GDwallobjectObjects2= [];
gdjs.WonCode.GDwallobjectObjects3= [];
gdjs.WonCode.GDwallobjectObjects4= [];
gdjs.WonCode.GDwindowObjects1= [];
gdjs.WonCode.GDwindowObjects2= [];
gdjs.WonCode.GDwindowObjects3= [];
gdjs.WonCode.GDwindowObjects4= [];
gdjs.WonCode.GDrailObjects1= [];
gdjs.WonCode.GDrailObjects2= [];
gdjs.WonCode.GDrailObjects3= [];
gdjs.WonCode.GDrailObjects4= [];
gdjs.WonCode.GDplayerObjects1= [];
gdjs.WonCode.GDplayerObjects2= [];
gdjs.WonCode.GDplayerObjects3= [];
gdjs.WonCode.GDplayerObjects4= [];
gdjs.WonCode.GDhitboxObjects1= [];
gdjs.WonCode.GDhitboxObjects2= [];
gdjs.WonCode.GDhitboxObjects3= [];
gdjs.WonCode.GDhitboxObjects4= [];
gdjs.WonCode.GDMainlightObjects1= [];
gdjs.WonCode.GDMainlightObjects2= [];
gdjs.WonCode.GDMainlightObjects3= [];
gdjs.WonCode.GDMainlightObjects4= [];
gdjs.WonCode.GDsmalllightObjects1= [];
gdjs.WonCode.GDsmalllightObjects2= [];
gdjs.WonCode.GDsmalllightObjects3= [];
gdjs.WonCode.GDsmalllightObjects4= [];
gdjs.WonCode.GDNewBitmapTextObjects1= [];
gdjs.WonCode.GDNewBitmapTextObjects2= [];
gdjs.WonCode.GDNewBitmapTextObjects3= [];
gdjs.WonCode.GDNewBitmapTextObjects4= [];
gdjs.WonCode.GDtask_9595barObjects1= [];
gdjs.WonCode.GDtask_9595barObjects2= [];
gdjs.WonCode.GDtask_9595barObjects3= [];
gdjs.WonCode.GDtask_9595barObjects4= [];
gdjs.WonCode.GDcharectersObjects1= [];
gdjs.WonCode.GDcharectersObjects2= [];
gdjs.WonCode.GDcharectersObjects3= [];
gdjs.WonCode.GDcharectersObjects4= [];
gdjs.WonCode.GDcharecters22Objects1= [];
gdjs.WonCode.GDcharecters22Objects2= [];
gdjs.WonCode.GDcharecters22Objects3= [];
gdjs.WonCode.GDcharecters22Objects4= [];
gdjs.WonCode.GDPauseObjects1= [];
gdjs.WonCode.GDPauseObjects2= [];
gdjs.WonCode.GDPauseObjects3= [];
gdjs.WonCode.GDPauseObjects4= [];
gdjs.WonCode.GDresumeObjects1= [];
gdjs.WonCode.GDresumeObjects2= [];
gdjs.WonCode.GDresumeObjects3= [];
gdjs.WonCode.GDresumeObjects4= [];
gdjs.WonCode.GDQuit_95952Objects1= [];
gdjs.WonCode.GDQuit_95952Objects2= [];
gdjs.WonCode.GDQuit_95952Objects3= [];
gdjs.WonCode.GDQuit_95952Objects4= [];
gdjs.WonCode.GDpause_9595menuObjects1= [];
gdjs.WonCode.GDpause_9595menuObjects2= [];
gdjs.WonCode.GDpause_9595menuObjects3= [];
gdjs.WonCode.GDpause_9595menuObjects4= [];
gdjs.WonCode.GDHimaObjects1= [];
gdjs.WonCode.GDHimaObjects2= [];
gdjs.WonCode.GDHimaObjects3= [];
gdjs.WonCode.GDHimaObjects4= [];
gdjs.WonCode.GDLayaObjects1= [];
gdjs.WonCode.GDLayaObjects2= [];
gdjs.WonCode.GDLayaObjects3= [];
gdjs.WonCode.GDLayaObjects4= [];
gdjs.WonCode.GDJoystickObjects1= [];
gdjs.WonCode.GDJoystickObjects2= [];
gdjs.WonCode.GDJoystickObjects3= [];
gdjs.WonCode.GDJoystickObjects4= [];
gdjs.WonCode.GDE_9595buttonObjects1= [];
gdjs.WonCode.GDE_9595buttonObjects2= [];
gdjs.WonCode.GDE_9595buttonObjects3= [];
gdjs.WonCode.GDE_9595buttonObjects4= [];


gdjs.WonCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.WonCode.GDplayerObjects2, gdjs.WonCode.GDplayerObjects3);

{for(var i = 0, len = gdjs.WonCode.GDplayerObjects3.length ;i < len;++i) {
    gdjs.WonCode.GDplayerObjects3[i].getBehavior("Flippable").flipX(false);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if (isConditionTrue_0) {
/* Reuse gdjs.WonCode.GDplayerObjects2 */
{for(var i = 0, len = gdjs.WonCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.WonCode.GDplayerObjects2[i].getBehavior("Flippable").flipX(true);
}
}}

}


};gdjs.WonCode.mapOfGDgdjs_9546WonCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.WonCode.GDplayerObjects2});
gdjs.WonCode.mapOfGDgdjs_9546WonCode_9546GDWallObjects2Objects = Hashtable.newFrom({"Wall": gdjs.WonCode.GDWallObjects2});
gdjs.WonCode.mapOfGDgdjs_9546WonCode_9546GDWallObjects2Objects = Hashtable.newFrom({"Wall": gdjs.WonCode.GDWallObjects2});
gdjs.WonCode.mapOfGDgdjs_9546WonCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.WonCode.GDplayerObjects2});
gdjs.WonCode.mapOfGDgdjs_9546WonCode_9546GDhitboxObjects2Objects = Hashtable.newFrom({"hitbox": gdjs.WonCode.GDhitboxObjects2});
gdjs.WonCode.mapOfGDgdjs_9546WonCode_9546GDhitboxObjects2Objects = Hashtable.newFrom({"hitbox": gdjs.WonCode.GDhitboxObjects2});
gdjs.WonCode.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.WonCode.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.WonCode.GDplayerObjects2.length;i<l;++i) {
    if ( gdjs.WonCode.GDplayerObjects2[i].getBehavior("TopDownMovement").isMoving() ) {
        isConditionTrue_0 = true;
        gdjs.WonCode.GDplayerObjects2[k] = gdjs.WonCode.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.WonCode.GDplayerObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.WonCode.GDplayerObjects2 */
{for(var i = 0, len = gdjs.WonCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.WonCode.GDplayerObjects2[i].getBehavior("Animation").setAnimationName("player-walk");
}
}
{ //Subevents
gdjs.WonCode.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.WonCode.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.WonCode.GDplayerObjects2.length;i<l;++i) {
    if ( !(gdjs.WonCode.GDplayerObjects2[i].getBehavior("TopDownMovement").isMoving()) ) {
        isConditionTrue_0 = true;
        gdjs.WonCode.GDplayerObjects2[k] = gdjs.WonCode.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.WonCode.GDplayerObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.WonCode.GDplayerObjects2 */
{for(var i = 0, len = gdjs.WonCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.WonCode.GDplayerObjects2[i].getBehavior("Animation").setAnimationName("player");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Wall"), gdjs.WonCode.GDWallObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.WonCode.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.WonCode.mapOfGDgdjs_9546WonCode_9546GDplayerObjects2Objects, gdjs.WonCode.mapOfGDgdjs_9546WonCode_9546GDWallObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.WonCode.GDWallObjects2 */
/* Reuse gdjs.WonCode.GDplayerObjects2 */
{for(var i = 0, len = gdjs.WonCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.WonCode.GDplayerObjects2[i].separateFromObjectsList(gdjs.WonCode.mapOfGDgdjs_9546WonCode_9546GDWallObjects2Objects, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("hitbox"), gdjs.WonCode.GDhitboxObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.WonCode.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.WonCode.mapOfGDgdjs_9546WonCode_9546GDplayerObjects2Objects, gdjs.WonCode.mapOfGDgdjs_9546WonCode_9546GDhitboxObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.WonCode.GDhitboxObjects2 */
/* Reuse gdjs.WonCode.GDplayerObjects2 */
{for(var i = 0, len = gdjs.WonCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.WonCode.GDplayerObjects2[i].separateFromObjectsList(gdjs.WonCode.mapOfGDgdjs_9546WonCode_9546GDhitboxObjects2Objects, false);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.WonCode.GDplayerObjects2);
{for(var i = 0, len = gdjs.WonCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.WonCode.GDplayerObjects2[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "s");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.WonCode.GDplayerObjects2);
{for(var i = 0, len = gdjs.WonCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.WonCode.GDplayerObjects2[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.WonCode.GDplayerObjects2);
{for(var i = 0, len = gdjs.WonCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.WonCode.GDplayerObjects2[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.WonCode.GDplayerObjects1);
{for(var i = 0, len = gdjs.WonCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.WonCode.GDplayerObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


};gdjs.WonCode.mapOfGDgdjs_9546WonCode_9546GDplayerObjects3Objects = Hashtable.newFrom({"player": gdjs.WonCode.GDplayerObjects3});
gdjs.WonCode.mapOfGDgdjs_9546WonCode_9546GDcharectersObjects3Objects = Hashtable.newFrom({"charecters": gdjs.WonCode.GDcharectersObjects3});
gdjs.WonCode.mapOfGDgdjs_9546WonCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.WonCode.GDplayerObjects2});
gdjs.WonCode.mapOfGDgdjs_9546WonCode_9546GDcharectersObjects2Objects = Hashtable.newFrom({"charecters": gdjs.WonCode.GDcharectersObjects2});
gdjs.WonCode.eventsList2 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("charecters"), gdjs.WonCode.GDcharectersObjects3);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.WonCode.GDplayerObjects3);
gdjs.WonCode.GDE_9595buttonObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.WonCode.GDE_9595buttonObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.WonCode.GDE_9595buttonObjects4);
for (var i = 0, k = 0, l = gdjs.WonCode.GDE_9595buttonObjects4.length;i<l;++i) {
    if ( gdjs.WonCode.GDE_9595buttonObjects4[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.WonCode.GDE_9595buttonObjects4[k] = gdjs.WonCode.GDE_9595buttonObjects4[i];
        ++k;
    }
}
gdjs.WonCode.GDE_9595buttonObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.WonCode.GDE_9595buttonObjects4.length; j < jLen ; ++j) {
        if ( gdjs.WonCode.GDE_9595buttonObjects3_1final.indexOf(gdjs.WonCode.GDE_9595buttonObjects4[j]) === -1 )
            gdjs.WonCode.GDE_9595buttonObjects3_1final.push(gdjs.WonCode.GDE_9595buttonObjects4[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.WonCode.GDE_9595buttonObjects3_1final, gdjs.WonCode.GDE_9595buttonObjects3);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.WonCode.mapOfGDgdjs_9546WonCode_9546GDplayerObjects3Objects, gdjs.WonCode.mapOfGDgdjs_9546WonCode_9546GDcharectersObjects3Objects, 80, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.WonCode.GDcharectersObjects3.length;i<l;++i) {
    if ( gdjs.WonCode.GDcharectersObjects3[i].getBehavior("Animation").getAnimationName() == "oldman" ) {
        isConditionTrue_0 = true;
        gdjs.WonCode.GDcharectersObjects3[k] = gdjs.WonCode.GDcharectersObjects3[i];
        ++k;
    }
}
gdjs.WonCode.GDcharectersObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(18)) == 2;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "conversation"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(30223444);
}
}
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Name"), gdjs.WonCode.GDNameObjects3);
gdjs.copyArray(runtimeScene.getObjects("charecters2"), gdjs.WonCode.GDcharecters2Objects3);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollspeed");
}{gdjs.dialogueTree.startFrom("End");
}{for(var i = 0, len = gdjs.WonCode.GDcharecters2Objects3.length ;i < len;++i) {
    gdjs.WonCode.GDcharecters2Objects3[i].getBehavior("Animation").setAnimationName("oldman");
}
}{for(var i = 0, len = gdjs.WonCode.GDNameObjects3.length ;i < len;++i) {
    gdjs.WonCode.GDNameObjects3[i].getBehavior("Text").setText("Cayo");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("charecters"), gdjs.WonCode.GDcharectersObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.WonCode.GDplayerObjects2);
gdjs.WonCode.GDE_9595buttonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.WonCode.GDE_9595buttonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.WonCode.GDE_9595buttonObjects3);
for (var i = 0, k = 0, l = gdjs.WonCode.GDE_9595buttonObjects3.length;i<l;++i) {
    if ( gdjs.WonCode.GDE_9595buttonObjects3[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.WonCode.GDE_9595buttonObjects3[k] = gdjs.WonCode.GDE_9595buttonObjects3[i];
        ++k;
    }
}
gdjs.WonCode.GDE_9595buttonObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.WonCode.GDE_9595buttonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.WonCode.GDE_9595buttonObjects2_1final.indexOf(gdjs.WonCode.GDE_9595buttonObjects3[j]) === -1 )
            gdjs.WonCode.GDE_9595buttonObjects2_1final.push(gdjs.WonCode.GDE_9595buttonObjects3[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.WonCode.GDE_9595buttonObjects2_1final, gdjs.WonCode.GDE_9595buttonObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.WonCode.mapOfGDgdjs_9546WonCode_9546GDplayerObjects2Objects, gdjs.WonCode.mapOfGDgdjs_9546WonCode_9546GDcharectersObjects2Objects, 80, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.WonCode.GDcharectersObjects2.length;i<l;++i) {
    if ( gdjs.WonCode.GDcharectersObjects2[i].getBehavior("Animation").getAnimationName() == "oldman" ) {
        isConditionTrue_0 = true;
        gdjs.WonCode.GDcharectersObjects2[k] = gdjs.WonCode.GDcharectersObjects2[i];
        ++k;
    }
}
gdjs.WonCode.GDcharectersObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(18)) == 4;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "conversation"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(30226372);
}
}
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Name"), gdjs.WonCode.GDNameObjects2);
gdjs.copyArray(runtimeScene.getObjects("charecters2"), gdjs.WonCode.GDcharecters2Objects2);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollspeed");
}{gdjs.dialogueTree.startFrom("Secret");
}{for(var i = 0, len = gdjs.WonCode.GDcharecters2Objects2.length ;i < len;++i) {
    gdjs.WonCode.GDcharecters2Objects2[i].getBehavior("Animation").setAnimationName("oldman");
}
}{for(var i = 0, len = gdjs.WonCode.GDNameObjects2.length ;i < len;++i) {
    gdjs.WonCode.GDNameObjects2[i].getBehavior("Text").setText("Cayo");
}
}}

}


};gdjs.WonCode.mapOfGDgdjs_9546WonCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.WonCode.GDplayerObjects2});
gdjs.WonCode.mapOfGDgdjs_9546WonCode_9546GDcharectersObjects2Objects = Hashtable.newFrom({"charecters": gdjs.WonCode.GDcharectersObjects2});
gdjs.WonCode.mapOfGDgdjs_9546WonCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.WonCode.GDplayerObjects2});
gdjs.WonCode.mapOfGDgdjs_9546WonCode_9546GDcharectersObjects2Objects = Hashtable.newFrom({"charecters": gdjs.WonCode.GDcharectersObjects2});
gdjs.WonCode.asyncCallback30232652 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.WonCode.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Main Menu", false);
}gdjs.WonCode.localVariables.length = 0;
}
gdjs.WonCode.eventsList3 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.WonCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.WonCode.asyncCallback30232652(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.WonCode.eventsList4 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "scrollspeed") >= runtimeScene.getGame().getVariables().getFromIndex(2).getAsNumber();
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.hasClippedScrollingCompleted());
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "New sound effect", false, 50, gdjs.random(2));
}{gdjs.dialogueTree.scrollClippedText();
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollspeed");
}}

}


{

gdjs.WonCode.GDE_9595buttonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.WonCode.GDE_9595buttonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.WonCode.GDE_9595buttonObjects3);
for (var i = 0, k = 0, l = gdjs.WonCode.GDE_9595buttonObjects3.length;i<l;++i) {
    if ( gdjs.WonCode.GDE_9595buttonObjects3[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.WonCode.GDE_9595buttonObjects3[k] = gdjs.WonCode.GDE_9595buttonObjects3[i];
        ++k;
    }
}
gdjs.WonCode.GDE_9595buttonObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.WonCode.GDE_9595buttonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.WonCode.GDE_9595buttonObjects2_1final.indexOf(gdjs.WonCode.GDE_9595buttonObjects3[j]) === -1 )
            gdjs.WonCode.GDE_9595buttonObjects2_1final.push(gdjs.WonCode.GDE_9595buttonObjects3[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.WonCode.GDE_9595buttonObjects2_1final, gdjs.WonCode.GDE_9595buttonObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.dialogueTree.hasClippedScrollingCompleted();
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(30236060);
}
}
}
if (isConditionTrue_0) {
{gdjs.dialogueTree.goToNextDialogueLine();
}}

}


{

gdjs.WonCode.GDE_9595buttonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.WonCode.GDE_9595buttonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.WonCode.GDE_9595buttonObjects3);
for (var i = 0, k = 0, l = gdjs.WonCode.GDE_9595buttonObjects3.length;i<l;++i) {
    if ( gdjs.WonCode.GDE_9595buttonObjects3[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.WonCode.GDE_9595buttonObjects3[k] = gdjs.WonCode.GDE_9595buttonObjects3[i];
        ++k;
    }
}
gdjs.WonCode.GDE_9595buttonObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.WonCode.GDE_9595buttonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.WonCode.GDE_9595buttonObjects2_1final.indexOf(gdjs.WonCode.GDE_9595buttonObjects3[j]) === -1 )
            gdjs.WonCode.GDE_9595buttonObjects2_1final.push(gdjs.WonCode.GDE_9595buttonObjects3[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.WonCode.GDE_9595buttonObjects2_1final, gdjs.WonCode.GDE_9595buttonObjects2);
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(2).setNumber(0.01);
}}

}


{

gdjs.WonCode.GDE_9595buttonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.WonCode.GDE_9595buttonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.WonCode.GDE_9595buttonObjects3);
for (var i = 0, k = 0, l = gdjs.WonCode.GDE_9595buttonObjects3.length;i<l;++i) {
    if ( !(gdjs.WonCode.GDE_9595buttonObjects3[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_1 = true;
        gdjs.WonCode.GDE_9595buttonObjects3[k] = gdjs.WonCode.GDE_9595buttonObjects3[i];
        ++k;
    }
}
gdjs.WonCode.GDE_9595buttonObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.WonCode.GDE_9595buttonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.WonCode.GDE_9595buttonObjects2_1final.indexOf(gdjs.WonCode.GDE_9595buttonObjects3[j]) === -1 )
            gdjs.WonCode.GDE_9595buttonObjects2_1final.push(gdjs.WonCode.GDE_9595buttonObjects3[j]);
    }
}
}
{
isConditionTrue_1 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "e"));
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.WonCode.GDE_9595buttonObjects2_1final, gdjs.WonCode.GDE_9595buttonObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(30238260);
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(2).setNumber(0.05);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Space");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(30238676);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.WonCode.GDDialogeObjects1 */
{for(var i = 0, len = gdjs.WonCode.GDDialogeObjects1.length ;i < len;++i) {
    gdjs.WonCode.GDDialogeObjects1[i].getBehavior("Text").setText(gdjs.dialogueTree.getLineText());
}
}{gdjs.dialogueTree.goToNextDialogueLine();
}}

}


};gdjs.WonCode.eventsList5 = function(runtimeScene) {

{


gdjs.WonCode.eventsList2(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("charecters"), gdjs.WonCode.GDcharectersObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.WonCode.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.WonCode.mapOfGDgdjs_9546WonCode_9546GDplayerObjects2Objects, gdjs.WonCode.mapOfGDgdjs_9546WonCode_9546GDcharectersObjects2Objects, 80, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(30227740);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause"));
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewBitmapText"), gdjs.WonCode.GDNewBitmapTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("task_bar"), gdjs.WonCode.GDtask_9595barObjects2);
{for(var i = 0, len = gdjs.WonCode.GDtask_9595barObjects2.length ;i < len;++i) {
    gdjs.WonCode.GDtask_9595barObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.WonCode.GDNewBitmapTextObjects2.length ;i < len;++i) {
    gdjs.WonCode.GDNewBitmapTextObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.WonCode.GDNewBitmapTextObjects2.length ;i < len;++i) {
    gdjs.WonCode.GDNewBitmapTextObjects2[i].getBehavior("Text").setText("talk?");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("charecters"), gdjs.WonCode.GDcharectersObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.WonCode.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.WonCode.mapOfGDgdjs_9546WonCode_9546GDplayerObjects2Objects, gdjs.WonCode.mapOfGDgdjs_9546WonCode_9546GDcharectersObjects2Objects, 80, true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(30228932);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewBitmapText"), gdjs.WonCode.GDNewBitmapTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("task_bar"), gdjs.WonCode.GDtask_9595barObjects2);
{for(var i = 0, len = gdjs.WonCode.GDtask_9595barObjects2.length ;i < len;++i) {
    gdjs.WonCode.GDtask_9595barObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.WonCode.GDNewBitmapTextObjects2.length ;i < len;++i) {
    gdjs.WonCode.GDNewBitmapTextObjects2[i].hide();
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.dialogueTree.isRunning();
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Joystick"), gdjs.WonCode.GDJoystickObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.WonCode.GDplayerObjects2);
{gdjs.evtTools.camera.showLayer(runtimeScene, "conversation");
}{for(var i = 0, len = gdjs.WonCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.WonCode.GDplayerObjects2[i].activateBehavior("TopDownMovement", false);
}
}{for(var i = 0, len = gdjs.WonCode.GDJoystickObjects2.length ;i < len;++i) {
    gdjs.WonCode.GDJoystickObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.WonCode.GDJoystickObjects2.length ;i < len;++i) {
    gdjs.WonCode.GDJoystickObjects2[i].ActivateControl(false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "scrollspeed") >= 2;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(30231364);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Joystick"), gdjs.WonCode.GDJoystickObjects2);
gdjs.copyArray(runtimeScene.getObjects("charecters"), gdjs.WonCode.GDcharectersObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.WonCode.GDplayerObjects2);
{gdjs.evtTools.camera.hideLayer(runtimeScene, "conversation");
}{for(var i = 0, len = gdjs.WonCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.WonCode.GDplayerObjects2[i].activateBehavior("TopDownMovement", true);
}
}{gdjs.evtTools.runtimeScene.removeTimer(runtimeScene, "scrollspeed");
}{for(var i = 0, len = gdjs.WonCode.GDJoystickObjects2.length ;i < len;++i) {
    gdjs.WonCode.GDJoystickObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.WonCode.GDJoystickObjects2.length ;i < len;++i) {
    gdjs.WonCode.GDJoystickObjects2[i].ActivateControl(true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.WonCode.GDcharectersObjects2.length ;i < len;++i) {
    gdjs.WonCode.GDcharectersObjects2[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.WonCode.eventsList3(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.dialogueTree.isDialogueLineType("text");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Dialoge"), gdjs.WonCode.GDDialogeObjects1);
{for(var i = 0, len = gdjs.WonCode.GDDialogeObjects1.length ;i < len;++i) {
    gdjs.WonCode.GDDialogeObjects1[i].getBehavior("Text").setText(gdjs.dialogueTree.getClippedLineText());
}
}
{ //Subevents
gdjs.WonCode.eventsList4(runtimeScene);} //End of subevents
}

}


};gdjs.WonCode.eventsList6 = function(runtimeScene) {

{

gdjs.WonCode.GDJoystickObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.WonCode.GDJoystickObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Joystick"), gdjs.WonCode.GDJoystickObjects3);
for (var i = 0, k = 0, l = gdjs.WonCode.GDJoystickObjects3.length;i<l;++i) {
    if ( gdjs.WonCode.GDJoystickObjects3[i].IsDirectionPushed8Way("Right", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.WonCode.GDJoystickObjects3[k] = gdjs.WonCode.GDJoystickObjects3[i];
        ++k;
    }
}
gdjs.WonCode.GDJoystickObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.WonCode.GDJoystickObjects3.length; j < jLen ; ++j) {
        if ( gdjs.WonCode.GDJoystickObjects2_1final.indexOf(gdjs.WonCode.GDJoystickObjects3[j]) === -1 )
            gdjs.WonCode.GDJoystickObjects2_1final.push(gdjs.WonCode.GDJoystickObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Joystick"), gdjs.WonCode.GDJoystickObjects3);
for (var i = 0, k = 0, l = gdjs.WonCode.GDJoystickObjects3.length;i<l;++i) {
    if ( gdjs.WonCode.GDJoystickObjects3[i].IsDirectionPushed8Way("UpRight", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.WonCode.GDJoystickObjects3[k] = gdjs.WonCode.GDJoystickObjects3[i];
        ++k;
    }
}
gdjs.WonCode.GDJoystickObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.WonCode.GDJoystickObjects3.length; j < jLen ; ++j) {
        if ( gdjs.WonCode.GDJoystickObjects2_1final.indexOf(gdjs.WonCode.GDJoystickObjects3[j]) === -1 )
            gdjs.WonCode.GDJoystickObjects2_1final.push(gdjs.WonCode.GDJoystickObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Joystick"), gdjs.WonCode.GDJoystickObjects3);
for (var i = 0, k = 0, l = gdjs.WonCode.GDJoystickObjects3.length;i<l;++i) {
    if ( gdjs.WonCode.GDJoystickObjects3[i].IsDirectionPushed8Way("DownRight", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.WonCode.GDJoystickObjects3[k] = gdjs.WonCode.GDJoystickObjects3[i];
        ++k;
    }
}
gdjs.WonCode.GDJoystickObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.WonCode.GDJoystickObjects3.length; j < jLen ; ++j) {
        if ( gdjs.WonCode.GDJoystickObjects2_1final.indexOf(gdjs.WonCode.GDJoystickObjects3[j]) === -1 )
            gdjs.WonCode.GDJoystickObjects2_1final.push(gdjs.WonCode.GDJoystickObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.WonCode.GDJoystickObjects2_1final, gdjs.WonCode.GDJoystickObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(30240884);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.WonCode.GDplayerObjects2);
{for(var i = 0, len = gdjs.WonCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.WonCode.GDplayerObjects2[i].getBehavior("Animation").setAnimationName("player-walk");
}
}{for(var i = 0, len = gdjs.WonCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.WonCode.GDplayerObjects2[i].getBehavior("Flippable").flipX(false);
}
}}

}


{

gdjs.WonCode.GDJoystickObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.WonCode.GDJoystickObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Joystick"), gdjs.WonCode.GDJoystickObjects3);
for (var i = 0, k = 0, l = gdjs.WonCode.GDJoystickObjects3.length;i<l;++i) {
    if ( gdjs.WonCode.GDJoystickObjects3[i].IsDirectionPushed8Way("Left", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.WonCode.GDJoystickObjects3[k] = gdjs.WonCode.GDJoystickObjects3[i];
        ++k;
    }
}
gdjs.WonCode.GDJoystickObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.WonCode.GDJoystickObjects3.length; j < jLen ; ++j) {
        if ( gdjs.WonCode.GDJoystickObjects2_1final.indexOf(gdjs.WonCode.GDJoystickObjects3[j]) === -1 )
            gdjs.WonCode.GDJoystickObjects2_1final.push(gdjs.WonCode.GDJoystickObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Joystick"), gdjs.WonCode.GDJoystickObjects3);
for (var i = 0, k = 0, l = gdjs.WonCode.GDJoystickObjects3.length;i<l;++i) {
    if ( gdjs.WonCode.GDJoystickObjects3[i].IsDirectionPushed8Way("DownLeft", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.WonCode.GDJoystickObjects3[k] = gdjs.WonCode.GDJoystickObjects3[i];
        ++k;
    }
}
gdjs.WonCode.GDJoystickObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.WonCode.GDJoystickObjects3.length; j < jLen ; ++j) {
        if ( gdjs.WonCode.GDJoystickObjects2_1final.indexOf(gdjs.WonCode.GDJoystickObjects3[j]) === -1 )
            gdjs.WonCode.GDJoystickObjects2_1final.push(gdjs.WonCode.GDJoystickObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Joystick"), gdjs.WonCode.GDJoystickObjects3);
for (var i = 0, k = 0, l = gdjs.WonCode.GDJoystickObjects3.length;i<l;++i) {
    if ( gdjs.WonCode.GDJoystickObjects3[i].IsDirectionPushed8Way("UpLeft", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.WonCode.GDJoystickObjects3[k] = gdjs.WonCode.GDJoystickObjects3[i];
        ++k;
    }
}
gdjs.WonCode.GDJoystickObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.WonCode.GDJoystickObjects3.length; j < jLen ; ++j) {
        if ( gdjs.WonCode.GDJoystickObjects2_1final.indexOf(gdjs.WonCode.GDJoystickObjects3[j]) === -1 )
            gdjs.WonCode.GDJoystickObjects2_1final.push(gdjs.WonCode.GDJoystickObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.WonCode.GDJoystickObjects2_1final, gdjs.WonCode.GDJoystickObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(30243052);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.WonCode.GDplayerObjects2);
{for(var i = 0, len = gdjs.WonCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.WonCode.GDplayerObjects2[i].getBehavior("Animation").setAnimationName("player-walk");
}
}{for(var i = 0, len = gdjs.WonCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.WonCode.GDplayerObjects2[i].getBehavior("Flippable").flipX(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Joystick"), gdjs.WonCode.GDJoystickObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.WonCode.GDJoystickObjects2.length;i<l;++i) {
    if ( !(gdjs.WonCode.GDJoystickObjects2[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.WonCode.GDJoystickObjects2[k] = gdjs.WonCode.GDJoystickObjects2[i];
        ++k;
    }
}
gdjs.WonCode.GDJoystickObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(30244428);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.WonCode.GDplayerObjects2);
{for(var i = 0, len = gdjs.WonCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.WonCode.GDplayerObjects2[i].getBehavior("Animation").setAnimationName("player");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.WonCode.GDE_9595buttonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Joystick"), gdjs.WonCode.GDJoystickObjects2);
{gdjs.evtTools.camera.showLayer(runtimeScene, "Mobile");
}{for(var i = 0, len = gdjs.WonCode.GDJoystickObjects2.length ;i < len;++i) {
    gdjs.WonCode.GDJoystickObjects2[i].ActivateControl(true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.WonCode.GDE_9595buttonObjects2.length ;i < len;++i) {
    gdjs.WonCode.GDE_9595buttonObjects2[i].Activate(true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene));
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.WonCode.GDE_9595buttonObjects1);
gdjs.copyArray(runtimeScene.getObjects("Joystick"), gdjs.WonCode.GDJoystickObjects1);
{gdjs.evtTools.camera.hideLayer(runtimeScene, "Mobile");
}{for(var i = 0, len = gdjs.WonCode.GDJoystickObjects1.length ;i < len;++i) {
    gdjs.WonCode.GDJoystickObjects1[i].ActivateControl(false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.WonCode.GDE_9595buttonObjects1.length ;i < len;++i) {
    gdjs.WonCode.GDE_9595buttonObjects1[i].Activate(false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.WonCode.eventsList7 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hitbox"), gdjs.WonCode.GDhitboxObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.WonCode.GDplayerObjects1);
{for(var i = 0, len = gdjs.WonCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.WonCode.GDplayerObjects1[i].activateBehavior("SmoothCamera", false);
}
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 2.5, "", 0);
}{for(var i = 0, len = gdjs.WonCode.GDhitboxObjects1.length ;i < len;++i) {
    gdjs.WonCode.GDhitboxObjects1[i].hide();
}
}{gdjs.dialogueTree.loadFromJsonFile(runtimeScene, "End");
}{gdjs.evtTools.sound.playMusic(runtimeScene, "calm-mountain-creek-ambience-228231.mp3", false, 25, 1);
}{gdjs.evtTools.sound.playMusic(runtimeScene, "fireplace-loop-original-noise-178209.mp3", false, 100, 1);
}}

}


{


gdjs.WonCode.eventsList1(runtimeScene);
}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NewBitmapText"), gdjs.WonCode.GDNewBitmapTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.WonCode.GDplayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("task_bar"), gdjs.WonCode.GDtask_9595barObjects1);
{for(var i = 0, len = gdjs.WonCode.GDtask_9595barObjects1.length ;i < len;++i) {
    gdjs.WonCode.GDtask_9595barObjects1[i].setPosition((( gdjs.WonCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.WonCode.GDplayerObjects1[0].getPointX("fly")) - 32,(( gdjs.WonCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.WonCode.GDplayerObjects1[0].getPointY("fly")) - 16);
}
}{for(var i = 0, len = gdjs.WonCode.GDNewBitmapTextObjects1.length ;i < len;++i) {
    gdjs.WonCode.GDNewBitmapTextObjects1[i].setPosition((( gdjs.WonCode.GDtask_9595barObjects1.length === 0 ) ? 0 :gdjs.WonCode.GDtask_9595barObjects1[0].getCenterXInScene()) - 16,(( gdjs.WonCode.GDtask_9595barObjects1.length === 0 ) ? 0 :gdjs.WonCode.GDtask_9595barObjects1[0].getCenterYInScene()) - 4);
}
}}

}


{


gdjs.WonCode.eventsList5(runtimeScene);
}


{


gdjs.WonCode.eventsList6(runtimeScene);
}


};

gdjs.WonCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.WonCode.GDNewSpriteObjects1.length = 0;
gdjs.WonCode.GDNewSpriteObjects2.length = 0;
gdjs.WonCode.GDNewSpriteObjects3.length = 0;
gdjs.WonCode.GDNewSpriteObjects4.length = 0;
gdjs.WonCode.GDtext_9595boxObjects1.length = 0;
gdjs.WonCode.GDtext_9595boxObjects2.length = 0;
gdjs.WonCode.GDtext_9595boxObjects3.length = 0;
gdjs.WonCode.GDtext_9595boxObjects4.length = 0;
gdjs.WonCode.GDtipObjects1.length = 0;
gdjs.WonCode.GDtipObjects2.length = 0;
gdjs.WonCode.GDtipObjects3.length = 0;
gdjs.WonCode.GDtipObjects4.length = 0;
gdjs.WonCode.GDNameObjects1.length = 0;
gdjs.WonCode.GDNameObjects2.length = 0;
gdjs.WonCode.GDNameObjects3.length = 0;
gdjs.WonCode.GDNameObjects4.length = 0;
gdjs.WonCode.GDDialogeObjects1.length = 0;
gdjs.WonCode.GDDialogeObjects2.length = 0;
gdjs.WonCode.GDDialogeObjects3.length = 0;
gdjs.WonCode.GDDialogeObjects4.length = 0;
gdjs.WonCode.GDcharecters2Objects1.length = 0;
gdjs.WonCode.GDcharecters2Objects2.length = 0;
gdjs.WonCode.GDcharecters2Objects3.length = 0;
gdjs.WonCode.GDcharecters2Objects4.length = 0;
gdjs.WonCode.GDfireObjects1.length = 0;
gdjs.WonCode.GDfireObjects2.length = 0;
gdjs.WonCode.GDfireObjects3.length = 0;
gdjs.WonCode.GDfireObjects4.length = 0;
gdjs.WonCode.GDPixelFlameObjects1.length = 0;
gdjs.WonCode.GDPixelFlameObjects2.length = 0;
gdjs.WonCode.GDPixelFlameObjects3.length = 0;
gdjs.WonCode.GDPixelFlameObjects4.length = 0;
gdjs.WonCode.GDPixelSmokeObjects1.length = 0;
gdjs.WonCode.GDPixelSmokeObjects2.length = 0;
gdjs.WonCode.GDPixelSmokeObjects3.length = 0;
gdjs.WonCode.GDPixelSmokeObjects4.length = 0;
gdjs.WonCode.GDRoomsObjects1.length = 0;
gdjs.WonCode.GDRoomsObjects2.length = 0;
gdjs.WonCode.GDRoomsObjects3.length = 0;
gdjs.WonCode.GDRoomsObjects4.length = 0;
gdjs.WonCode.GDWallObjects1.length = 0;
gdjs.WonCode.GDWallObjects2.length = 0;
gdjs.WonCode.GDWallObjects3.length = 0;
gdjs.WonCode.GDWallObjects4.length = 0;
gdjs.WonCode.GDfloorObjects1.length = 0;
gdjs.WonCode.GDfloorObjects2.length = 0;
gdjs.WonCode.GDfloorObjects3.length = 0;
gdjs.WonCode.GDfloorObjects4.length = 0;
gdjs.WonCode.GDdoorsObjects1.length = 0;
gdjs.WonCode.GDdoorsObjects2.length = 0;
gdjs.WonCode.GDdoorsObjects3.length = 0;
gdjs.WonCode.GDdoorsObjects4.length = 0;
gdjs.WonCode.GDobjectsObjects1.length = 0;
gdjs.WonCode.GDobjectsObjects2.length = 0;
gdjs.WonCode.GDobjectsObjects3.length = 0;
gdjs.WonCode.GDobjectsObjects4.length = 0;
gdjs.WonCode.GDwallobjectObjects1.length = 0;
gdjs.WonCode.GDwallobjectObjects2.length = 0;
gdjs.WonCode.GDwallobjectObjects3.length = 0;
gdjs.WonCode.GDwallobjectObjects4.length = 0;
gdjs.WonCode.GDwindowObjects1.length = 0;
gdjs.WonCode.GDwindowObjects2.length = 0;
gdjs.WonCode.GDwindowObjects3.length = 0;
gdjs.WonCode.GDwindowObjects4.length = 0;
gdjs.WonCode.GDrailObjects1.length = 0;
gdjs.WonCode.GDrailObjects2.length = 0;
gdjs.WonCode.GDrailObjects3.length = 0;
gdjs.WonCode.GDrailObjects4.length = 0;
gdjs.WonCode.GDplayerObjects1.length = 0;
gdjs.WonCode.GDplayerObjects2.length = 0;
gdjs.WonCode.GDplayerObjects3.length = 0;
gdjs.WonCode.GDplayerObjects4.length = 0;
gdjs.WonCode.GDhitboxObjects1.length = 0;
gdjs.WonCode.GDhitboxObjects2.length = 0;
gdjs.WonCode.GDhitboxObjects3.length = 0;
gdjs.WonCode.GDhitboxObjects4.length = 0;
gdjs.WonCode.GDMainlightObjects1.length = 0;
gdjs.WonCode.GDMainlightObjects2.length = 0;
gdjs.WonCode.GDMainlightObjects3.length = 0;
gdjs.WonCode.GDMainlightObjects4.length = 0;
gdjs.WonCode.GDsmalllightObjects1.length = 0;
gdjs.WonCode.GDsmalllightObjects2.length = 0;
gdjs.WonCode.GDsmalllightObjects3.length = 0;
gdjs.WonCode.GDsmalllightObjects4.length = 0;
gdjs.WonCode.GDNewBitmapTextObjects1.length = 0;
gdjs.WonCode.GDNewBitmapTextObjects2.length = 0;
gdjs.WonCode.GDNewBitmapTextObjects3.length = 0;
gdjs.WonCode.GDNewBitmapTextObjects4.length = 0;
gdjs.WonCode.GDtask_9595barObjects1.length = 0;
gdjs.WonCode.GDtask_9595barObjects2.length = 0;
gdjs.WonCode.GDtask_9595barObjects3.length = 0;
gdjs.WonCode.GDtask_9595barObjects4.length = 0;
gdjs.WonCode.GDcharectersObjects1.length = 0;
gdjs.WonCode.GDcharectersObjects2.length = 0;
gdjs.WonCode.GDcharectersObjects3.length = 0;
gdjs.WonCode.GDcharectersObjects4.length = 0;
gdjs.WonCode.GDcharecters22Objects1.length = 0;
gdjs.WonCode.GDcharecters22Objects2.length = 0;
gdjs.WonCode.GDcharecters22Objects3.length = 0;
gdjs.WonCode.GDcharecters22Objects4.length = 0;
gdjs.WonCode.GDPauseObjects1.length = 0;
gdjs.WonCode.GDPauseObjects2.length = 0;
gdjs.WonCode.GDPauseObjects3.length = 0;
gdjs.WonCode.GDPauseObjects4.length = 0;
gdjs.WonCode.GDresumeObjects1.length = 0;
gdjs.WonCode.GDresumeObjects2.length = 0;
gdjs.WonCode.GDresumeObjects3.length = 0;
gdjs.WonCode.GDresumeObjects4.length = 0;
gdjs.WonCode.GDQuit_95952Objects1.length = 0;
gdjs.WonCode.GDQuit_95952Objects2.length = 0;
gdjs.WonCode.GDQuit_95952Objects3.length = 0;
gdjs.WonCode.GDQuit_95952Objects4.length = 0;
gdjs.WonCode.GDpause_9595menuObjects1.length = 0;
gdjs.WonCode.GDpause_9595menuObjects2.length = 0;
gdjs.WonCode.GDpause_9595menuObjects3.length = 0;
gdjs.WonCode.GDpause_9595menuObjects4.length = 0;
gdjs.WonCode.GDHimaObjects1.length = 0;
gdjs.WonCode.GDHimaObjects2.length = 0;
gdjs.WonCode.GDHimaObjects3.length = 0;
gdjs.WonCode.GDHimaObjects4.length = 0;
gdjs.WonCode.GDLayaObjects1.length = 0;
gdjs.WonCode.GDLayaObjects2.length = 0;
gdjs.WonCode.GDLayaObjects3.length = 0;
gdjs.WonCode.GDLayaObjects4.length = 0;
gdjs.WonCode.GDJoystickObjects1.length = 0;
gdjs.WonCode.GDJoystickObjects2.length = 0;
gdjs.WonCode.GDJoystickObjects3.length = 0;
gdjs.WonCode.GDJoystickObjects4.length = 0;
gdjs.WonCode.GDE_9595buttonObjects1.length = 0;
gdjs.WonCode.GDE_9595buttonObjects2.length = 0;
gdjs.WonCode.GDE_9595buttonObjects3.length = 0;
gdjs.WonCode.GDE_9595buttonObjects4.length = 0;

gdjs.WonCode.eventsList7(runtimeScene);
gdjs.WonCode.GDNewSpriteObjects1.length = 0;
gdjs.WonCode.GDNewSpriteObjects2.length = 0;
gdjs.WonCode.GDNewSpriteObjects3.length = 0;
gdjs.WonCode.GDNewSpriteObjects4.length = 0;
gdjs.WonCode.GDtext_9595boxObjects1.length = 0;
gdjs.WonCode.GDtext_9595boxObjects2.length = 0;
gdjs.WonCode.GDtext_9595boxObjects3.length = 0;
gdjs.WonCode.GDtext_9595boxObjects4.length = 0;
gdjs.WonCode.GDtipObjects1.length = 0;
gdjs.WonCode.GDtipObjects2.length = 0;
gdjs.WonCode.GDtipObjects3.length = 0;
gdjs.WonCode.GDtipObjects4.length = 0;
gdjs.WonCode.GDNameObjects1.length = 0;
gdjs.WonCode.GDNameObjects2.length = 0;
gdjs.WonCode.GDNameObjects3.length = 0;
gdjs.WonCode.GDNameObjects4.length = 0;
gdjs.WonCode.GDDialogeObjects1.length = 0;
gdjs.WonCode.GDDialogeObjects2.length = 0;
gdjs.WonCode.GDDialogeObjects3.length = 0;
gdjs.WonCode.GDDialogeObjects4.length = 0;
gdjs.WonCode.GDcharecters2Objects1.length = 0;
gdjs.WonCode.GDcharecters2Objects2.length = 0;
gdjs.WonCode.GDcharecters2Objects3.length = 0;
gdjs.WonCode.GDcharecters2Objects4.length = 0;
gdjs.WonCode.GDfireObjects1.length = 0;
gdjs.WonCode.GDfireObjects2.length = 0;
gdjs.WonCode.GDfireObjects3.length = 0;
gdjs.WonCode.GDfireObjects4.length = 0;
gdjs.WonCode.GDPixelFlameObjects1.length = 0;
gdjs.WonCode.GDPixelFlameObjects2.length = 0;
gdjs.WonCode.GDPixelFlameObjects3.length = 0;
gdjs.WonCode.GDPixelFlameObjects4.length = 0;
gdjs.WonCode.GDPixelSmokeObjects1.length = 0;
gdjs.WonCode.GDPixelSmokeObjects2.length = 0;
gdjs.WonCode.GDPixelSmokeObjects3.length = 0;
gdjs.WonCode.GDPixelSmokeObjects4.length = 0;
gdjs.WonCode.GDRoomsObjects1.length = 0;
gdjs.WonCode.GDRoomsObjects2.length = 0;
gdjs.WonCode.GDRoomsObjects3.length = 0;
gdjs.WonCode.GDRoomsObjects4.length = 0;
gdjs.WonCode.GDWallObjects1.length = 0;
gdjs.WonCode.GDWallObjects2.length = 0;
gdjs.WonCode.GDWallObjects3.length = 0;
gdjs.WonCode.GDWallObjects4.length = 0;
gdjs.WonCode.GDfloorObjects1.length = 0;
gdjs.WonCode.GDfloorObjects2.length = 0;
gdjs.WonCode.GDfloorObjects3.length = 0;
gdjs.WonCode.GDfloorObjects4.length = 0;
gdjs.WonCode.GDdoorsObjects1.length = 0;
gdjs.WonCode.GDdoorsObjects2.length = 0;
gdjs.WonCode.GDdoorsObjects3.length = 0;
gdjs.WonCode.GDdoorsObjects4.length = 0;
gdjs.WonCode.GDobjectsObjects1.length = 0;
gdjs.WonCode.GDobjectsObjects2.length = 0;
gdjs.WonCode.GDobjectsObjects3.length = 0;
gdjs.WonCode.GDobjectsObjects4.length = 0;
gdjs.WonCode.GDwallobjectObjects1.length = 0;
gdjs.WonCode.GDwallobjectObjects2.length = 0;
gdjs.WonCode.GDwallobjectObjects3.length = 0;
gdjs.WonCode.GDwallobjectObjects4.length = 0;
gdjs.WonCode.GDwindowObjects1.length = 0;
gdjs.WonCode.GDwindowObjects2.length = 0;
gdjs.WonCode.GDwindowObjects3.length = 0;
gdjs.WonCode.GDwindowObjects4.length = 0;
gdjs.WonCode.GDrailObjects1.length = 0;
gdjs.WonCode.GDrailObjects2.length = 0;
gdjs.WonCode.GDrailObjects3.length = 0;
gdjs.WonCode.GDrailObjects4.length = 0;
gdjs.WonCode.GDplayerObjects1.length = 0;
gdjs.WonCode.GDplayerObjects2.length = 0;
gdjs.WonCode.GDplayerObjects3.length = 0;
gdjs.WonCode.GDplayerObjects4.length = 0;
gdjs.WonCode.GDhitboxObjects1.length = 0;
gdjs.WonCode.GDhitboxObjects2.length = 0;
gdjs.WonCode.GDhitboxObjects3.length = 0;
gdjs.WonCode.GDhitboxObjects4.length = 0;
gdjs.WonCode.GDMainlightObjects1.length = 0;
gdjs.WonCode.GDMainlightObjects2.length = 0;
gdjs.WonCode.GDMainlightObjects3.length = 0;
gdjs.WonCode.GDMainlightObjects4.length = 0;
gdjs.WonCode.GDsmalllightObjects1.length = 0;
gdjs.WonCode.GDsmalllightObjects2.length = 0;
gdjs.WonCode.GDsmalllightObjects3.length = 0;
gdjs.WonCode.GDsmalllightObjects4.length = 0;
gdjs.WonCode.GDNewBitmapTextObjects1.length = 0;
gdjs.WonCode.GDNewBitmapTextObjects2.length = 0;
gdjs.WonCode.GDNewBitmapTextObjects3.length = 0;
gdjs.WonCode.GDNewBitmapTextObjects4.length = 0;
gdjs.WonCode.GDtask_9595barObjects1.length = 0;
gdjs.WonCode.GDtask_9595barObjects2.length = 0;
gdjs.WonCode.GDtask_9595barObjects3.length = 0;
gdjs.WonCode.GDtask_9595barObjects4.length = 0;
gdjs.WonCode.GDcharectersObjects1.length = 0;
gdjs.WonCode.GDcharectersObjects2.length = 0;
gdjs.WonCode.GDcharectersObjects3.length = 0;
gdjs.WonCode.GDcharectersObjects4.length = 0;
gdjs.WonCode.GDcharecters22Objects1.length = 0;
gdjs.WonCode.GDcharecters22Objects2.length = 0;
gdjs.WonCode.GDcharecters22Objects3.length = 0;
gdjs.WonCode.GDcharecters22Objects4.length = 0;
gdjs.WonCode.GDPauseObjects1.length = 0;
gdjs.WonCode.GDPauseObjects2.length = 0;
gdjs.WonCode.GDPauseObjects3.length = 0;
gdjs.WonCode.GDPauseObjects4.length = 0;
gdjs.WonCode.GDresumeObjects1.length = 0;
gdjs.WonCode.GDresumeObjects2.length = 0;
gdjs.WonCode.GDresumeObjects3.length = 0;
gdjs.WonCode.GDresumeObjects4.length = 0;
gdjs.WonCode.GDQuit_95952Objects1.length = 0;
gdjs.WonCode.GDQuit_95952Objects2.length = 0;
gdjs.WonCode.GDQuit_95952Objects3.length = 0;
gdjs.WonCode.GDQuit_95952Objects4.length = 0;
gdjs.WonCode.GDpause_9595menuObjects1.length = 0;
gdjs.WonCode.GDpause_9595menuObjects2.length = 0;
gdjs.WonCode.GDpause_9595menuObjects3.length = 0;
gdjs.WonCode.GDpause_9595menuObjects4.length = 0;
gdjs.WonCode.GDHimaObjects1.length = 0;
gdjs.WonCode.GDHimaObjects2.length = 0;
gdjs.WonCode.GDHimaObjects3.length = 0;
gdjs.WonCode.GDHimaObjects4.length = 0;
gdjs.WonCode.GDLayaObjects1.length = 0;
gdjs.WonCode.GDLayaObjects2.length = 0;
gdjs.WonCode.GDLayaObjects3.length = 0;
gdjs.WonCode.GDLayaObjects4.length = 0;
gdjs.WonCode.GDJoystickObjects1.length = 0;
gdjs.WonCode.GDJoystickObjects2.length = 0;
gdjs.WonCode.GDJoystickObjects3.length = 0;
gdjs.WonCode.GDJoystickObjects4.length = 0;
gdjs.WonCode.GDE_9595buttonObjects1.length = 0;
gdjs.WonCode.GDE_9595buttonObjects2.length = 0;
gdjs.WonCode.GDE_9595buttonObjects3.length = 0;
gdjs.WonCode.GDE_9595buttonObjects4.length = 0;


return;

}

gdjs['WonCode'] = gdjs.WonCode;
