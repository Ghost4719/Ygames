gdjs.SchoolCode = {};
gdjs.SchoolCode.localVariables = [];
gdjs.SchoolCode.GDE_9595buttonObjects1_1final = [];

gdjs.SchoolCode.GDE_9595buttonObjects2_1final = [];

gdjs.SchoolCode.GDJoystickObjects2_1final = [];

gdjs.SchoolCode.GDpuddlesObjects1= [];
gdjs.SchoolCode.GDpuddlesObjects2= [];
gdjs.SchoolCode.GDpuddlesObjects3= [];
gdjs.SchoolCode.GDpuddlesObjects4= [];
gdjs.SchoolCode.GDNewParticlesEmitterObjects1= [];
gdjs.SchoolCode.GDNewParticlesEmitterObjects2= [];
gdjs.SchoolCode.GDNewParticlesEmitterObjects3= [];
gdjs.SchoolCode.GDNewParticlesEmitterObjects4= [];
gdjs.SchoolCode.GDLightObjects1= [];
gdjs.SchoolCode.GDLightObjects2= [];
gdjs.SchoolCode.GDLightObjects3= [];
gdjs.SchoolCode.GDLightObjects4= [];
gdjs.SchoolCode.GDLight2Objects1= [];
gdjs.SchoolCode.GDLight2Objects2= [];
gdjs.SchoolCode.GDLight2Objects3= [];
gdjs.SchoolCode.GDLight2Objects4= [];
gdjs.SchoolCode.GDNewShapePainterObjects1= [];
gdjs.SchoolCode.GDNewShapePainterObjects2= [];
gdjs.SchoolCode.GDNewShapePainterObjects3= [];
gdjs.SchoolCode.GDNewShapePainterObjects4= [];
gdjs.SchoolCode.GDNewParticlesEmitter2Objects1= [];
gdjs.SchoolCode.GDNewParticlesEmitter2Objects2= [];
gdjs.SchoolCode.GDNewParticlesEmitter2Objects3= [];
gdjs.SchoolCode.GDNewParticlesEmitter2Objects4= [];
gdjs.SchoolCode.GDtransitionObjects1= [];
gdjs.SchoolCode.GDtransitionObjects2= [];
gdjs.SchoolCode.GDtransitionObjects3= [];
gdjs.SchoolCode.GDtransitionObjects4= [];
gdjs.SchoolCode.GDfloor_95953Objects1= [];
gdjs.SchoolCode.GDfloor_95953Objects2= [];
gdjs.SchoolCode.GDfloor_95953Objects3= [];
gdjs.SchoolCode.GDfloor_95953Objects4= [];
gdjs.SchoolCode.GDcolorsObjects1= [];
gdjs.SchoolCode.GDcolorsObjects2= [];
gdjs.SchoolCode.GDcolorsObjects3= [];
gdjs.SchoolCode.GDcolorsObjects4= [];
gdjs.SchoolCode.GDnoteObjects1= [];
gdjs.SchoolCode.GDnoteObjects2= [];
gdjs.SchoolCode.GDnoteObjects3= [];
gdjs.SchoolCode.GDnoteObjects4= [];
gdjs.SchoolCode.GDoppacityObjects1= [];
gdjs.SchoolCode.GDoppacityObjects2= [];
gdjs.SchoolCode.GDoppacityObjects3= [];
gdjs.SchoolCode.GDoppacityObjects4= [];
gdjs.SchoolCode.GDcloseObjects1= [];
gdjs.SchoolCode.GDcloseObjects2= [];
gdjs.SchoolCode.GDcloseObjects3= [];
gdjs.SchoolCode.GDcloseObjects4= [];
gdjs.SchoolCode.GDnotesObjects1= [];
gdjs.SchoolCode.GDnotesObjects2= [];
gdjs.SchoolCode.GDnotesObjects3= [];
gdjs.SchoolCode.GDnotesObjects4= [];
gdjs.SchoolCode.GDnote2Objects1= [];
gdjs.SchoolCode.GDnote2Objects2= [];
gdjs.SchoolCode.GDnote2Objects3= [];
gdjs.SchoolCode.GDnote2Objects4= [];
gdjs.SchoolCode.GDLight3Objects1= [];
gdjs.SchoolCode.GDLight3Objects2= [];
gdjs.SchoolCode.GDLight3Objects3= [];
gdjs.SchoolCode.GDLight3Objects4= [];
gdjs.SchoolCode.GDareaObjects1= [];
gdjs.SchoolCode.GDareaObjects2= [];
gdjs.SchoolCode.GDareaObjects3= [];
gdjs.SchoolCode.GDareaObjects4= [];
gdjs.SchoolCode.GDspawn_9595himaObjects1= [];
gdjs.SchoolCode.GDspawn_9595himaObjects2= [];
gdjs.SchoolCode.GDspawn_9595himaObjects3= [];
gdjs.SchoolCode.GDspawn_9595himaObjects4= [];
gdjs.SchoolCode.GDLight_9595handObjects1= [];
gdjs.SchoolCode.GDLight_9595handObjects2= [];
gdjs.SchoolCode.GDLight_9595handObjects3= [];
gdjs.SchoolCode.GDLight_9595handObjects4= [];
gdjs.SchoolCode.GDarea2Objects1= [];
gdjs.SchoolCode.GDarea2Objects2= [];
gdjs.SchoolCode.GDarea2Objects3= [];
gdjs.SchoolCode.GDarea2Objects4= [];
gdjs.SchoolCode.GDCartObjects1= [];
gdjs.SchoolCode.GDCartObjects2= [];
gdjs.SchoolCode.GDCartObjects3= [];
gdjs.SchoolCode.GDCartObjects4= [];
gdjs.SchoolCode.GDWallObjects1= [];
gdjs.SchoolCode.GDWallObjects2= [];
gdjs.SchoolCode.GDWallObjects3= [];
gdjs.SchoolCode.GDWallObjects4= [];
gdjs.SchoolCode.GDfloorObjects1= [];
gdjs.SchoolCode.GDfloorObjects2= [];
gdjs.SchoolCode.GDfloorObjects3= [];
gdjs.SchoolCode.GDfloorObjects4= [];
gdjs.SchoolCode.GDdoorsObjects1= [];
gdjs.SchoolCode.GDdoorsObjects2= [];
gdjs.SchoolCode.GDdoorsObjects3= [];
gdjs.SchoolCode.GDdoorsObjects4= [];
gdjs.SchoolCode.GDobjectsObjects1= [];
gdjs.SchoolCode.GDobjectsObjects2= [];
gdjs.SchoolCode.GDobjectsObjects3= [];
gdjs.SchoolCode.GDobjectsObjects4= [];
gdjs.SchoolCode.GDwallobjectObjects1= [];
gdjs.SchoolCode.GDwallobjectObjects2= [];
gdjs.SchoolCode.GDwallobjectObjects3= [];
gdjs.SchoolCode.GDwallobjectObjects4= [];
gdjs.SchoolCode.GDwindowObjects1= [];
gdjs.SchoolCode.GDwindowObjects2= [];
gdjs.SchoolCode.GDwindowObjects3= [];
gdjs.SchoolCode.GDwindowObjects4= [];
gdjs.SchoolCode.GDrailObjects1= [];
gdjs.SchoolCode.GDrailObjects2= [];
gdjs.SchoolCode.GDrailObjects3= [];
gdjs.SchoolCode.GDrailObjects4= [];
gdjs.SchoolCode.GDplayerObjects1= [];
gdjs.SchoolCode.GDplayerObjects2= [];
gdjs.SchoolCode.GDplayerObjects3= [];
gdjs.SchoolCode.GDplayerObjects4= [];
gdjs.SchoolCode.GDhitboxObjects1= [];
gdjs.SchoolCode.GDhitboxObjects2= [];
gdjs.SchoolCode.GDhitboxObjects3= [];
gdjs.SchoolCode.GDhitboxObjects4= [];
gdjs.SchoolCode.GDMainlightObjects1= [];
gdjs.SchoolCode.GDMainlightObjects2= [];
gdjs.SchoolCode.GDMainlightObjects3= [];
gdjs.SchoolCode.GDMainlightObjects4= [];
gdjs.SchoolCode.GDsmalllightObjects1= [];
gdjs.SchoolCode.GDsmalllightObjects2= [];
gdjs.SchoolCode.GDsmalllightObjects3= [];
gdjs.SchoolCode.GDsmalllightObjects4= [];
gdjs.SchoolCode.GDNewBitmapTextObjects1= [];
gdjs.SchoolCode.GDNewBitmapTextObjects2= [];
gdjs.SchoolCode.GDNewBitmapTextObjects3= [];
gdjs.SchoolCode.GDNewBitmapTextObjects4= [];
gdjs.SchoolCode.GDtask_9595barObjects1= [];
gdjs.SchoolCode.GDtask_9595barObjects2= [];
gdjs.SchoolCode.GDtask_9595barObjects3= [];
gdjs.SchoolCode.GDtask_9595barObjects4= [];
gdjs.SchoolCode.GDcharectersObjects1= [];
gdjs.SchoolCode.GDcharectersObjects2= [];
gdjs.SchoolCode.GDcharectersObjects3= [];
gdjs.SchoolCode.GDcharectersObjects4= [];
gdjs.SchoolCode.GDcharecters22Objects1= [];
gdjs.SchoolCode.GDcharecters22Objects2= [];
gdjs.SchoolCode.GDcharecters22Objects3= [];
gdjs.SchoolCode.GDcharecters22Objects4= [];
gdjs.SchoolCode.GDPauseObjects1= [];
gdjs.SchoolCode.GDPauseObjects2= [];
gdjs.SchoolCode.GDPauseObjects3= [];
gdjs.SchoolCode.GDPauseObjects4= [];
gdjs.SchoolCode.GDresumeObjects1= [];
gdjs.SchoolCode.GDresumeObjects2= [];
gdjs.SchoolCode.GDresumeObjects3= [];
gdjs.SchoolCode.GDresumeObjects4= [];
gdjs.SchoolCode.GDQuit_95952Objects1= [];
gdjs.SchoolCode.GDQuit_95952Objects2= [];
gdjs.SchoolCode.GDQuit_95952Objects3= [];
gdjs.SchoolCode.GDQuit_95952Objects4= [];
gdjs.SchoolCode.GDpause_9595menuObjects1= [];
gdjs.SchoolCode.GDpause_9595menuObjects2= [];
gdjs.SchoolCode.GDpause_9595menuObjects3= [];
gdjs.SchoolCode.GDpause_9595menuObjects4= [];
gdjs.SchoolCode.GDHimaObjects1= [];
gdjs.SchoolCode.GDHimaObjects2= [];
gdjs.SchoolCode.GDHimaObjects3= [];
gdjs.SchoolCode.GDHimaObjects4= [];
gdjs.SchoolCode.GDLayaObjects1= [];
gdjs.SchoolCode.GDLayaObjects2= [];
gdjs.SchoolCode.GDLayaObjects3= [];
gdjs.SchoolCode.GDLayaObjects4= [];
gdjs.SchoolCode.GDJoystickObjects1= [];
gdjs.SchoolCode.GDJoystickObjects2= [];
gdjs.SchoolCode.GDJoystickObjects3= [];
gdjs.SchoolCode.GDJoystickObjects4= [];
gdjs.SchoolCode.GDE_9595buttonObjects1= [];
gdjs.SchoolCode.GDE_9595buttonObjects2= [];
gdjs.SchoolCode.GDE_9595buttonObjects3= [];
gdjs.SchoolCode.GDE_9595buttonObjects4= [];


gdjs.SchoolCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.SchoolCode.GDplayerObjects2, gdjs.SchoolCode.GDplayerObjects3);

{for(var i = 0, len = gdjs.SchoolCode.GDplayerObjects3.length ;i < len;++i) {
    gdjs.SchoolCode.GDplayerObjects3[i].getBehavior("Flippable").flipX(false);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if (isConditionTrue_0) {
/* Reuse gdjs.SchoolCode.GDplayerObjects2 */
{for(var i = 0, len = gdjs.SchoolCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDplayerObjects2[i].getBehavior("Flippable").flipX(true);
}
}}

}


};gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.SchoolCode.GDplayerObjects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDWallObjects2Objects = Hashtable.newFrom({"Wall": gdjs.SchoolCode.GDWallObjects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDWallObjects2Objects = Hashtable.newFrom({"Wall": gdjs.SchoolCode.GDWallObjects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.SchoolCode.GDplayerObjects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDhitboxObjects2Objects = Hashtable.newFrom({"hitbox": gdjs.SchoolCode.GDhitboxObjects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDhitboxObjects2Objects = Hashtable.newFrom({"hitbox": gdjs.SchoolCode.GDhitboxObjects2});
gdjs.SchoolCode.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDplayerObjects2.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDplayerObjects2[i].getBehavior("TopDownMovement").isMoving() ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDplayerObjects2[k] = gdjs.SchoolCode.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDplayerObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.SchoolCode.GDplayerObjects2 */
{for(var i = 0, len = gdjs.SchoolCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDplayerObjects2[i].getBehavior("Animation").setAnimationName("player-walk");
}
}
{ //Subevents
gdjs.SchoolCode.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDplayerObjects2.length;i<l;++i) {
    if ( !(gdjs.SchoolCode.GDplayerObjects2[i].getBehavior("TopDownMovement").isMoving()) ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDplayerObjects2[k] = gdjs.SchoolCode.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDplayerObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.SchoolCode.GDplayerObjects2 */
{for(var i = 0, len = gdjs.SchoolCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDplayerObjects2[i].getBehavior("Animation").setAnimationName("player");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Wall"), gdjs.SchoolCode.GDWallObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects, gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDWallObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.SchoolCode.GDWallObjects2 */
/* Reuse gdjs.SchoolCode.GDplayerObjects2 */
{for(var i = 0, len = gdjs.SchoolCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDplayerObjects2[i].separateFromObjectsList(gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDWallObjects2Objects, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("hitbox"), gdjs.SchoolCode.GDhitboxObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects, gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDhitboxObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.SchoolCode.GDhitboxObjects2 */
/* Reuse gdjs.SchoolCode.GDplayerObjects2 */
{for(var i = 0, len = gdjs.SchoolCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDplayerObjects2[i].separateFromObjectsList(gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDhitboxObjects2Objects, false);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects2);
{for(var i = 0, len = gdjs.SchoolCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDplayerObjects2[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "s");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects2);
{for(var i = 0, len = gdjs.SchoolCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDplayerObjects2[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects2);
{for(var i = 0, len = gdjs.SchoolCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDplayerObjects2[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects1);
{for(var i = 0, len = gdjs.SchoolCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.SchoolCode.GDplayerObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


};gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.SchoolCode.GDplayerObjects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDdoorsObjects2Objects = Hashtable.newFrom({"doors": gdjs.SchoolCode.GDdoorsObjects2});
gdjs.SchoolCode.asyncCallback29119092 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.SchoolCode.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Rooms", false);
}gdjs.SchoolCode.localVariables.length = 0;
}
gdjs.SchoolCode.eventsList2 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.SchoolCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.SchoolCode.asyncCallback29119092(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.SchoolCode.asyncCallback29118660 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.SchoolCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("doors"), gdjs.SchoolCode.GDdoorsObjects3);

gdjs.copyArray(runtimeScene.getObjects("transition"), gdjs.SchoolCode.GDtransitionObjects3);
{runtimeScene.getGame().getVariables().getFromIndex(0).setString(((gdjs.SchoolCode.GDdoorsObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.SchoolCode.GDdoorsObjects3[0].getVariables()).getFromIndex(0).getAsString());
}{for(var i = 0, len = gdjs.SchoolCode.GDtransitionObjects3.length ;i < len;++i) {
    gdjs.SchoolCode.GDtransitionObjects3[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 0.2, "Flash", "Forward", 100, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.SchoolCode.eventsList2(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.SchoolCode.localVariables.length = 0;
}
gdjs.SchoolCode.eventsList3 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.SchoolCode.localVariables);
for (const obj of gdjs.SchoolCode.GDdoorsObjects2) asyncObjectsList.addObject("doors", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.SchoolCode.asyncCallback29118660(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.SchoolCode.GDplayerObjects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDdoorsObjects2Objects = Hashtable.newFrom({"doors": gdjs.SchoolCode.GDdoorsObjects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.SchoolCode.GDplayerObjects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDdoorsObjects2Objects = Hashtable.newFrom({"doors": gdjs.SchoolCode.GDdoorsObjects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.SchoolCode.GDplayerObjects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDdoorsObjects2Objects = Hashtable.newFrom({"doors": gdjs.SchoolCode.GDdoorsObjects2});
gdjs.SchoolCode.asyncCallback29126660 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.SchoolCode.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Rooms", false);
}gdjs.SchoolCode.localVariables.length = 0;
}
gdjs.SchoolCode.eventsList4 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.SchoolCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.SchoolCode.asyncCallback29126660(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.SchoolCode.asyncCallback29126228 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.SchoolCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("doors"), gdjs.SchoolCode.GDdoorsObjects3);

gdjs.copyArray(runtimeScene.getObjects("transition"), gdjs.SchoolCode.GDtransitionObjects3);
{runtimeScene.getGame().getVariables().getFromIndex(0).setString(((gdjs.SchoolCode.GDdoorsObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.SchoolCode.GDdoorsObjects3[0].getVariables()).getFromIndex(0).getAsString());
}{for(var i = 0, len = gdjs.SchoolCode.GDtransitionObjects3.length ;i < len;++i) {
    gdjs.SchoolCode.GDtransitionObjects3[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 0.2, "Flash", "Forward", 100, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.SchoolCode.eventsList4(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.SchoolCode.localVariables.length = 0;
}
gdjs.SchoolCode.eventsList5 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.SchoolCode.localVariables);
for (const obj of gdjs.SchoolCode.GDdoorsObjects2) asyncObjectsList.addObject("doors", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.SchoolCode.asyncCallback29126228(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.SchoolCode.GDplayerObjects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDdoorsObjects2Objects = Hashtable.newFrom({"doors": gdjs.SchoolCode.GDdoorsObjects2});
gdjs.SchoolCode.asyncCallback29130084 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.SchoolCode.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "School", false);
}gdjs.SchoolCode.localVariables.length = 0;
}
gdjs.SchoolCode.eventsList6 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.SchoolCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.SchoolCode.asyncCallback29130084(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.SchoolCode.eventsList7 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("transition"), gdjs.SchoolCode.GDtransitionObjects3);
{for(var i = 0, len = gdjs.SchoolCode.GDtransitionObjects3.length ;i < len;++i) {
    gdjs.SchoolCode.GDtransitionObjects3[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 0.2, "Flash", "Forward", 100, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.SchoolCode.eventsList6(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.SchoolCode.asyncCallback29129124 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.SchoolCode.localVariables);
{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(3);
}{runtimeScene.getGame().getVariables().getFromIndex(0).setString("1");
}
{ //Subevents
gdjs.SchoolCode.eventsList7(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.SchoolCode.localVariables.length = 0;
}
gdjs.SchoolCode.eventsList8 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.SchoolCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.SchoolCode.asyncCallback29129124(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.SchoolCode.GDplayerObjects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDdoorsObjects2Objects = Hashtable.newFrom({"doors": gdjs.SchoolCode.GDdoorsObjects2});
gdjs.SchoolCode.asyncCallback29133780 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.SchoolCode.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "School", false);
}gdjs.SchoolCode.localVariables.length = 0;
}
gdjs.SchoolCode.eventsList9 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.SchoolCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.SchoolCode.asyncCallback29133780(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.SchoolCode.eventsList10 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("transition"), gdjs.SchoolCode.GDtransitionObjects3);
{for(var i = 0, len = gdjs.SchoolCode.GDtransitionObjects3.length ;i < len;++i) {
    gdjs.SchoolCode.GDtransitionObjects3[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 0.2, "Flash", "Forward", 100, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.SchoolCode.eventsList9(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.SchoolCode.asyncCallback29132804 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.SchoolCode.localVariables);
{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(3);
}{runtimeScene.getGame().getVariables().getFromIndex(0).setString("1");
}
{ //Subevents
gdjs.SchoolCode.eventsList10(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.SchoolCode.localVariables.length = 0;
}
gdjs.SchoolCode.eventsList11 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.SchoolCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.SchoolCode.asyncCallback29132804(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.SchoolCode.GDplayerObjects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDdoorsObjects2Objects = Hashtable.newFrom({"doors": gdjs.SchoolCode.GDdoorsObjects2});
gdjs.SchoolCode.asyncCallback29137188 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.SchoolCode.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "School", false);
}gdjs.SchoolCode.localVariables.length = 0;
}
gdjs.SchoolCode.eventsList12 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.SchoolCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.SchoolCode.asyncCallback29137188(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.SchoolCode.eventsList13 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("transition"), gdjs.SchoolCode.GDtransitionObjects3);
{for(var i = 0, len = gdjs.SchoolCode.GDtransitionObjects3.length ;i < len;++i) {
    gdjs.SchoolCode.GDtransitionObjects3[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 0.2, "Flash", "Forward", 100, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.SchoolCode.eventsList12(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.SchoolCode.asyncCallback29136244 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.SchoolCode.localVariables);
{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(1);
}{runtimeScene.getGame().getVariables().getFromIndex(0).setString("3");
}
{ //Subevents
gdjs.SchoolCode.eventsList13(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.SchoolCode.localVariables.length = 0;
}
gdjs.SchoolCode.eventsList14 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.SchoolCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.SchoolCode.asyncCallback29136244(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.SchoolCode.GDplayerObjects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDdoorsObjects2Objects = Hashtable.newFrom({"doors": gdjs.SchoolCode.GDdoorsObjects2});
gdjs.SchoolCode.asyncCallback29140820 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.SchoolCode.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "School", false);
}gdjs.SchoolCode.localVariables.length = 0;
}
gdjs.SchoolCode.eventsList15 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.SchoolCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.SchoolCode.asyncCallback29140820(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.SchoolCode.eventsList16 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("transition"), gdjs.SchoolCode.GDtransitionObjects3);
{for(var i = 0, len = gdjs.SchoolCode.GDtransitionObjects3.length ;i < len;++i) {
    gdjs.SchoolCode.GDtransitionObjects3[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 0.2, "Flash", "Forward", 100, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.SchoolCode.eventsList15(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.SchoolCode.asyncCallback29139228 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.SchoolCode.localVariables);
{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(1);
}{runtimeScene.getGame().getVariables().getFromIndex(0).setString("3");
}
{ //Subevents
gdjs.SchoolCode.eventsList16(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.SchoolCode.localVariables.length = 0;
}
gdjs.SchoolCode.eventsList17 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.SchoolCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.SchoolCode.asyncCallback29139228(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.SchoolCode.GDplayerObjects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDdoorsObjects2Objects = Hashtable.newFrom({"doors": gdjs.SchoolCode.GDdoorsObjects2});
gdjs.SchoolCode.asyncCallback29144028 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.SchoolCode.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "School", false);
}{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(4);
}gdjs.SchoolCode.localVariables.length = 0;
}
gdjs.SchoolCode.eventsList18 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.SchoolCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.SchoolCode.asyncCallback29144028(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.SchoolCode.eventsList19 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("transition"), gdjs.SchoolCode.GDtransitionObjects3);
{for(var i = 0, len = gdjs.SchoolCode.GDtransitionObjects3.length ;i < len;++i) {
    gdjs.SchoolCode.GDtransitionObjects3[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 0.2, "Flash", "Forward", 100, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.SchoolCode.eventsList18(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.SchoolCode.asyncCallback29143180 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.SchoolCode.localVariables);
{runtimeScene.getGame().getVariables().getFromIndex(0).setString("2");
}
{ //Subevents
gdjs.SchoolCode.eventsList19(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.SchoolCode.localVariables.length = 0;
}
gdjs.SchoolCode.eventsList20 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.SchoolCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.SchoolCode.asyncCallback29143180(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.SchoolCode.GDplayerObjects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDdoorsObjects2Objects = Hashtable.newFrom({"doors": gdjs.SchoolCode.GDdoorsObjects2});
gdjs.SchoolCode.asyncCallback29147692 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.SchoolCode.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "School", false);
}{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(4);
}gdjs.SchoolCode.localVariables.length = 0;
}
gdjs.SchoolCode.eventsList21 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.SchoolCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.SchoolCode.asyncCallback29147692(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.SchoolCode.eventsList22 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("transition"), gdjs.SchoolCode.GDtransitionObjects3);
{for(var i = 0, len = gdjs.SchoolCode.GDtransitionObjects3.length ;i < len;++i) {
    gdjs.SchoolCode.GDtransitionObjects3[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 0.2, "Flash", "Forward", 100, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.SchoolCode.eventsList21(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.SchoolCode.asyncCallback29146948 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.SchoolCode.localVariables);
{runtimeScene.getGame().getVariables().getFromIndex(0).setString("2");
}
{ //Subevents
gdjs.SchoolCode.eventsList22(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.SchoolCode.localVariables.length = 0;
}
gdjs.SchoolCode.eventsList23 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.SchoolCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.SchoolCode.asyncCallback29146948(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.SchoolCode.GDplayerObjects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDdoorsObjects2Objects = Hashtable.newFrom({"doors": gdjs.SchoolCode.GDdoorsObjects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDareaObjects2Objects = Hashtable.newFrom({"area": gdjs.SchoolCode.GDareaObjects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDdoorsObjects2Objects = Hashtable.newFrom({"doors": gdjs.SchoolCode.GDdoorsObjects2});
gdjs.SchoolCode.asyncCallback29151340 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.SchoolCode.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "School", false);
}{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(4);
}gdjs.SchoolCode.localVariables.length = 0;
}
gdjs.SchoolCode.eventsList24 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.SchoolCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.SchoolCode.asyncCallback29151340(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.SchoolCode.eventsList25 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("transition"), gdjs.SchoolCode.GDtransitionObjects3);
{for(var i = 0, len = gdjs.SchoolCode.GDtransitionObjects3.length ;i < len;++i) {
    gdjs.SchoolCode.GDtransitionObjects3[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 0.2, "Flash", "Forward", 100, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.SchoolCode.eventsList24(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.SchoolCode.asyncCallback29150308 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.SchoolCode.localVariables);
{runtimeScene.getGame().getVariables().getFromIndex(0).setString("2");
}
{ //Subevents
gdjs.SchoolCode.eventsList25(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.SchoolCode.localVariables.length = 0;
}
gdjs.SchoolCode.eventsList26 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.SchoolCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.SchoolCode.asyncCallback29150308(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.SchoolCode.GDplayerObjects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDdoorsObjects2Objects = Hashtable.newFrom({"doors": gdjs.SchoolCode.GDdoorsObjects2});
gdjs.SchoolCode.asyncCallback29154772 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.SchoolCode.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "School", false);
}{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(2);
}gdjs.SchoolCode.localVariables.length = 0;
}
gdjs.SchoolCode.eventsList27 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.SchoolCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.SchoolCode.asyncCallback29154772(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.SchoolCode.eventsList28 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("transition"), gdjs.SchoolCode.GDtransitionObjects3);
{for(var i = 0, len = gdjs.SchoolCode.GDtransitionObjects3.length ;i < len;++i) {
    gdjs.SchoolCode.GDtransitionObjects3[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 0.2, "Flash", "Forward", 100, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.SchoolCode.eventsList27(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.SchoolCode.asyncCallback29154004 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.SchoolCode.localVariables);
{runtimeScene.getGame().getVariables().getFromIndex(0).setString("4");
}
{ //Subevents
gdjs.SchoolCode.eventsList28(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.SchoolCode.localVariables.length = 0;
}
gdjs.SchoolCode.eventsList29 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.SchoolCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.SchoolCode.asyncCallback29154004(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.SchoolCode.GDplayerObjects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDdoorsObjects2Objects = Hashtable.newFrom({"doors": gdjs.SchoolCode.GDdoorsObjects2});
gdjs.SchoolCode.asyncCallback29158404 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.SchoolCode.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "School", false);
}{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(2);
}gdjs.SchoolCode.localVariables.length = 0;
}
gdjs.SchoolCode.eventsList30 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.SchoolCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.SchoolCode.asyncCallback29158404(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.SchoolCode.eventsList31 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("transition"), gdjs.SchoolCode.GDtransitionObjects3);
{for(var i = 0, len = gdjs.SchoolCode.GDtransitionObjects3.length ;i < len;++i) {
    gdjs.SchoolCode.GDtransitionObjects3[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 0.2, "Flash", "Forward", 100, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.SchoolCode.eventsList30(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.SchoolCode.asyncCallback29157612 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.SchoolCode.localVariables);
{runtimeScene.getGame().getVariables().getFromIndex(0).setString("4");
}
{ //Subevents
gdjs.SchoolCode.eventsList31(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.SchoolCode.localVariables.length = 0;
}
gdjs.SchoolCode.eventsList32 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.SchoolCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.SchoolCode.asyncCallback29157612(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.SchoolCode.GDplayerObjects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDdoorsObjects2Objects = Hashtable.newFrom({"doors": gdjs.SchoolCode.GDdoorsObjects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDareaObjects2Objects = Hashtable.newFrom({"area": gdjs.SchoolCode.GDareaObjects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDdoorsObjects2Objects = Hashtable.newFrom({"doors": gdjs.SchoolCode.GDdoorsObjects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDareaObjects2Objects = Hashtable.newFrom({"area": gdjs.SchoolCode.GDareaObjects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDdoorsObjects2Objects = Hashtable.newFrom({"doors": gdjs.SchoolCode.GDdoorsObjects2});
gdjs.SchoolCode.asyncCallback29162236 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.SchoolCode.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "School", false);
}{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(2);
}gdjs.SchoolCode.localVariables.length = 0;
}
gdjs.SchoolCode.eventsList33 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.SchoolCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.SchoolCode.asyncCallback29162236(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.SchoolCode.eventsList34 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("transition"), gdjs.SchoolCode.GDtransitionObjects3);
{for(var i = 0, len = gdjs.SchoolCode.GDtransitionObjects3.length ;i < len;++i) {
    gdjs.SchoolCode.GDtransitionObjects3[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 0.2, "Flash", "Forward", 100, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.SchoolCode.eventsList33(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.SchoolCode.asyncCallback29161484 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.SchoolCode.localVariables);
{runtimeScene.getGame().getVariables().getFromIndex(0).setString("4");
}
{ //Subevents
gdjs.SchoolCode.eventsList34(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.SchoolCode.localVariables.length = 0;
}
gdjs.SchoolCode.eventsList35 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.SchoolCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.SchoolCode.asyncCallback29161484(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.SchoolCode.GDplayerObjects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDdoorsObjects2Objects = Hashtable.newFrom({"doors": gdjs.SchoolCode.GDdoorsObjects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.SchoolCode.GDplayerObjects1});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDdoorsObjects1Objects = Hashtable.newFrom({"doors": gdjs.SchoolCode.GDdoorsObjects1});
gdjs.SchoolCode.eventsList36 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("doors"), gdjs.SchoolCode.GDdoorsObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects2);
gdjs.SchoolCode.GDE_9595buttonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects, gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDdoorsObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDdoorsObjects2.length;i<l;++i) {
    if ( !((gdjs.SchoolCode.GDdoorsObjects2[i].getVariableString(gdjs.SchoolCode.GDdoorsObjects2[i].getVariables().getFromIndex(0))).includes("0")) ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDdoorsObjects2[k] = gdjs.SchoolCode.GDdoorsObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDdoorsObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.SchoolCode.GDE_9595buttonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.SchoolCode.GDE_9595buttonObjects3);
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDE_9595buttonObjects3.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDE_9595buttonObjects3[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.SchoolCode.GDE_9595buttonObjects3[k] = gdjs.SchoolCode.GDE_9595buttonObjects3[i];
        ++k;
    }
}
gdjs.SchoolCode.GDE_9595buttonObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.SchoolCode.GDE_9595buttonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.SchoolCode.GDE_9595buttonObjects2_1final.indexOf(gdjs.SchoolCode.GDE_9595buttonObjects3[j]) === -1 )
            gdjs.SchoolCode.GDE_9595buttonObjects2_1final.push(gdjs.SchoolCode.GDE_9595buttonObjects3[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.SchoolCode.GDE_9595buttonObjects2_1final, gdjs.SchoolCode.GDE_9595buttonObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(16)) == 1);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(18)) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("misionstate"), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29118068);
}
}
}
}
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "door-open-46756_nnWlox72.mp3", false, 100, 1);
}
{ //Subevents
gdjs.SchoolCode.eventsList3(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("doors"), gdjs.SchoolCode.GDdoorsObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects2);
gdjs.SchoolCode.GDE_9595buttonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects, gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDdoorsObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDdoorsObjects2.length;i<l;++i) {
    if ( (gdjs.SchoolCode.GDdoorsObjects2[i].getVariableString(gdjs.SchoolCode.GDdoorsObjects2[i].getVariables().getFromIndex(0))).includes("0") ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDdoorsObjects2[k] = gdjs.SchoolCode.GDdoorsObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDdoorsObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.SchoolCode.GDE_9595buttonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.SchoolCode.GDE_9595buttonObjects3);
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDE_9595buttonObjects3.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDE_9595buttonObjects3[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.SchoolCode.GDE_9595buttonObjects3[k] = gdjs.SchoolCode.GDE_9595buttonObjects3[i];
        ++k;
    }
}
gdjs.SchoolCode.GDE_9595buttonObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.SchoolCode.GDE_9595buttonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.SchoolCode.GDE_9595buttonObjects2_1final.indexOf(gdjs.SchoolCode.GDE_9595buttonObjects3[j]) === -1 )
            gdjs.SchoolCode.GDE_9595buttonObjects2_1final.push(gdjs.SchoolCode.GDE_9595buttonObjects3[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.SchoolCode.GDE_9595buttonObjects2_1final, gdjs.SchoolCode.GDE_9595buttonObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "locked") >= 2;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29120852);
}
}
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "door-bang-1wav-14449.mp3", false, 100, 1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "locked");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("doors"), gdjs.SchoolCode.GDdoorsObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects2);
gdjs.SchoolCode.GDE_9595buttonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects, gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDdoorsObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(18)) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.SchoolCode.GDE_9595buttonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.SchoolCode.GDE_9595buttonObjects3);
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDE_9595buttonObjects3.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDE_9595buttonObjects3[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.SchoolCode.GDE_9595buttonObjects3[k] = gdjs.SchoolCode.GDE_9595buttonObjects3[i];
        ++k;
    }
}
gdjs.SchoolCode.GDE_9595buttonObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.SchoolCode.GDE_9595buttonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.SchoolCode.GDE_9595buttonObjects2_1final.indexOf(gdjs.SchoolCode.GDE_9595buttonObjects3[j]) === -1 )
            gdjs.SchoolCode.GDE_9595buttonObjects2_1final.push(gdjs.SchoolCode.GDE_9595buttonObjects3[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.SchoolCode.GDE_9595buttonObjects2_1final, gdjs.SchoolCode.GDE_9595buttonObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "locked") >= 2;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29123444);
}
}
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "door-bang-1wav-14449.mp3", false, 100, 1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "locked");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("doors"), gdjs.SchoolCode.GDdoorsObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects2);
gdjs.SchoolCode.GDE_9595buttonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects, gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDdoorsObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDdoorsObjects2.length;i<l;++i) {
    if ( !((gdjs.SchoolCode.GDdoorsObjects2[i].getVariableString(gdjs.SchoolCode.GDdoorsObjects2[i].getVariables().getFromIndex(0))).includes("0")) ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDdoorsObjects2[k] = gdjs.SchoolCode.GDdoorsObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDdoorsObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.SchoolCode.GDE_9595buttonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.SchoolCode.GDE_9595buttonObjects3);
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDE_9595buttonObjects3.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDE_9595buttonObjects3[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.SchoolCode.GDE_9595buttonObjects3[k] = gdjs.SchoolCode.GDE_9595buttonObjects3[i];
        ++k;
    }
}
gdjs.SchoolCode.GDE_9595buttonObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.SchoolCode.GDE_9595buttonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.SchoolCode.GDE_9595buttonObjects2_1final.indexOf(gdjs.SchoolCode.GDE_9595buttonObjects3[j]) === -1 )
            gdjs.SchoolCode.GDE_9595buttonObjects2_1final.push(gdjs.SchoolCode.GDE_9595buttonObjects3[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.SchoolCode.GDE_9595buttonObjects2_1final, gdjs.SchoolCode.GDE_9595buttonObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(16)) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(18)) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("misionstate"), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29125636);
}
}
}
}
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "door-open-46756_nnWlox72.mp3", false, 100, 1);
}
{ //Subevents
gdjs.SchoolCode.eventsList5(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("doors"), gdjs.SchoolCode.GDdoorsObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects2);
gdjs.SchoolCode.GDE_9595buttonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects, gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDdoorsObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDdoorsObjects2.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDdoorsObjects2[i].getVariableString(gdjs.SchoolCode.GDdoorsObjects2[i].getVariables().getFromIndex(0)) == "01" ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDdoorsObjects2[k] = gdjs.SchoolCode.GDdoorsObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDdoorsObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.SchoolCode.GDE_9595buttonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.SchoolCode.GDE_9595buttonObjects3);
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDE_9595buttonObjects3.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDE_9595buttonObjects3[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.SchoolCode.GDE_9595buttonObjects3[k] = gdjs.SchoolCode.GDE_9595buttonObjects3[i];
        ++k;
    }
}
gdjs.SchoolCode.GDE_9595buttonObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.SchoolCode.GDE_9595buttonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.SchoolCode.GDE_9595buttonObjects2_1final.indexOf(gdjs.SchoolCode.GDE_9595buttonObjects3[j]) === -1 )
            gdjs.SchoolCode.GDE_9595buttonObjects2_1final.push(gdjs.SchoolCode.GDE_9595buttonObjects3[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.SchoolCode.GDE_9595buttonObjects2_1final, gdjs.SchoolCode.GDE_9595buttonObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(16)) == 1);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29128420);
}
}
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "door-open-46756_nnWlox72.mp3", false, 100, 1);
}
{ //Subevents
gdjs.SchoolCode.eventsList8(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("doors"), gdjs.SchoolCode.GDdoorsObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects2);
gdjs.SchoolCode.GDE_9595buttonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects, gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDdoorsObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDdoorsObjects2.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDdoorsObjects2[i].getVariableString(gdjs.SchoolCode.GDdoorsObjects2[i].getVariables().getFromIndex(0)) == "01" ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDdoorsObjects2[k] = gdjs.SchoolCode.GDdoorsObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDdoorsObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.SchoolCode.GDE_9595buttonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.SchoolCode.GDE_9595buttonObjects3);
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDE_9595buttonObjects3.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDE_9595buttonObjects3[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.SchoolCode.GDE_9595buttonObjects3[k] = gdjs.SchoolCode.GDE_9595buttonObjects3[i];
        ++k;
    }
}
gdjs.SchoolCode.GDE_9595buttonObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.SchoolCode.GDE_9595buttonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.SchoolCode.GDE_9595buttonObjects2_1final.indexOf(gdjs.SchoolCode.GDE_9595buttonObjects3[j]) === -1 )
            gdjs.SchoolCode.GDE_9595buttonObjects2_1final.push(gdjs.SchoolCode.GDE_9595buttonObjects3[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.SchoolCode.GDE_9595buttonObjects2_1final, gdjs.SchoolCode.GDE_9595buttonObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("misionstate"), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(16)) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29132364);
}
}
}
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "door-open-46756_nnWlox72.mp3", false, 100, 1);
}
{ //Subevents
gdjs.SchoolCode.eventsList11(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("doors"), gdjs.SchoolCode.GDdoorsObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects2);
gdjs.SchoolCode.GDE_9595buttonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects, gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDdoorsObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDdoorsObjects2.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDdoorsObjects2[i].getVariableString(gdjs.SchoolCode.GDdoorsObjects2[i].getVariables().getFromIndex(0)) == "03" ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDdoorsObjects2[k] = gdjs.SchoolCode.GDdoorsObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDdoorsObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.SchoolCode.GDE_9595buttonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.SchoolCode.GDE_9595buttonObjects3);
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDE_9595buttonObjects3.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDE_9595buttonObjects3[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.SchoolCode.GDE_9595buttonObjects3[k] = gdjs.SchoolCode.GDE_9595buttonObjects3[i];
        ++k;
    }
}
gdjs.SchoolCode.GDE_9595buttonObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.SchoolCode.GDE_9595buttonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.SchoolCode.GDE_9595buttonObjects2_1final.indexOf(gdjs.SchoolCode.GDE_9595buttonObjects3[j]) === -1 )
            gdjs.SchoolCode.GDE_9595buttonObjects2_1final.push(gdjs.SchoolCode.GDE_9595buttonObjects3[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.SchoolCode.GDE_9595buttonObjects2_1final, gdjs.SchoolCode.GDE_9595buttonObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(16)) == 1);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29135516);
}
}
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "door-open-46756_nnWlox72.mp3", false, 100, 1);
}
{ //Subevents
gdjs.SchoolCode.eventsList14(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("doors"), gdjs.SchoolCode.GDdoorsObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects2);
gdjs.SchoolCode.GDE_9595buttonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects, gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDdoorsObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDdoorsObjects2.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDdoorsObjects2[i].getVariableString(gdjs.SchoolCode.GDdoorsObjects2[i].getVariables().getFromIndex(0)) == "03" ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDdoorsObjects2[k] = gdjs.SchoolCode.GDdoorsObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDdoorsObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.SchoolCode.GDE_9595buttonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.SchoolCode.GDE_9595buttonObjects3);
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDE_9595buttonObjects3.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDE_9595buttonObjects3[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.SchoolCode.GDE_9595buttonObjects3[k] = gdjs.SchoolCode.GDE_9595buttonObjects3[i];
        ++k;
    }
}
gdjs.SchoolCode.GDE_9595buttonObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.SchoolCode.GDE_9595buttonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.SchoolCode.GDE_9595buttonObjects2_1final.indexOf(gdjs.SchoolCode.GDE_9595buttonObjects3[j]) === -1 )
            gdjs.SchoolCode.GDE_9595buttonObjects2_1final.push(gdjs.SchoolCode.GDE_9595buttonObjects3[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.SchoolCode.GDE_9595buttonObjects2_1final, gdjs.SchoolCode.GDE_9595buttonObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("misionstate"), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(16)) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29138924);
}
}
}
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "door-open-46756_nnWlox72.mp3", false, 100, 1);
}
{ //Subevents
gdjs.SchoolCode.eventsList17(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("doors"), gdjs.SchoolCode.GDdoorsObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects2);
gdjs.SchoolCode.GDE_9595buttonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects, gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDdoorsObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDdoorsObjects2.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDdoorsObjects2[i].getVariableString(gdjs.SchoolCode.GDdoorsObjects2[i].getVariables().getFromIndex(0)) == "02" ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDdoorsObjects2[k] = gdjs.SchoolCode.GDdoorsObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDdoorsObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.SchoolCode.GDE_9595buttonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.SchoolCode.GDE_9595buttonObjects3);
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDE_9595buttonObjects3.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDE_9595buttonObjects3[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.SchoolCode.GDE_9595buttonObjects3[k] = gdjs.SchoolCode.GDE_9595buttonObjects3[i];
        ++k;
    }
}
gdjs.SchoolCode.GDE_9595buttonObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.SchoolCode.GDE_9595buttonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.SchoolCode.GDE_9595buttonObjects2_1final.indexOf(gdjs.SchoolCode.GDE_9595buttonObjects3[j]) === -1 )
            gdjs.SchoolCode.GDE_9595buttonObjects2_1final.push(gdjs.SchoolCode.GDE_9595buttonObjects3[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.SchoolCode.GDE_9595buttonObjects2_1final, gdjs.SchoolCode.GDE_9595buttonObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(16)) == 1);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29142572);
}
}
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "door-open-46756_nnWlox72.mp3", false, 100, 1);
}
{ //Subevents
gdjs.SchoolCode.eventsList20(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("doors"), gdjs.SchoolCode.GDdoorsObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects2);
gdjs.SchoolCode.GDE_9595buttonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects, gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDdoorsObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDdoorsObjects2.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDdoorsObjects2[i].getVariableString(gdjs.SchoolCode.GDdoorsObjects2[i].getVariables().getFromIndex(0)) == "02" ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDdoorsObjects2[k] = gdjs.SchoolCode.GDdoorsObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDdoorsObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.SchoolCode.GDE_9595buttonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.SchoolCode.GDE_9595buttonObjects3);
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDE_9595buttonObjects3.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDE_9595buttonObjects3[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.SchoolCode.GDE_9595buttonObjects3[k] = gdjs.SchoolCode.GDE_9595buttonObjects3[i];
        ++k;
    }
}
gdjs.SchoolCode.GDE_9595buttonObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.SchoolCode.GDE_9595buttonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.SchoolCode.GDE_9595buttonObjects2_1final.indexOf(gdjs.SchoolCode.GDE_9595buttonObjects3[j]) === -1 )
            gdjs.SchoolCode.GDE_9595buttonObjects2_1final.push(gdjs.SchoolCode.GDE_9595buttonObjects3[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.SchoolCode.GDE_9595buttonObjects2_1final, gdjs.SchoolCode.GDE_9595buttonObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("misionstate"), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(16)) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29146324);
}
}
}
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "door-open-46756_nnWlox72.mp3", false, 100, 1);
}
{ //Subevents
gdjs.SchoolCode.eventsList23(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("area"), gdjs.SchoolCode.GDareaObjects2);
gdjs.copyArray(runtimeScene.getObjects("doors"), gdjs.SchoolCode.GDdoorsObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects2);
gdjs.SchoolCode.GDE_9595buttonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects, gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDdoorsObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDareaObjects2Objects, gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDdoorsObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDdoorsObjects2.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDdoorsObjects2[i].getVariableString(gdjs.SchoolCode.GDdoorsObjects2[i].getVariables().getFromIndex(0)) == "02" ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDdoorsObjects2[k] = gdjs.SchoolCode.GDdoorsObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDdoorsObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.SchoolCode.GDE_9595buttonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.SchoolCode.GDE_9595buttonObjects3);
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDE_9595buttonObjects3.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDE_9595buttonObjects3[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.SchoolCode.GDE_9595buttonObjects3[k] = gdjs.SchoolCode.GDE_9595buttonObjects3[i];
        ++k;
    }
}
gdjs.SchoolCode.GDE_9595buttonObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.SchoolCode.GDE_9595buttonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.SchoolCode.GDE_9595buttonObjects2_1final.indexOf(gdjs.SchoolCode.GDE_9595buttonObjects3[j]) === -1 )
            gdjs.SchoolCode.GDE_9595buttonObjects2_1final.push(gdjs.SchoolCode.GDE_9595buttonObjects3[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.SchoolCode.GDE_9595buttonObjects2_1final, gdjs.SchoolCode.GDE_9595buttonObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(16)) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29149852);
}
}
}
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "door-open-46756_nnWlox72.mp3", false, 100, 1);
}
{ //Subevents
gdjs.SchoolCode.eventsList26(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("doors"), gdjs.SchoolCode.GDdoorsObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects2);
gdjs.SchoolCode.GDE_9595buttonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects, gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDdoorsObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDdoorsObjects2.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDdoorsObjects2[i].getVariableString(gdjs.SchoolCode.GDdoorsObjects2[i].getVariables().getFromIndex(0)) == "04" ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDdoorsObjects2[k] = gdjs.SchoolCode.GDdoorsObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDdoorsObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.SchoolCode.GDE_9595buttonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.SchoolCode.GDE_9595buttonObjects3);
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDE_9595buttonObjects3.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDE_9595buttonObjects3[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.SchoolCode.GDE_9595buttonObjects3[k] = gdjs.SchoolCode.GDE_9595buttonObjects3[i];
        ++k;
    }
}
gdjs.SchoolCode.GDE_9595buttonObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.SchoolCode.GDE_9595buttonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.SchoolCode.GDE_9595buttonObjects2_1final.indexOf(gdjs.SchoolCode.GDE_9595buttonObjects3[j]) === -1 )
            gdjs.SchoolCode.GDE_9595buttonObjects2_1final.push(gdjs.SchoolCode.GDE_9595buttonObjects3[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.SchoolCode.GDE_9595buttonObjects2_1final, gdjs.SchoolCode.GDE_9595buttonObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(16)) == 1);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29152444);
}
}
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "door-open-46756_nnWlox72.mp3", false, 100, 1);
}
{ //Subevents
gdjs.SchoolCode.eventsList29(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("doors"), gdjs.SchoolCode.GDdoorsObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects2);
gdjs.SchoolCode.GDE_9595buttonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects, gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDdoorsObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDdoorsObjects2.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDdoorsObjects2[i].getVariableString(gdjs.SchoolCode.GDdoorsObjects2[i].getVariables().getFromIndex(0)) == "04" ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDdoorsObjects2[k] = gdjs.SchoolCode.GDdoorsObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDdoorsObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.SchoolCode.GDE_9595buttonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.SchoolCode.GDE_9595buttonObjects3);
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDE_9595buttonObjects3.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDE_9595buttonObjects3[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.SchoolCode.GDE_9595buttonObjects3[k] = gdjs.SchoolCode.GDE_9595buttonObjects3[i];
        ++k;
    }
}
gdjs.SchoolCode.GDE_9595buttonObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.SchoolCode.GDE_9595buttonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.SchoolCode.GDE_9595buttonObjects2_1final.indexOf(gdjs.SchoolCode.GDE_9595buttonObjects3[j]) === -1 )
            gdjs.SchoolCode.GDE_9595buttonObjects2_1final.push(gdjs.SchoolCode.GDE_9595buttonObjects3[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.SchoolCode.GDE_9595buttonObjects2_1final, gdjs.SchoolCode.GDE_9595buttonObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(16)) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("misionstate"), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29155876);
}
}
}
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "door-open-46756_nnWlox72.mp3", false, 100, 1);
}
{ //Subevents
gdjs.SchoolCode.eventsList32(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("area"), gdjs.SchoolCode.GDareaObjects2);
gdjs.copyArray(runtimeScene.getObjects("doors"), gdjs.SchoolCode.GDdoorsObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects2);
gdjs.SchoolCode.GDE_9595buttonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects, gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDdoorsObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDareaObjects2Objects, gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDdoorsObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDareaObjects2Objects, gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDdoorsObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDdoorsObjects2.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDdoorsObjects2[i].getVariableString(gdjs.SchoolCode.GDdoorsObjects2[i].getVariables().getFromIndex(0)) == "04" ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDdoorsObjects2[k] = gdjs.SchoolCode.GDdoorsObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDdoorsObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.SchoolCode.GDE_9595buttonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.SchoolCode.GDE_9595buttonObjects3);
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDE_9595buttonObjects3.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDE_9595buttonObjects3[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.SchoolCode.GDE_9595buttonObjects3[k] = gdjs.SchoolCode.GDE_9595buttonObjects3[i];
        ++k;
    }
}
gdjs.SchoolCode.GDE_9595buttonObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.SchoolCode.GDE_9595buttonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.SchoolCode.GDE_9595buttonObjects2_1final.indexOf(gdjs.SchoolCode.GDE_9595buttonObjects3[j]) === -1 )
            gdjs.SchoolCode.GDE_9595buttonObjects2_1final.push(gdjs.SchoolCode.GDE_9595buttonObjects3[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.SchoolCode.GDE_9595buttonObjects2_1final, gdjs.SchoolCode.GDE_9595buttonObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(16)) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29161196);
}
}
}
}
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "door-open-46756_nnWlox72.mp3", false, 100, 1);
}
{ //Subevents
gdjs.SchoolCode.eventsList35(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("doors"), gdjs.SchoolCode.GDdoorsObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects, gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDdoorsObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29163340);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewBitmapText"), gdjs.SchoolCode.GDNewBitmapTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("task_bar"), gdjs.SchoolCode.GDtask_9595barObjects2);
{for(var i = 0, len = gdjs.SchoolCode.GDtask_9595barObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDtask_9595barObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.SchoolCode.GDNewBitmapTextObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDNewBitmapTextObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.SchoolCode.GDNewBitmapTextObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDNewBitmapTextObjects2[i].getBehavior("Text").setText("Enter?");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("doors"), gdjs.SchoolCode.GDdoorsObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects1Objects, gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDdoorsObjects1Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29164572);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewBitmapText"), gdjs.SchoolCode.GDNewBitmapTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("task_bar"), gdjs.SchoolCode.GDtask_9595barObjects1);
{for(var i = 0, len = gdjs.SchoolCode.GDtask_9595barObjects1.length ;i < len;++i) {
    gdjs.SchoolCode.GDtask_9595barObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.SchoolCode.GDNewBitmapTextObjects1.length ;i < len;++i) {
    gdjs.SchoolCode.GDNewBitmapTextObjects1[i].hide();
}
}}

}


};gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDnote2Objects2Objects = Hashtable.newFrom({"note2": gdjs.SchoolCode.GDnote2Objects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDnote2Objects2Objects = Hashtable.newFrom({"note2": gdjs.SchoolCode.GDnote2Objects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDcloseObjects1Objects = Hashtable.newFrom({"close": gdjs.SchoolCode.GDcloseObjects1});
gdjs.SchoolCode.eventsList37 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("note2"), gdjs.SchoolCode.GDnote2Objects2);
gdjs.copyArray(runtimeScene.getObjects("wallobject"), gdjs.SchoolCode.GDwallobjectObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDnote2Objects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDnote2Objects2.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDnote2Objects2[i].getVariableNumber(gdjs.SchoolCode.GDnote2Objects2[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDnote2Objects2[k] = gdjs.SchoolCode.GDnote2Objects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDnote2Objects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "note"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDwallobjectObjects2.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDwallobjectObjects2[i].getBehavior("Animation").getAnimationIndex() >= 20 ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDwallobjectObjects2[k] = gdjs.SchoolCode.GDwallobjectObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDwallobjectObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29166380);
}
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("colors"), gdjs.SchoolCode.GDcolorsObjects2);
gdjs.copyArray(runtimeScene.getObjects("notes"), gdjs.SchoolCode.GDnotesObjects2);
/* Reuse gdjs.SchoolCode.GDwallobjectObjects2 */
{gdjs.evtTools.camera.showLayer(runtimeScene, "note");
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 0);
}{for(var i = 0, len = gdjs.SchoolCode.GDnotesObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDnotesObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.SchoolCode.GDcolorsObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDcolorsObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.SchoolCode.GDwallobjectObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDwallobjectObjects2[i].hide(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("note2"), gdjs.SchoolCode.GDnote2Objects2);
gdjs.copyArray(runtimeScene.getObjects("wallobject"), gdjs.SchoolCode.GDwallobjectObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDnote2Objects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDnote2Objects2.length;i<l;++i) {
    if ( !(gdjs.SchoolCode.GDnote2Objects2[i].getVariableNumber(gdjs.SchoolCode.GDnote2Objects2[i].getVariables().getFromIndex(0)) == 0) ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDnote2Objects2[k] = gdjs.SchoolCode.GDnote2Objects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDnote2Objects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "note"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDwallobjectObjects2.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDwallobjectObjects2[i].getBehavior("Animation").getAnimationIndex() >= 20 ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDwallobjectObjects2[k] = gdjs.SchoolCode.GDwallobjectObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDwallobjectObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29168084);
}
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("colors"), gdjs.SchoolCode.GDcolorsObjects2);
/* Reuse gdjs.SchoolCode.GDnote2Objects2 */
gdjs.copyArray(runtimeScene.getObjects("notes"), gdjs.SchoolCode.GDnotesObjects2);
/* Reuse gdjs.SchoolCode.GDwallobjectObjects2 */
{gdjs.evtTools.camera.showLayer(runtimeScene, "note");
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 0);
}{for(var i = 0, len = gdjs.SchoolCode.GDcolorsObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDcolorsObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.SchoolCode.GDwallobjectObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDwallobjectObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.SchoolCode.GDnotesObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDnotesObjects2[i].hide(false);
}
}{gdjs.dialogueTree.startFrom("Note-" + ((gdjs.SchoolCode.GDnote2Objects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.SchoolCode.GDnote2Objects2[0].getVariables()).getFromIndex(0).getAsString());
}{for(var i = 0, len = gdjs.SchoolCode.GDnotesObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDnotesObjects2[i].getBehavior("Text").setText(gdjs.dialogueTree.getBranchText());
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("close"), gdjs.SchoolCode.GDcloseObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDcloseObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "note");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29170796);
}
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "note");
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 1);
}}

}


};gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDcharecters22Objects2Objects = Hashtable.newFrom({"charecters22": gdjs.SchoolCode.GDcharecters22Objects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDhitboxObjects2Objects = Hashtable.newFrom({"hitbox": gdjs.SchoolCode.GDhitboxObjects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDhitboxObjects2Objects = Hashtable.newFrom({"hitbox": gdjs.SchoolCode.GDhitboxObjects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDcharecters22Objects2Objects = Hashtable.newFrom({"charecters22": gdjs.SchoolCode.GDcharecters22Objects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDWallObjects2Objects = Hashtable.newFrom({"Wall": gdjs.SchoolCode.GDWallObjects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDWallObjects2Objects = Hashtable.newFrom({"Wall": gdjs.SchoolCode.GDWallObjects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDcharecters22Objects4Objects = Hashtable.newFrom({"charecters22": gdjs.SchoolCode.GDcharecters22Objects4});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDcharecters22Objects4Objects = Hashtable.newFrom({"charecters22": gdjs.SchoolCode.GDcharecters22Objects4});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDcharecters22Objects4Objects = Hashtable.newFrom({"charecters22": gdjs.SchoolCode.GDcharecters22Objects4});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDcharecters22Objects4Objects = Hashtable.newFrom({"charecters22": gdjs.SchoolCode.GDcharecters22Objects4});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDcharecters22Objects4Objects = Hashtable.newFrom({"charecters22": gdjs.SchoolCode.GDcharecters22Objects4});
gdjs.SchoolCode.eventsList38 = function(runtimeScene) {

};gdjs.SchoolCode.eventsList39 = function(runtimeScene) {

{


const repeatCount4 = 3;
for (let repeatIndex4 = 0;repeatIndex4 < repeatCount4;++repeatIndex4) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects4);
gdjs.SchoolCode.GDcharecters22Objects4.length = 0;


let isConditionTrue_0 = false;
if (true)
{
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDcharecters22Objects4Objects, (( gdjs.SchoolCode.GDplayerObjects4.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects4[0].getPointX("")), (( gdjs.SchoolCode.GDplayerObjects4.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects4[0].getPointY("")) + 8 * gdjs.SchoolCode.localVariables[0].getFromIndex(0).getAsNumber(), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDcharecters22Objects4Objects, (( gdjs.SchoolCode.GDplayerObjects4.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects4[0].getPointX("")), (( gdjs.SchoolCode.GDplayerObjects4.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects4[0].getPointY("")) + 8 * gdjs.SchoolCode.localVariables[0].getFromIndex(0).getAsNumber(), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDcharecters22Objects4Objects, (( gdjs.SchoolCode.GDplayerObjects4.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects4[0].getPointX("")), (( gdjs.SchoolCode.GDplayerObjects4.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects4[0].getPointY("")) + 8 * gdjs.SchoolCode.localVariables[0].getFromIndex(0).getAsNumber(), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDcharecters22Objects4Objects, (( gdjs.SchoolCode.GDplayerObjects4.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects4[0].getPointX("")), (( gdjs.SchoolCode.GDplayerObjects4.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects4[0].getPointY("")) + 8 * gdjs.SchoolCode.localVariables[0].getFromIndex(0).getAsNumber(), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDcharecters22Objects4Objects, (( gdjs.SchoolCode.GDplayerObjects4.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects4[0].getPointX("")), (( gdjs.SchoolCode.GDplayerObjects4.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects4[0].getPointY("")) + 8 * gdjs.SchoolCode.localVariables[0].getFromIndex(0).getAsNumber(), "");
}{gdjs.SchoolCode.localVariables[0].getFromIndex(0).add(1);
}{for(var i = 0, len = gdjs.SchoolCode.GDcharecters22Objects4.length ;i < len;++i) {
    gdjs.SchoolCode.GDcharecters22Objects4[i].setZOrder(6);
}
}}
}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDcharecters22Objects4Objects = Hashtable.newFrom({"charecters22": gdjs.SchoolCode.GDcharecters22Objects4});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDcharecters22Objects4Objects = Hashtable.newFrom({"charecters22": gdjs.SchoolCode.GDcharecters22Objects4});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDcharecters22Objects4Objects = Hashtable.newFrom({"charecters22": gdjs.SchoolCode.GDcharecters22Objects4});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDcharecters22Objects4Objects = Hashtable.newFrom({"charecters22": gdjs.SchoolCode.GDcharecters22Objects4});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDcharecters22Objects4Objects = Hashtable.newFrom({"charecters22": gdjs.SchoolCode.GDcharecters22Objects4});
gdjs.SchoolCode.eventsList40 = function(runtimeScene) {

};gdjs.SchoolCode.eventsList41 = function(runtimeScene) {

{


const repeatCount4 = 3;
for (let repeatIndex4 = 0;repeatIndex4 < repeatCount4;++repeatIndex4) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects4);
gdjs.SchoolCode.GDcharecters22Objects4.length = 0;


let isConditionTrue_0 = false;
if (true)
{
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDcharecters22Objects4Objects, (( gdjs.SchoolCode.GDplayerObjects4.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects4[0].getPointX("")), (( gdjs.SchoolCode.GDplayerObjects4.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects4[0].getPointY("")) + 8 * gdjs.SchoolCode.localVariables[0].getFromIndex(0).getAsNumber(), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDcharecters22Objects4Objects, (( gdjs.SchoolCode.GDplayerObjects4.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects4[0].getPointX("")), (( gdjs.SchoolCode.GDplayerObjects4.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects4[0].getPointY("")) + 8 * gdjs.SchoolCode.localVariables[0].getFromIndex(0).getAsNumber(), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDcharecters22Objects4Objects, (( gdjs.SchoolCode.GDplayerObjects4.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects4[0].getPointX("")), (( gdjs.SchoolCode.GDplayerObjects4.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects4[0].getPointY("")) + 8 * gdjs.SchoolCode.localVariables[0].getFromIndex(0).getAsNumber(), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDcharecters22Objects4Objects, (( gdjs.SchoolCode.GDplayerObjects4.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects4[0].getPointX("")), (( gdjs.SchoolCode.GDplayerObjects4.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects4[0].getPointY("")) + 8 * gdjs.SchoolCode.localVariables[0].getFromIndex(0).getAsNumber(), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDcharecters22Objects4Objects, (( gdjs.SchoolCode.GDplayerObjects4.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects4[0].getPointX("")), (( gdjs.SchoolCode.GDplayerObjects4.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects4[0].getPointY("")) + 8 * gdjs.SchoolCode.localVariables[0].getFromIndex(0).getAsNumber(), "");
}{gdjs.SchoolCode.localVariables[0].getFromIndex(0).add(1);
}{for(var i = 0, len = gdjs.SchoolCode.GDcharecters22Objects4.length ;i < len;++i) {
    gdjs.SchoolCode.GDcharecters22Objects4[i].setZOrder(6);
}
}}
}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDcharecters22Objects4Objects = Hashtable.newFrom({"charecters22": gdjs.SchoolCode.GDcharecters22Objects4});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDcharecters22Objects4Objects = Hashtable.newFrom({"charecters22": gdjs.SchoolCode.GDcharecters22Objects4});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDcharecters22Objects4Objects = Hashtable.newFrom({"charecters22": gdjs.SchoolCode.GDcharecters22Objects4});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDcharecters22Objects4Objects = Hashtable.newFrom({"charecters22": gdjs.SchoolCode.GDcharecters22Objects4});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDcharecters22Objects4Objects = Hashtable.newFrom({"charecters22": gdjs.SchoolCode.GDcharecters22Objects4});
gdjs.SchoolCode.eventsList42 = function(runtimeScene) {

};gdjs.SchoolCode.eventsList43 = function(runtimeScene) {

{


const repeatCount4 = 3;
for (let repeatIndex4 = 0;repeatIndex4 < repeatCount4;++repeatIndex4) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects4);
gdjs.SchoolCode.GDcharecters22Objects4.length = 0;


let isConditionTrue_0 = false;
if (true)
{
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDcharecters22Objects4Objects, (( gdjs.SchoolCode.GDplayerObjects4.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects4[0].getPointX("")), (( gdjs.SchoolCode.GDplayerObjects4.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects4[0].getPointY("")) + 8 * gdjs.SchoolCode.localVariables[0].getFromIndex(0).getAsNumber(), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDcharecters22Objects4Objects, (( gdjs.SchoolCode.GDplayerObjects4.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects4[0].getPointX("")), (( gdjs.SchoolCode.GDplayerObjects4.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects4[0].getPointY("")) + 8 * gdjs.SchoolCode.localVariables[0].getFromIndex(0).getAsNumber(), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDcharecters22Objects4Objects, (( gdjs.SchoolCode.GDplayerObjects4.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects4[0].getPointX("")), (( gdjs.SchoolCode.GDplayerObjects4.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects4[0].getPointY("")) + 8 * gdjs.SchoolCode.localVariables[0].getFromIndex(0).getAsNumber(), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDcharecters22Objects4Objects, (( gdjs.SchoolCode.GDplayerObjects4.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects4[0].getPointX("")), (( gdjs.SchoolCode.GDplayerObjects4.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects4[0].getPointY("")) + 8 * gdjs.SchoolCode.localVariables[0].getFromIndex(0).getAsNumber(), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDcharecters22Objects4Objects, (( gdjs.SchoolCode.GDplayerObjects4.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects4[0].getPointX("")), (( gdjs.SchoolCode.GDplayerObjects4.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects4[0].getPointY("")) + 8 * gdjs.SchoolCode.localVariables[0].getFromIndex(0).getAsNumber(), "");
}{gdjs.SchoolCode.localVariables[0].getFromIndex(0).add(1);
}{for(var i = 0, len = gdjs.SchoolCode.GDcharecters22Objects4.length ;i < len;++i) {
    gdjs.SchoolCode.GDcharecters22Objects4[i].setZOrder(6);
}
}}
}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDcharecters22Objects4Objects = Hashtable.newFrom({"charecters22": gdjs.SchoolCode.GDcharecters22Objects4});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDcharecters22Objects4Objects = Hashtable.newFrom({"charecters22": gdjs.SchoolCode.GDcharecters22Objects4});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDcharecters22Objects4Objects = Hashtable.newFrom({"charecters22": gdjs.SchoolCode.GDcharecters22Objects4});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDcharecters22Objects4Objects = Hashtable.newFrom({"charecters22": gdjs.SchoolCode.GDcharecters22Objects4});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDcharecters22Objects4Objects = Hashtable.newFrom({"charecters22": gdjs.SchoolCode.GDcharecters22Objects4});
gdjs.SchoolCode.eventsList44 = function(runtimeScene) {

};gdjs.SchoolCode.eventsList45 = function(runtimeScene) {

{


const repeatCount4 = 3;
for (let repeatIndex4 = 0;repeatIndex4 < repeatCount4;++repeatIndex4) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects4);
gdjs.SchoolCode.GDcharecters22Objects4.length = 0;


let isConditionTrue_0 = false;
if (true)
{
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDcharecters22Objects4Objects, (( gdjs.SchoolCode.GDplayerObjects4.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects4[0].getPointX("")), (( gdjs.SchoolCode.GDplayerObjects4.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects4[0].getPointY("")) + 8 * gdjs.SchoolCode.localVariables[0].getFromIndex(0).getAsNumber(), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDcharecters22Objects4Objects, (( gdjs.SchoolCode.GDplayerObjects4.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects4[0].getPointX("")), (( gdjs.SchoolCode.GDplayerObjects4.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects4[0].getPointY("")) + 8 * gdjs.SchoolCode.localVariables[0].getFromIndex(0).getAsNumber(), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDcharecters22Objects4Objects, (( gdjs.SchoolCode.GDplayerObjects4.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects4[0].getPointX("")), (( gdjs.SchoolCode.GDplayerObjects4.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects4[0].getPointY("")) + 8 * gdjs.SchoolCode.localVariables[0].getFromIndex(0).getAsNumber(), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDcharecters22Objects4Objects, (( gdjs.SchoolCode.GDplayerObjects4.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects4[0].getPointX("")), (( gdjs.SchoolCode.GDplayerObjects4.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects4[0].getPointY("")) + 8 * gdjs.SchoolCode.localVariables[0].getFromIndex(0).getAsNumber(), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDcharecters22Objects4Objects, (( gdjs.SchoolCode.GDplayerObjects4.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects4[0].getPointX("")), (( gdjs.SchoolCode.GDplayerObjects4.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects4[0].getPointY("")) + 8 * gdjs.SchoolCode.localVariables[0].getFromIndex(0).getAsNumber(), "");
}{gdjs.SchoolCode.localVariables[0].getFromIndex(0).add(1);
}{for(var i = 0, len = gdjs.SchoolCode.GDcharecters22Objects4.length ;i < len;++i) {
    gdjs.SchoolCode.GDcharecters22Objects4[i].setZOrder(6);
}
}}
}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDcharecters22Objects2Objects = Hashtable.newFrom({"charecters22": gdjs.SchoolCode.GDcharecters22Objects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects3Objects = Hashtable.newFrom({"player": gdjs.SchoolCode.GDplayerObjects3});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDareaObjects3Objects = Hashtable.newFrom({"area": gdjs.SchoolCode.GDareaObjects3});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects3Objects = Hashtable.newFrom({"player": gdjs.SchoolCode.GDplayerObjects3});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDareaObjects3Objects = Hashtable.newFrom({"area": gdjs.SchoolCode.GDareaObjects3});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects3Objects = Hashtable.newFrom({"player": gdjs.SchoolCode.GDplayerObjects3});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDareaObjects3Objects = Hashtable.newFrom({"area": gdjs.SchoolCode.GDareaObjects3});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects3Objects = Hashtable.newFrom({"player": gdjs.SchoolCode.GDplayerObjects3});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDareaObjects3Objects = Hashtable.newFrom({"area": gdjs.SchoolCode.GDareaObjects3});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects3Objects = Hashtable.newFrom({"player": gdjs.SchoolCode.GDplayerObjects3});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDareaObjects3Objects = Hashtable.newFrom({"area": gdjs.SchoolCode.GDareaObjects3});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects3Objects = Hashtable.newFrom({"player": gdjs.SchoolCode.GDplayerObjects3});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDareaObjects3Objects = Hashtable.newFrom({"area": gdjs.SchoolCode.GDareaObjects3});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.SchoolCode.GDplayerObjects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDareaObjects2Objects = Hashtable.newFrom({"area": gdjs.SchoolCode.GDareaObjects2});
gdjs.SchoolCode.eventsList46 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("area"), gdjs.SchoolCode.GDareaObjects3);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDplayerObjects3.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDplayerObjects3[i].getBehavior("TopDownMovement").isMoving() ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDplayerObjects3[k] = gdjs.SchoolCode.GDplayerObjects3[i];
        ++k;
    }
}
gdjs.SchoolCode.GDplayerObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects3Objects, gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDareaObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDareaObjects3.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDareaObjects3[i].getX() < 3488 ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDareaObjects3[k] = gdjs.SchoolCode.GDareaObjects3[i];
        ++k;
    }
}
gdjs.SchoolCode.GDareaObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29191068);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.SchoolCode.GDareaObjects3 */
gdjs.copyArray(runtimeScene.getObjects("charecters22"), gdjs.SchoolCode.GDcharecters22Objects3);
{for(var i = 0, len = gdjs.SchoolCode.GDcharecters22Objects3.length ;i < len;++i) {
    gdjs.SchoolCode.GDcharecters22Objects3[i].clearForces();
}
}{for(var i = 0, len = gdjs.SchoolCode.GDareaObjects3.length ;i < len;++i) {
    gdjs.SchoolCode.GDareaObjects3[i].clearForces();
}
}{for(var i = 0, len = gdjs.SchoolCode.GDcharecters22Objects3.length ;i < len;++i) {
    gdjs.SchoolCode.GDcharecters22Objects3[i].addForce(96, 0, 1);
}
}{for(var i = 0, len = gdjs.SchoolCode.GDareaObjects3.length ;i < len;++i) {
    gdjs.SchoolCode.GDareaObjects3[i].addForce(96, 0, 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("area"), gdjs.SchoolCode.GDareaObjects3);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDplayerObjects3.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDplayerObjects3[i].getBehavior("TopDownMovement").isMoving() ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDplayerObjects3[k] = gdjs.SchoolCode.GDplayerObjects3[i];
        ++k;
    }
}
gdjs.SchoolCode.GDplayerObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects3Objects, gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDareaObjects3Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDplayerObjects3.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDplayerObjects3[i].getX() > (( gdjs.SchoolCode.GDareaObjects3.length === 0 ) ? 0 :gdjs.SchoolCode.GDareaObjects3[0].getCenterXInScene()) ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDplayerObjects3[k] = gdjs.SchoolCode.GDplayerObjects3[i];
        ++k;
    }
}
gdjs.SchoolCode.GDplayerObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29191908);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.SchoolCode.GDareaObjects3 */
gdjs.copyArray(runtimeScene.getObjects("charecters22"), gdjs.SchoolCode.GDcharecters22Objects3);
{for(var i = 0, len = gdjs.SchoolCode.GDcharecters22Objects3.length ;i < len;++i) {
    gdjs.SchoolCode.GDcharecters22Objects3[i].clearForces();
}
}{for(var i = 0, len = gdjs.SchoolCode.GDareaObjects3.length ;i < len;++i) {
    gdjs.SchoolCode.GDareaObjects3[i].clearForces();
}
}{for(var i = 0, len = gdjs.SchoolCode.GDcharecters22Objects3.length ;i < len;++i) {
    gdjs.SchoolCode.GDcharecters22Objects3[i].addForce(96, 0, 1);
}
}{for(var i = 0, len = gdjs.SchoolCode.GDareaObjects3.length ;i < len;++i) {
    gdjs.SchoolCode.GDareaObjects3[i].addForce(96, 0, 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("area"), gdjs.SchoolCode.GDareaObjects3);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDplayerObjects3.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDplayerObjects3[i].getBehavior("TopDownMovement").isMoving() ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDplayerObjects3[k] = gdjs.SchoolCode.GDplayerObjects3[i];
        ++k;
    }
}
gdjs.SchoolCode.GDplayerObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects3Objects, gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDareaObjects3Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDplayerObjects3.length;i<l;++i) {
    if ( !(gdjs.SchoolCode.GDplayerObjects3[i].getX() > (( gdjs.SchoolCode.GDareaObjects3.length === 0 ) ? 0 :gdjs.SchoolCode.GDareaObjects3[0].getCenterXInScene())) ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDplayerObjects3[k] = gdjs.SchoolCode.GDplayerObjects3[i];
        ++k;
    }
}
gdjs.SchoolCode.GDplayerObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29194164);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.SchoolCode.GDareaObjects3 */
gdjs.copyArray(runtimeScene.getObjects("charecters22"), gdjs.SchoolCode.GDcharecters22Objects3);
{for(var i = 0, len = gdjs.SchoolCode.GDcharecters22Objects3.length ;i < len;++i) {
    gdjs.SchoolCode.GDcharecters22Objects3[i].clearForces();
}
}{for(var i = 0, len = gdjs.SchoolCode.GDareaObjects3.length ;i < len;++i) {
    gdjs.SchoolCode.GDareaObjects3[i].clearForces();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("area"), gdjs.SchoolCode.GDareaObjects3);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDplayerObjects3.length;i<l;++i) {
    if ( !(gdjs.SchoolCode.GDplayerObjects3[i].getBehavior("TopDownMovement").isMoving()) ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDplayerObjects3[k] = gdjs.SchoolCode.GDplayerObjects3[i];
        ++k;
    }
}
gdjs.SchoolCode.GDplayerObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects3Objects, gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDareaObjects3Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDplayerObjects3.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDplayerObjects3[i].getX() > (( gdjs.SchoolCode.GDareaObjects3.length === 0 ) ? 0 :gdjs.SchoolCode.GDareaObjects3[0].getCenterXInScene()) ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDplayerObjects3[k] = gdjs.SchoolCode.GDplayerObjects3[i];
        ++k;
    }
}
gdjs.SchoolCode.GDplayerObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29195476);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.SchoolCode.GDareaObjects3 */
gdjs.copyArray(runtimeScene.getObjects("charecters22"), gdjs.SchoolCode.GDcharecters22Objects3);
{for(var i = 0, len = gdjs.SchoolCode.GDcharecters22Objects3.length ;i < len;++i) {
    gdjs.SchoolCode.GDcharecters22Objects3[i].clearForces();
}
}{for(var i = 0, len = gdjs.SchoolCode.GDareaObjects3.length ;i < len;++i) {
    gdjs.SchoolCode.GDareaObjects3[i].clearForces();
}
}{for(var i = 0, len = gdjs.SchoolCode.GDcharecters22Objects3.length ;i < len;++i) {
    gdjs.SchoolCode.GDcharecters22Objects3[i].addForce(96, 0, 1);
}
}{for(var i = 0, len = gdjs.SchoolCode.GDareaObjects3.length ;i < len;++i) {
    gdjs.SchoolCode.GDareaObjects3[i].addForce(96, 0, 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("area"), gdjs.SchoolCode.GDareaObjects3);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDplayerObjects3.length;i<l;++i) {
    if ( !(gdjs.SchoolCode.GDplayerObjects3[i].getBehavior("TopDownMovement").isMoving()) ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDplayerObjects3[k] = gdjs.SchoolCode.GDplayerObjects3[i];
        ++k;
    }
}
gdjs.SchoolCode.GDplayerObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects3Objects, gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDareaObjects3Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDplayerObjects3.length;i<l;++i) {
    if ( !(gdjs.SchoolCode.GDplayerObjects3[i].getX() > (( gdjs.SchoolCode.GDareaObjects3.length === 0 ) ? 0 :gdjs.SchoolCode.GDareaObjects3[0].getCenterXInScene())) ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDplayerObjects3[k] = gdjs.SchoolCode.GDplayerObjects3[i];
        ++k;
    }
}
gdjs.SchoolCode.GDplayerObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29196620);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.SchoolCode.GDareaObjects3 */
gdjs.copyArray(runtimeScene.getObjects("charecters22"), gdjs.SchoolCode.GDcharecters22Objects3);
{for(var i = 0, len = gdjs.SchoolCode.GDcharecters22Objects3.length ;i < len;++i) {
    gdjs.SchoolCode.GDcharecters22Objects3[i].clearForces();
}
}{for(var i = 0, len = gdjs.SchoolCode.GDareaObjects3.length ;i < len;++i) {
    gdjs.SchoolCode.GDareaObjects3[i].clearForces();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("area"), gdjs.SchoolCode.GDareaObjects3);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDplayerObjects3.length;i<l;++i) {
    if ( !(gdjs.SchoolCode.GDplayerObjects3[i].getBehavior("TopDownMovement").isMoving()) ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDplayerObjects3[k] = gdjs.SchoolCode.GDplayerObjects3[i];
        ++k;
    }
}
gdjs.SchoolCode.GDplayerObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects3Objects, gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDareaObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDplayerObjects3.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDplayerObjects3[i].getX() < (( gdjs.SchoolCode.GDareaObjects3.length === 0 ) ? 0 :gdjs.SchoolCode.GDareaObjects3[0].getCenterXInScene()) ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDplayerObjects3[k] = gdjs.SchoolCode.GDplayerObjects3[i];
        ++k;
    }
}
gdjs.SchoolCode.GDplayerObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29198460);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.SchoolCode.GDareaObjects3 */
gdjs.copyArray(runtimeScene.getObjects("charecters22"), gdjs.SchoolCode.GDcharecters22Objects3);
{for(var i = 0, len = gdjs.SchoolCode.GDcharecters22Objects3.length ;i < len;++i) {
    gdjs.SchoolCode.GDcharecters22Objects3[i].clearForces();
}
}{for(var i = 0, len = gdjs.SchoolCode.GDareaObjects3.length ;i < len;++i) {
    gdjs.SchoolCode.GDareaObjects3[i].clearForces();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("area"), gdjs.SchoolCode.GDareaObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDplayerObjects2.length;i<l;++i) {
    if ( !(gdjs.SchoolCode.GDplayerObjects2[i].getBehavior("TopDownMovement").isMoving()) ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDplayerObjects2[k] = gdjs.SchoolCode.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDplayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects, gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDareaObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDplayerObjects2.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDplayerObjects2[i].getX() > (( gdjs.SchoolCode.GDareaObjects2.length === 0 ) ? 0 :gdjs.SchoolCode.GDareaObjects2[0].getCenterXInScene()) ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDplayerObjects2[k] = gdjs.SchoolCode.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDplayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29200084);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.SchoolCode.GDareaObjects2 */
gdjs.copyArray(runtimeScene.getObjects("charecters22"), gdjs.SchoolCode.GDcharecters22Objects2);
{for(var i = 0, len = gdjs.SchoolCode.GDcharecters22Objects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDcharecters22Objects2[i].clearForces();
}
}{for(var i = 0, len = gdjs.SchoolCode.GDareaObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDareaObjects2[i].clearForces();
}
}{for(var i = 0, len = gdjs.SchoolCode.GDcharecters22Objects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDcharecters22Objects2[i].addForce(96, 0, 1);
}
}{for(var i = 0, len = gdjs.SchoolCode.GDareaObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDareaObjects2[i].addForce(96, 0, 1);
}
}}

}


};gdjs.SchoolCode.eventsList47 = function(runtimeScene) {

{


gdjs.SchoolCode.eventsList46(runtimeScene);
}


};gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.SchoolCode.GDplayerObjects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDareaObjects2Objects = Hashtable.newFrom({"area": gdjs.SchoolCode.GDareaObjects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.SchoolCode.GDplayerObjects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDareaObjects2Objects = Hashtable.newFrom({"area": gdjs.SchoolCode.GDareaObjects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.SchoolCode.GDplayerObjects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDareaObjects2Objects = Hashtable.newFrom({"area": gdjs.SchoolCode.GDareaObjects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.SchoolCode.GDplayerObjects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDareaObjects2Objects = Hashtable.newFrom({"area": gdjs.SchoolCode.GDareaObjects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.SchoolCode.GDplayerObjects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDareaObjects2Objects = Hashtable.newFrom({"area": gdjs.SchoolCode.GDareaObjects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.SchoolCode.GDplayerObjects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDareaObjects2Objects = Hashtable.newFrom({"area": gdjs.SchoolCode.GDareaObjects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.SchoolCode.GDplayerObjects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDareaObjects2Objects = Hashtable.newFrom({"area": gdjs.SchoolCode.GDareaObjects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.SchoolCode.GDplayerObjects1});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDareaObjects1Objects = Hashtable.newFrom({"area": gdjs.SchoolCode.GDareaObjects1});
gdjs.SchoolCode.eventsList48 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("area"), gdjs.SchoolCode.GDareaObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDplayerObjects2.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDplayerObjects2[i].getBehavior("TopDownMovement").isMoving() ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDplayerObjects2[k] = gdjs.SchoolCode.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDplayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects, gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDareaObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDareaObjects2.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDareaObjects2[i].getX() > 0 ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDareaObjects2[k] = gdjs.SchoolCode.GDareaObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDareaObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) == 4);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29202348);
}
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.SchoolCode.GDareaObjects2 */
gdjs.copyArray(runtimeScene.getObjects("charecters22"), gdjs.SchoolCode.GDcharecters22Objects2);
{for(var i = 0, len = gdjs.SchoolCode.GDcharecters22Objects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDcharecters22Objects2[i].clearForces();
}
}{for(var i = 0, len = gdjs.SchoolCode.GDareaObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDareaObjects2[i].clearForces();
}
}{for(var i = 0, len = gdjs.SchoolCode.GDcharecters22Objects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDcharecters22Objects2[i].addForce(-(96), 0, 1);
}
}{for(var i = 0, len = gdjs.SchoolCode.GDareaObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDareaObjects2[i].addForce(-(96), 0, 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("area"), gdjs.SchoolCode.GDareaObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDplayerObjects2.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDplayerObjects2[i].getBehavior("TopDownMovement").isMoving() ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDplayerObjects2[k] = gdjs.SchoolCode.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDplayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects, gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDareaObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDareaObjects2.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDareaObjects2[i].getX() > 500 ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDareaObjects2[k] = gdjs.SchoolCode.GDareaObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDareaObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) == 4;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29204420);
}
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.SchoolCode.GDareaObjects2 */
gdjs.copyArray(runtimeScene.getObjects("charecters22"), gdjs.SchoolCode.GDcharecters22Objects2);
{for(var i = 0, len = gdjs.SchoolCode.GDcharecters22Objects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDcharecters22Objects2[i].clearForces();
}
}{for(var i = 0, len = gdjs.SchoolCode.GDareaObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDareaObjects2[i].clearForces();
}
}{for(var i = 0, len = gdjs.SchoolCode.GDcharecters22Objects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDcharecters22Objects2[i].addForce(-(96), 0, 1);
}
}{for(var i = 0, len = gdjs.SchoolCode.GDareaObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDareaObjects2[i].addForce(-(96), 0, 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("area"), gdjs.SchoolCode.GDareaObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDplayerObjects2.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDplayerObjects2[i].getBehavior("TopDownMovement").isMoving() ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDplayerObjects2[k] = gdjs.SchoolCode.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDplayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects, gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDareaObjects2Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDplayerObjects2.length;i<l;++i) {
    if ( !(gdjs.SchoolCode.GDplayerObjects2[i].getX() > (( gdjs.SchoolCode.GDareaObjects2.length === 0 ) ? 0 :gdjs.SchoolCode.GDareaObjects2[0].getCenterXInScene())) ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDplayerObjects2[k] = gdjs.SchoolCode.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDplayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29205804);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.SchoolCode.GDareaObjects2 */
gdjs.copyArray(runtimeScene.getObjects("charecters22"), gdjs.SchoolCode.GDcharecters22Objects2);
{for(var i = 0, len = gdjs.SchoolCode.GDcharecters22Objects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDcharecters22Objects2[i].clearForces();
}
}{for(var i = 0, len = gdjs.SchoolCode.GDareaObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDareaObjects2[i].clearForces();
}
}{for(var i = 0, len = gdjs.SchoolCode.GDcharecters22Objects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDcharecters22Objects2[i].addForce(-(96), 0, 1);
}
}{for(var i = 0, len = gdjs.SchoolCode.GDareaObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDareaObjects2[i].addForce(-(96), 0, 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("area"), gdjs.SchoolCode.GDareaObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDplayerObjects2.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDplayerObjects2[i].getBehavior("TopDownMovement").isMoving() ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDplayerObjects2[k] = gdjs.SchoolCode.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDplayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects, gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDareaObjects2Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDplayerObjects2.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDplayerObjects2[i].getX() > (( gdjs.SchoolCode.GDareaObjects2.length === 0 ) ? 0 :gdjs.SchoolCode.GDareaObjects2[0].getCenterXInScene()) ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDplayerObjects2[k] = gdjs.SchoolCode.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDplayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29206964);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.SchoolCode.GDareaObjects2 */
gdjs.copyArray(runtimeScene.getObjects("charecters22"), gdjs.SchoolCode.GDcharecters22Objects2);
{for(var i = 0, len = gdjs.SchoolCode.GDcharecters22Objects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDcharecters22Objects2[i].clearForces();
}
}{for(var i = 0, len = gdjs.SchoolCode.GDareaObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDareaObjects2[i].clearForces();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("area"), gdjs.SchoolCode.GDareaObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDplayerObjects2.length;i<l;++i) {
    if ( !(gdjs.SchoolCode.GDplayerObjects2[i].getBehavior("TopDownMovement").isMoving()) ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDplayerObjects2[k] = gdjs.SchoolCode.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDplayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects, gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDareaObjects2Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDplayerObjects2.length;i<l;++i) {
    if ( !(gdjs.SchoolCode.GDplayerObjects2[i].getX() > (( gdjs.SchoolCode.GDareaObjects2.length === 0 ) ? 0 :gdjs.SchoolCode.GDareaObjects2[0].getCenterXInScene())) ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDplayerObjects2[k] = gdjs.SchoolCode.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDplayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29208780);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.SchoolCode.GDareaObjects2 */
gdjs.copyArray(runtimeScene.getObjects("charecters22"), gdjs.SchoolCode.GDcharecters22Objects2);
{for(var i = 0, len = gdjs.SchoolCode.GDcharecters22Objects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDcharecters22Objects2[i].clearForces();
}
}{for(var i = 0, len = gdjs.SchoolCode.GDareaObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDareaObjects2[i].clearForces();
}
}{for(var i = 0, len = gdjs.SchoolCode.GDcharecters22Objects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDcharecters22Objects2[i].addForce(-(96), 0, 1);
}
}{for(var i = 0, len = gdjs.SchoolCode.GDareaObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDareaObjects2[i].addForce(-(96), 0, 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("area"), gdjs.SchoolCode.GDareaObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDplayerObjects2.length;i<l;++i) {
    if ( !(gdjs.SchoolCode.GDplayerObjects2[i].getBehavior("TopDownMovement").isMoving()) ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDplayerObjects2[k] = gdjs.SchoolCode.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDplayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects, gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDareaObjects2Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDplayerObjects2.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDplayerObjects2[i].getX() > (( gdjs.SchoolCode.GDareaObjects2.length === 0 ) ? 0 :gdjs.SchoolCode.GDareaObjects2[0].getCenterXInScene()) ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDplayerObjects2[k] = gdjs.SchoolCode.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDplayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29210876);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.SchoolCode.GDareaObjects2 */
gdjs.copyArray(runtimeScene.getObjects("charecters22"), gdjs.SchoolCode.GDcharecters22Objects2);
{for(var i = 0, len = gdjs.SchoolCode.GDcharecters22Objects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDcharecters22Objects2[i].clearForces();
}
}{for(var i = 0, len = gdjs.SchoolCode.GDareaObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDareaObjects2[i].clearForces();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("area"), gdjs.SchoolCode.GDareaObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDplayerObjects2.length;i<l;++i) {
    if ( !(gdjs.SchoolCode.GDplayerObjects2[i].getBehavior("TopDownMovement").isMoving()) ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDplayerObjects2[k] = gdjs.SchoolCode.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDplayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects, gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDareaObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDplayerObjects2.length;i<l;++i) {
    if ( !(gdjs.SchoolCode.GDplayerObjects2[i].getX() < (( gdjs.SchoolCode.GDareaObjects2.length === 0 ) ? 0 :gdjs.SchoolCode.GDareaObjects2[0].getCenterXInScene())) ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDplayerObjects2[k] = gdjs.SchoolCode.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDplayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29211772);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.SchoolCode.GDareaObjects2 */
gdjs.copyArray(runtimeScene.getObjects("charecters22"), gdjs.SchoolCode.GDcharecters22Objects2);
{for(var i = 0, len = gdjs.SchoolCode.GDcharecters22Objects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDcharecters22Objects2[i].clearForces();
}
}{for(var i = 0, len = gdjs.SchoolCode.GDareaObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDareaObjects2[i].clearForces();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("area"), gdjs.SchoolCode.GDareaObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDplayerObjects1.length;i<l;++i) {
    if ( !(gdjs.SchoolCode.GDplayerObjects1[i].getBehavior("TopDownMovement").isMoving()) ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDplayerObjects1[k] = gdjs.SchoolCode.GDplayerObjects1[i];
        ++k;
    }
}
gdjs.SchoolCode.GDplayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects1Objects, gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDareaObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDplayerObjects1.length;i<l;++i) {
    if ( !(gdjs.SchoolCode.GDplayerObjects1[i].getX() > (( gdjs.SchoolCode.GDareaObjects1.length === 0 ) ? 0 :gdjs.SchoolCode.GDareaObjects1[0].getCenterXInScene())) ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDplayerObjects1[k] = gdjs.SchoolCode.GDplayerObjects1[i];
        ++k;
    }
}
gdjs.SchoolCode.GDplayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29213396);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.SchoolCode.GDareaObjects1 */
gdjs.copyArray(runtimeScene.getObjects("charecters22"), gdjs.SchoolCode.GDcharecters22Objects1);
{for(var i = 0, len = gdjs.SchoolCode.GDcharecters22Objects1.length ;i < len;++i) {
    gdjs.SchoolCode.GDcharecters22Objects1[i].clearForces();
}
}{for(var i = 0, len = gdjs.SchoolCode.GDareaObjects1.length ;i < len;++i) {
    gdjs.SchoolCode.GDareaObjects1[i].clearForces();
}
}{for(var i = 0, len = gdjs.SchoolCode.GDcharecters22Objects1.length ;i < len;++i) {
    gdjs.SchoolCode.GDcharecters22Objects1[i].addForce(-(96), 0, 1);
}
}{for(var i = 0, len = gdjs.SchoolCode.GDareaObjects1.length ;i < len;++i) {
    gdjs.SchoolCode.GDareaObjects1[i].addForce(-(96), 0, 1);
}
}}

}


};gdjs.SchoolCode.eventsList49 = function(runtimeScene) {

{


gdjs.SchoolCode.eventsList48(runtimeScene);
}


};gdjs.SchoolCode.eventsList50 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("charecters22"), gdjs.SchoolCode.GDcharecters22Objects2);
gdjs.copyArray(runtimeScene.getObjects("hitbox"), gdjs.SchoolCode.GDhitboxObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDcharecters22Objects2Objects, gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDhitboxObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.SchoolCode.GDcharecters22Objects2 */
/* Reuse gdjs.SchoolCode.GDhitboxObjects2 */
{for(var i = 0, len = gdjs.SchoolCode.GDcharecters22Objects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDcharecters22Objects2[i].separateFromObjectsList(gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDhitboxObjects2Objects, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Wall"), gdjs.SchoolCode.GDWallObjects2);
gdjs.copyArray(runtimeScene.getObjects("charecters22"), gdjs.SchoolCode.GDcharecters22Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDcharecters22Objects2Objects, gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDWallObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.SchoolCode.GDWallObjects2 */
/* Reuse gdjs.SchoolCode.GDcharecters22Objects2 */
{for(var i = 0, len = gdjs.SchoolCode.GDcharecters22Objects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDcharecters22Objects2[i].separateFromObjectsList(gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDWallObjects2Objects, false);
}
}}

}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("x", variable);
}
gdjs.SchoolCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(16)) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(gdjs.SchoolCode.localVariables[0].getFromIndex(0)) < 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("misionstate"), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29174020);
}
}
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).setBoolean(false);
}
{ //Subevents
gdjs.SchoolCode.eventsList39(runtimeScene);} //End of subevents
}
gdjs.SchoolCode.localVariables.pop();

}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("x", variable);
}
gdjs.SchoolCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(16)) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) == 2;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(gdjs.SchoolCode.localVariables[0].getFromIndex(0)) < 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("misionstate"), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29177564);
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("area"), gdjs.SchoolCode.GDareaObjects2);
{runtimeScene.getScene().getVariables().getFromIndex(0).setBoolean(true);
}{for(var i = 0, len = gdjs.SchoolCode.GDareaObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDareaObjects2[i].setPosition(0,1802);
}
}
{ //Subevents
gdjs.SchoolCode.eventsList41(runtimeScene);} //End of subevents
}
gdjs.SchoolCode.localVariables.pop();

}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("x", variable);
}
gdjs.SchoolCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(16)) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) == 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(gdjs.SchoolCode.localVariables[0].getFromIndex(0)) < 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("misionstate"), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29181396);
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("area"), gdjs.SchoolCode.GDareaObjects2);
{runtimeScene.getScene().getVariables().getFromIndex(0).setBoolean(true);
}{for(var i = 0, len = gdjs.SchoolCode.GDareaObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDareaObjects2[i].setPosition(0,1217);
}
}
{ //Subevents
gdjs.SchoolCode.eventsList43(runtimeScene);} //End of subevents
}
gdjs.SchoolCode.localVariables.pop();

}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("x", variable);
}
gdjs.SchoolCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(16)) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) == 4;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(gdjs.SchoolCode.localVariables[0].getFromIndex(0)) < 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("misionstate"), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29185340);
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("area"), gdjs.SchoolCode.GDareaObjects2);
{runtimeScene.getScene().getVariables().getFromIndex(0).setBoolean(false);
}{for(var i = 0, len = gdjs.SchoolCode.GDareaObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDareaObjects2[i].setPosition(3480,645);
}
}
{ //Subevents
gdjs.SchoolCode.eventsList45(runtimeScene);} //End of subevents
}
gdjs.SchoolCode.localVariables.pop();

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("charecters22"), gdjs.SchoolCode.GDcharecters22Objects2);
{for(var i = 0, len = gdjs.SchoolCode.GDcharecters22Objects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDcharecters22Objects2[i].separateFromObjectsList(gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDcharecters22Objects2Objects, false);
}
}{for(var i = 0, len = gdjs.SchoolCode.GDcharecters22Objects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDcharecters22Objects2[i].getBehavior("Animation").setAnimationName("regugee");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(0), true, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.SchoolCode.eventsList47(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(0), false, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.SchoolCode.eventsList49(runtimeScene);} //End of subevents
}

}


};gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.SchoolCode.GDplayerObjects1});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDdoorsObjects1Objects = Hashtable.newFrom({"doors": gdjs.SchoolCode.GDdoorsObjects1});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDareaObjects1Objects = Hashtable.newFrom({"area": gdjs.SchoolCode.GDareaObjects1});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDdoorsObjects1Objects = Hashtable.newFrom({"doors": gdjs.SchoolCode.GDdoorsObjects1});
gdjs.SchoolCode.asyncCallback29216908 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.SchoolCode.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "School", false);
}gdjs.SchoolCode.localVariables.length = 0;
}
gdjs.SchoolCode.eventsList51 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.SchoolCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.SchoolCode.asyncCallback29216908(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.SchoolCode.asyncCallback29215948 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.SchoolCode.localVariables);
gdjs.copyArray(runtimeScene.getObjects("transition"), gdjs.SchoolCode.GDtransitionObjects2);
{runtimeScene.getGame().getVariables().getFromIndex(0).setString("Bathroom-2");
}{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(3);
}{for(var i = 0, len = gdjs.SchoolCode.GDtransitionObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDtransitionObjects2[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 0.2, "Flash", "Forward", 100, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.SchoolCode.eventsList51(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.SchoolCode.localVariables.length = 0;
}
gdjs.SchoolCode.eventsList52 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.SchoolCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.SchoolCode.asyncCallback29215948(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.SchoolCode.GDplayerObjects1});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDdoorsObjects1Objects = Hashtable.newFrom({"doors": gdjs.SchoolCode.GDdoorsObjects1});
gdjs.SchoolCode.asyncCallback29220012 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.SchoolCode.localVariables);
gdjs.copyArray(runtimeScene.getObjects("area"), gdjs.SchoolCode.GDareaObjects3);
gdjs.copyArray(runtimeScene.getObjects("charecters22"), gdjs.SchoolCode.GDcharecters22Objects3);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Rooms", false);
}{runtimeScene.getGame().getVariables().getFromIndex(3).getChild("misionstate").setBoolean(true);
}{for(var i = 0, len = gdjs.SchoolCode.GDcharecters22Objects3.length ;i < len;++i) {
    gdjs.SchoolCode.GDcharecters22Objects3[i].clearForces();
}
}{for(var i = 0, len = gdjs.SchoolCode.GDareaObjects3.length ;i < len;++i) {
    gdjs.SchoolCode.GDareaObjects3[i].clearForces();
}
}gdjs.SchoolCode.localVariables.length = 0;
}
gdjs.SchoolCode.eventsList53 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.SchoolCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.SchoolCode.asyncCallback29220012(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.SchoolCode.asyncCallback29219516 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.SchoolCode.localVariables);
gdjs.copyArray(runtimeScene.getObjects("transition"), gdjs.SchoolCode.GDtransitionObjects2);
{runtimeScene.getGame().getVariables().getFromIndex(0).setString("Grandpa's");
}{for(var i = 0, len = gdjs.SchoolCode.GDtransitionObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDtransitionObjects2[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 0.2, "Flash", "Forward", 100, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.SchoolCode.eventsList53(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.SchoolCode.localVariables.length = 0;
}
gdjs.SchoolCode.eventsList54 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.SchoolCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.SchoolCode.asyncCallback29219516(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.SchoolCode.GDplayerObjects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDdoorsObjects2Objects = Hashtable.newFrom({"doors": gdjs.SchoolCode.GDdoorsObjects2});
gdjs.SchoolCode.asyncCallback29223676 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.SchoolCode.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Rooms", false);
}gdjs.SchoolCode.localVariables.length = 0;
}
gdjs.SchoolCode.eventsList55 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.SchoolCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.SchoolCode.asyncCallback29223676(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.SchoolCode.asyncCallback29223132 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.SchoolCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("doors"), gdjs.SchoolCode.GDdoorsObjects3);

gdjs.copyArray(runtimeScene.getObjects("transition"), gdjs.SchoolCode.GDtransitionObjects3);
{runtimeScene.getGame().getVariables().getFromIndex(0).setString(((gdjs.SchoolCode.GDdoorsObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.SchoolCode.GDdoorsObjects3[0].getVariables()).getFromIndex(0).getAsString());
}{for(var i = 0, len = gdjs.SchoolCode.GDtransitionObjects3.length ;i < len;++i) {
    gdjs.SchoolCode.GDtransitionObjects3[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 0.2, "Flash", "Forward", 100, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.SchoolCode.eventsList55(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.SchoolCode.localVariables.length = 0;
}
gdjs.SchoolCode.eventsList56 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.SchoolCode.localVariables);
for (const obj of gdjs.SchoolCode.GDdoorsObjects2) asyncObjectsList.addObject("doors", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.SchoolCode.asyncCallback29223132(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.SchoolCode.GDplayerObjects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDdoorsObjects2Objects = Hashtable.newFrom({"doors": gdjs.SchoolCode.GDdoorsObjects2});
gdjs.SchoolCode.asyncCallback29226652 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.SchoolCode.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Rooms", false);
}gdjs.SchoolCode.localVariables.length = 0;
}
gdjs.SchoolCode.eventsList57 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.SchoolCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.SchoolCode.asyncCallback29226652(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.SchoolCode.asyncCallback29226132 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.SchoolCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("doors"), gdjs.SchoolCode.GDdoorsObjects3);

gdjs.copyArray(runtimeScene.getObjects("transition"), gdjs.SchoolCode.GDtransitionObjects3);
{runtimeScene.getGame().getVariables().getFromIndex(0).setString(((gdjs.SchoolCode.GDdoorsObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.SchoolCode.GDdoorsObjects3[0].getVariables()).getFromIndex(0).getAsString());
}{for(var i = 0, len = gdjs.SchoolCode.GDtransitionObjects3.length ;i < len;++i) {
    gdjs.SchoolCode.GDtransitionObjects3[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 0.2, "Flash", "Forward", 100, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.SchoolCode.eventsList57(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.SchoolCode.localVariables.length = 0;
}
gdjs.SchoolCode.eventsList58 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.SchoolCode.localVariables);
for (const obj of gdjs.SchoolCode.GDdoorsObjects2) asyncObjectsList.addObject("doors", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.SchoolCode.asyncCallback29226132(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.SchoolCode.GDplayerObjects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDdoorsObjects2Objects = Hashtable.newFrom({"doors": gdjs.SchoolCode.GDdoorsObjects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.SchoolCode.GDplayerObjects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDdoorsObjects2Objects = Hashtable.newFrom({"doors": gdjs.SchoolCode.GDdoorsObjects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.SchoolCode.GDplayerObjects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDarea2Objects2Objects = Hashtable.newFrom({"area2": gdjs.SchoolCode.GDarea2Objects2});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.SchoolCode.GDplayerObjects1});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDdoorsObjects1Objects = Hashtable.newFrom({"doors": gdjs.SchoolCode.GDdoorsObjects1});
gdjs.SchoolCode.asyncCallback29234452 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.SchoolCode.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Rooms", false);
}gdjs.SchoolCode.localVariables.length = 0;
}
gdjs.SchoolCode.eventsList59 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.SchoolCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.SchoolCode.asyncCallback29234452(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.SchoolCode.asyncCallback29234052 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.SchoolCode.localVariables);
gdjs.copyArray(runtimeScene.getObjects("transition"), gdjs.SchoolCode.GDtransitionObjects2);
{runtimeScene.getGame().getVariables().getFromIndex(0).setString("Lost in time");
}{for(var i = 0, len = gdjs.SchoolCode.GDtransitionObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDtransitionObjects2[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 0.2, "Flash", "Forward", 100, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.SchoolCode.eventsList59(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.SchoolCode.localVariables.length = 0;
}
gdjs.SchoolCode.eventsList60 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.SchoolCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.SchoolCode.asyncCallback29234052(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.SchoolCode.eventsList61 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("doors"), gdjs.SchoolCode.GDdoorsObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects2);
gdjs.SchoolCode.GDE_9595buttonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects, gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDdoorsObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDdoorsObjects2.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDdoorsObjects2[i].getVariableString(gdjs.SchoolCode.GDdoorsObjects2[i].getVariables().getFromIndex(0)) == "Lift" ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDdoorsObjects2[k] = gdjs.SchoolCode.GDdoorsObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDdoorsObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.SchoolCode.GDE_9595buttonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.SchoolCode.GDE_9595buttonObjects3);
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDE_9595buttonObjects3.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDE_9595buttonObjects3[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.SchoolCode.GDE_9595buttonObjects3[k] = gdjs.SchoolCode.GDE_9595buttonObjects3[i];
        ++k;
    }
}
gdjs.SchoolCode.GDE_9595buttonObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.SchoolCode.GDE_9595buttonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.SchoolCode.GDE_9595buttonObjects2_1final.indexOf(gdjs.SchoolCode.GDE_9595buttonObjects3[j]) === -1 )
            gdjs.SchoolCode.GDE_9595buttonObjects2_1final.push(gdjs.SchoolCode.GDE_9595buttonObjects3[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.SchoolCode.GDE_9595buttonObjects2_1final, gdjs.SchoolCode.GDE_9595buttonObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(18)) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29222988);
}
}
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "door-open-46756_nnWlox72.mp3", false, 100, 1);
}
{ //Subevents
gdjs.SchoolCode.eventsList56(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("doors"), gdjs.SchoolCode.GDdoorsObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects2);
gdjs.SchoolCode.GDE_9595buttonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects, gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDdoorsObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDdoorsObjects2.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDdoorsObjects2[i].getVariableString(gdjs.SchoolCode.GDdoorsObjects2[i].getVariables().getFromIndex(0)) == "Lift" ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDdoorsObjects2[k] = gdjs.SchoolCode.GDdoorsObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDdoorsObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.SchoolCode.GDE_9595buttonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.SchoolCode.GDE_9595buttonObjects3);
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDE_9595buttonObjects3.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDE_9595buttonObjects3[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.SchoolCode.GDE_9595buttonObjects3[k] = gdjs.SchoolCode.GDE_9595buttonObjects3[i];
        ++k;
    }
}
gdjs.SchoolCode.GDE_9595buttonObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.SchoolCode.GDE_9595buttonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.SchoolCode.GDE_9595buttonObjects2_1final.indexOf(gdjs.SchoolCode.GDE_9595buttonObjects3[j]) === -1 )
            gdjs.SchoolCode.GDE_9595buttonObjects2_1final.push(gdjs.SchoolCode.GDE_9595buttonObjects3[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.SchoolCode.GDE_9595buttonObjects2_1final, gdjs.SchoolCode.GDE_9595buttonObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(18)) == 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29225468);
}
}
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "door-open-46756_nnWlox72.mp3", false, 100, 1);
}
{ //Subevents
gdjs.SchoolCode.eventsList58(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("doors"), gdjs.SchoolCode.GDdoorsObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects, gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDdoorsObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDdoorsObjects2.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDdoorsObjects2[i].getVariableString(gdjs.SchoolCode.GDdoorsObjects2[i].getVariables().getFromIndex(0)) == "Generator" ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDdoorsObjects2[k] = gdjs.SchoolCode.GDdoorsObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDdoorsObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(18)) >= 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29228092);
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewBitmapText"), gdjs.SchoolCode.GDNewBitmapTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("task_bar"), gdjs.SchoolCode.GDtask_9595barObjects2);
{for(var i = 0, len = gdjs.SchoolCode.GDtask_9595barObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDtask_9595barObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.SchoolCode.GDNewBitmapTextObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDNewBitmapTextObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.SchoolCode.GDNewBitmapTextObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDNewBitmapTextObjects2[i].getBehavior("Text").setText("Ring?");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("doors"), gdjs.SchoolCode.GDdoorsObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects2);
gdjs.SchoolCode.GDE_9595buttonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.SchoolCode.GDE_9595buttonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.SchoolCode.GDE_9595buttonObjects3);
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDE_9595buttonObjects3.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDE_9595buttonObjects3[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.SchoolCode.GDE_9595buttonObjects3[k] = gdjs.SchoolCode.GDE_9595buttonObjects3[i];
        ++k;
    }
}
gdjs.SchoolCode.GDE_9595buttonObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.SchoolCode.GDE_9595buttonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.SchoolCode.GDE_9595buttonObjects2_1final.indexOf(gdjs.SchoolCode.GDE_9595buttonObjects3[j]) === -1 )
            gdjs.SchoolCode.GDE_9595buttonObjects2_1final.push(gdjs.SchoolCode.GDE_9595buttonObjects3[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.SchoolCode.GDE_9595buttonObjects2_1final, gdjs.SchoolCode.GDE_9595buttonObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects, gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDdoorsObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDdoorsObjects2.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDdoorsObjects2[i].getVariableString(gdjs.SchoolCode.GDdoorsObjects2[i].getVariables().getFromIndex(0)) == "Generator" ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDdoorsObjects2[k] = gdjs.SchoolCode.GDdoorsObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDdoorsObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(18)) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29229964);
}
}
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Won", false);
}{runtimeScene.getGame().getVariables().getFromIndex(18).setNumber(2);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("area2"), gdjs.SchoolCode.GDarea2Objects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects2Objects, gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDarea2Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(18)) == 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29231612);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Won", false);
}{runtimeScene.getGame().getVariables().getFromIndex(18).setNumber(4);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("doors"), gdjs.SchoolCode.GDdoorsObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects1);
gdjs.SchoolCode.GDE_9595buttonObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.SchoolCode.GDE_9595buttonObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.SchoolCode.GDE_9595buttonObjects2);
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDE_9595buttonObjects2.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDE_9595buttonObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.SchoolCode.GDE_9595buttonObjects2[k] = gdjs.SchoolCode.GDE_9595buttonObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDE_9595buttonObjects2.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.SchoolCode.GDE_9595buttonObjects2.length; j < jLen ; ++j) {
        if ( gdjs.SchoolCode.GDE_9595buttonObjects1_1final.indexOf(gdjs.SchoolCode.GDE_9595buttonObjects2[j]) === -1 )
            gdjs.SchoolCode.GDE_9595buttonObjects1_1final.push(gdjs.SchoolCode.GDE_9595buttonObjects2[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.SchoolCode.GDE_9595buttonObjects1_1final, gdjs.SchoolCode.GDE_9595buttonObjects1);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects1Objects, gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDdoorsObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDdoorsObjects1.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDdoorsObjects1[i].getVariableString(gdjs.SchoolCode.GDdoorsObjects1[i].getVariables().getFromIndex(0)) == "Lost in time" ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDdoorsObjects1[k] = gdjs.SchoolCode.GDdoorsObjects1[i];
        ++k;
    }
}
gdjs.SchoolCode.GDdoorsObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(18)) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(4).getChild("Secret"), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29233332);
}
}
}
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "door-open-46756_nnWlox72.mp3", false, 100, 1);
}
{ //Subevents
gdjs.SchoolCode.eventsList60(runtimeScene);} //End of subevents
}

}


};gdjs.SchoolCode.asyncCallback29237604 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.SchoolCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("NewShapePainter"), gdjs.SchoolCode.GDNewShapePainterObjects4);

{for(var i = 0, len = gdjs.SchoolCode.GDNewShapePainterObjects4.length ;i < len;++i) {
    gdjs.SchoolCode.GDNewShapePainterObjects4[i].getBehavior("FlashTransitionPainter").PaintEffect("240;240;240", 0.1, "Flash", "Both", 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{runtimeScene.getScene().getVariables().getFromIndex(2).setBoolean(false);
}gdjs.SchoolCode.localVariables.length = 0;
}
gdjs.SchoolCode.eventsList62 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.SchoolCode.localVariables);
for (const obj of gdjs.SchoolCode.GDNewShapePainterObjects3) asyncObjectsList.addObject("NewShapePainter", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.SchoolCode.asyncCallback29237604(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.SchoolCode.asyncCallback29237316 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.SchoolCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("NewShapePainter"), gdjs.SchoolCode.GDNewShapePainterObjects3);

{for(var i = 0, len = gdjs.SchoolCode.GDNewShapePainterObjects3.length ;i < len;++i) {
    gdjs.SchoolCode.GDNewShapePainterObjects3[i].getBehavior("FlashTransitionPainter").PaintEffect("240;240;240", 0.5, "Flash", "Both", 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.SchoolCode.eventsList62(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.SchoolCode.localVariables.length = 0;
}
gdjs.SchoolCode.eventsList63 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.SchoolCode.localVariables);
for (const obj of gdjs.SchoolCode.GDNewShapePainterObjects2) asyncObjectsList.addObject("NewShapePainter", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.SchoolCode.asyncCallback29237316(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDHimaObjects3Objects = Hashtable.newFrom({"Hima": gdjs.SchoolCode.GDHimaObjects3});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDHimaObjects3Objects = Hashtable.newFrom({"Hima": gdjs.SchoolCode.GDHimaObjects3});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDLight_95959595handObjects3Objects = Hashtable.newFrom({"Light_hand": gdjs.SchoolCode.GDLight_9595handObjects3});
gdjs.SchoolCode.asyncCallback29241324 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.SchoolCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("Hima"), gdjs.SchoolCode.GDHimaObjects4);

{for(var i = 0, len = gdjs.SchoolCode.GDHimaObjects4.length ;i < len;++i) {
    gdjs.SchoolCode.GDHimaObjects4[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.SchoolCode.GDHimaObjects4.length ;i < len;++i) {
    gdjs.SchoolCode.GDHimaObjects4[i].removeTimer("die");
}
}gdjs.SchoolCode.localVariables.length = 0;
}
gdjs.SchoolCode.eventsList64 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.SchoolCode.localVariables);
for (const obj of gdjs.SchoolCode.GDHimaObjects3) asyncObjectsList.addObject("Hima", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.3), (runtimeScene) => (gdjs.SchoolCode.asyncCallback29241324(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.SchoolCode.asyncCallback29243484 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.SchoolCode.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "died", false);
}gdjs.SchoolCode.localVariables.length = 0;
}
gdjs.SchoolCode.eventsList65 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.SchoolCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.4), (runtimeScene) => (gdjs.SchoolCode.asyncCallback29243484(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.SchoolCode.eventsList66 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)) == -(2);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(2), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29239820);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects3);
gdjs.SchoolCode.GDHimaObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDHimaObjects3Objects, (( gdjs.SchoolCode.GDplayerObjects3.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects3[0].getPointX("")) + gdjs.randomInRange(-(300), 300), (( gdjs.SchoolCode.GDplayerObjects3.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects3[0].getPointY("")) + gdjs.randomInRange(-(128), 32), "");
}{for(var i = 0, len = gdjs.SchoolCode.GDHimaObjects3.length ;i < len;++i) {
    gdjs.SchoolCode.GDHimaObjects3[i].getBehavior("Resizable").setSize(32, 32);
}
}{for(var i = 0, len = gdjs.SchoolCode.GDHimaObjects3.length ;i < len;++i) {
    gdjs.SchoolCode.GDHimaObjects3[i].resetTimer("die");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Hima"), gdjs.SchoolCode.GDHimaObjects3);
gdjs.copyArray(runtimeScene.getObjects("Light_hand"), gdjs.SchoolCode.GDLight_9595handObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDHimaObjects3Objects, gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDLight_95959595handObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29240788);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.SchoolCode.eventsList64(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Hima"), gdjs.SchoolCode.GDHimaObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDHimaObjects2.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDHimaObjects2[i].getTimerElapsedTimeInSecondsOrNaN("die") >= 3 ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDHimaObjects2[k] = gdjs.SchoolCode.GDHimaObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDHimaObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29242044);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.fadeMusicVolume(runtimeScene, 1, 0, 0.5);
}{gdjs.evtTools.sound.playSound(runtimeScene, "church-temple-bell-gong-dong-sound-effect-3-241681.mp3", false, 100, 1);
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "pause");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "ui");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "Lighting");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "note");
}
{ //Subevents
gdjs.SchoolCode.eventsList65(runtimeScene);} //End of subevents
}

}


};gdjs.SchoolCode.mapOfEmptyGDLayaObjects = Hashtable.newFrom({"Laya": []});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDLayaObjects2Objects = Hashtable.newFrom({"Laya": gdjs.SchoolCode.GDLayaObjects2});
gdjs.SchoolCode.mapOfEmptyGDLayaObjects = Hashtable.newFrom({"Laya": []});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDLayaObjects2Objects = Hashtable.newFrom({"Laya": gdjs.SchoolCode.GDLayaObjects2});
gdjs.SchoolCode.mapOfEmptyGDLayaObjects = Hashtable.newFrom({"Laya": []});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDLayaObjects2Objects = Hashtable.newFrom({"Laya": gdjs.SchoolCode.GDLayaObjects2});
gdjs.SchoolCode.mapOfEmptyGDLayaObjects = Hashtable.newFrom({"Laya": []});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDLayaObjects2Objects = Hashtable.newFrom({"Laya": gdjs.SchoolCode.GDLayaObjects2});
gdjs.SchoolCode.asyncCallback29253100 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.SchoolCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("Laya"), gdjs.SchoolCode.GDLayaObjects3);

{for(var i = 0, len = gdjs.SchoolCode.GDLayaObjects3.length ;i < len;++i) {
    gdjs.SchoolCode.GDLayaObjects3[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.SchoolCode.GDLayaObjects3.length ;i < len;++i) {
    gdjs.SchoolCode.GDLayaObjects3[i].removeTimer("die");
}
}{for(var i = 0, len = gdjs.SchoolCode.GDLayaObjects3.length ;i < len;++i) {
    gdjs.SchoolCode.GDLayaObjects3[i].removeTimer("tp");
}
}gdjs.SchoolCode.localVariables.length = 0;
}
gdjs.SchoolCode.eventsList67 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.SchoolCode.localVariables);
for (const obj of gdjs.SchoolCode.GDLayaObjects2) asyncObjectsList.addObject("Laya", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.3), (runtimeScene) => (gdjs.SchoolCode.asyncCallback29253100(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.SchoolCode.GDplayerObjects1});
gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDLayaObjects1Objects = Hashtable.newFrom({"Laya": gdjs.SchoolCode.GDLayaObjects1});
gdjs.SchoolCode.asyncCallback29261940 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.SchoolCode.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Main Menu", false);
}gdjs.SchoolCode.localVariables.length = 0;
}
gdjs.SchoolCode.eventsList68 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.SchoolCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.SchoolCode.asyncCallback29261940(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.SchoolCode.eventsList69 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)) == -(1);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(16)) == 1);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(2), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDplayerObjects2.length;i<l;++i) {
    if ( !(gdjs.SchoolCode.GDplayerObjects2[i].getBehavior("Flippable").isFlippedX()) ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDplayerObjects2[k] = gdjs.SchoolCode.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDplayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.SchoolCode.mapOfEmptyGDLayaObjects) < 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("misionstate"), true, false));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29245044);
}
}
}
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.SchoolCode.GDplayerObjects2 */
gdjs.SchoolCode.GDLayaObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDLayaObjects2Objects, (( gdjs.SchoolCode.GDplayerObjects2.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects2[0].getPointX("")) - 300, (( gdjs.SchoolCode.GDplayerObjects2.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects2[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.SchoolCode.GDLayaObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDLayaObjects2[i].resetTimer("die");
}
}{for(var i = 0, len = gdjs.SchoolCode.GDLayaObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDLayaObjects2[i].resetTimer("tp");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)) == -(1);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(16)) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(2), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDplayerObjects2.length;i<l;++i) {
    if ( !(gdjs.SchoolCode.GDplayerObjects2[i].getBehavior("Flippable").isFlippedX()) ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDplayerObjects2[k] = gdjs.SchoolCode.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDplayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.SchoolCode.mapOfEmptyGDLayaObjects) < 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("misionstate"), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29247244);
}
}
}
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.SchoolCode.GDplayerObjects2 */
gdjs.SchoolCode.GDLayaObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDLayaObjects2Objects, (( gdjs.SchoolCode.GDplayerObjects2.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects2[0].getPointX("")) - 300, (( gdjs.SchoolCode.GDplayerObjects2.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects2[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.SchoolCode.GDLayaObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDLayaObjects2[i].resetTimer("die");
}
}{for(var i = 0, len = gdjs.SchoolCode.GDLayaObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDLayaObjects2[i].resetTimer("tp");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)) == -(1);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(16)) == 1);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("misionstate"), true, false));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(2), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDplayerObjects2.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDplayerObjects2[i].getBehavior("Flippable").isFlippedX() ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDplayerObjects2[k] = gdjs.SchoolCode.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDplayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.SchoolCode.mapOfEmptyGDLayaObjects) < 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29249900);
}
}
}
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.SchoolCode.GDplayerObjects2 */
gdjs.SchoolCode.GDLayaObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDLayaObjects2Objects, (( gdjs.SchoolCode.GDplayerObjects2.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects2[0].getPointX("")) + 300, (( gdjs.SchoolCode.GDplayerObjects2.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects2[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.SchoolCode.GDLayaObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDLayaObjects2[i].resetTimer("die");
}
}{for(var i = 0, len = gdjs.SchoolCode.GDLayaObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDLayaObjects2[i].resetTimer("tp");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)) == -(1);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(16)) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("misionstate"), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(2), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDplayerObjects2.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDplayerObjects2[i].getBehavior("Flippable").isFlippedX() ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDplayerObjects2[k] = gdjs.SchoolCode.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDplayerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.SchoolCode.mapOfEmptyGDLayaObjects) < 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29251764);
}
}
}
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.SchoolCode.GDplayerObjects2 */
gdjs.SchoolCode.GDLayaObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDLayaObjects2Objects, (( gdjs.SchoolCode.GDplayerObjects2.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects2[0].getPointX("")) + 300, (( gdjs.SchoolCode.GDplayerObjects2.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects2[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.SchoolCode.GDLayaObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDLayaObjects2[i].resetTimer("die");
}
}{for(var i = 0, len = gdjs.SchoolCode.GDLayaObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDLayaObjects2[i].resetTimer("tp");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Laya"), gdjs.SchoolCode.GDLayaObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDLayaObjects2.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDLayaObjects2[i].getTimerElapsedTimeInSecondsOrNaN("die") >= 30 ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDLayaObjects2[k] = gdjs.SchoolCode.GDLayaObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDLayaObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29253348);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.SchoolCode.eventsList67(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Laya"), gdjs.SchoolCode.GDLayaObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDLayaObjects2.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDLayaObjects2[i].getTimerElapsedTimeInSecondsOrNaN("tp") >= gdjs.randomInRange(3, 10) ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDLayaObjects2[k] = gdjs.SchoolCode.GDLayaObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDLayaObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDLayaObjects2.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDLayaObjects2[i].getX() < (( gdjs.SchoolCode.GDplayerObjects2.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects2[0].getPointX("")) ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDLayaObjects2[k] = gdjs.SchoolCode.GDLayaObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDLayaObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29254772);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.SchoolCode.GDLayaObjects2 */
/* Reuse gdjs.SchoolCode.GDplayerObjects2 */
{gdjs.evtTools.sound.playSound(runtimeScene, "New sound effect2", false, 100, 1);
}{for(var i = 0, len = gdjs.SchoolCode.GDLayaObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDLayaObjects2[i].setX((( gdjs.SchoolCode.GDplayerObjects2.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects2[0].getPointX("")) + 300);
}
}{for(var i = 0, len = gdjs.SchoolCode.GDLayaObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDLayaObjects2[i].resetTimer("tp");
}
}{for(var i = 0, len = gdjs.SchoolCode.GDLayaObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDLayaObjects2[i].setY((( gdjs.SchoolCode.GDplayerObjects2.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects2[0].getPointY("")));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Laya"), gdjs.SchoolCode.GDLayaObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDLayaObjects2.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDLayaObjects2[i].getTimerElapsedTimeInSecondsOrNaN("tp") >= gdjs.randomInRange(3, 10) ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDLayaObjects2[k] = gdjs.SchoolCode.GDLayaObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDLayaObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDLayaObjects2.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDLayaObjects2[i].getX() > (( gdjs.SchoolCode.GDplayerObjects2.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects2[0].getPointX("")) ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDLayaObjects2[k] = gdjs.SchoolCode.GDLayaObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDLayaObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29255924);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.SchoolCode.GDLayaObjects2 */
/* Reuse gdjs.SchoolCode.GDplayerObjects2 */
{gdjs.evtTools.sound.playSound(runtimeScene, "New sound effect2", false, 100, 1);
}{for(var i = 0, len = gdjs.SchoolCode.GDLayaObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDLayaObjects2[i].setX((( gdjs.SchoolCode.GDplayerObjects2.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects2[0].getPointX("")) - 300);
}
}{for(var i = 0, len = gdjs.SchoolCode.GDLayaObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDLayaObjects2[i].resetTimer("tp");
}
}{for(var i = 0, len = gdjs.SchoolCode.GDLayaObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDLayaObjects2[i].setY((( gdjs.SchoolCode.GDplayerObjects2.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects2[0].getPointY("")));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Laya"), gdjs.SchoolCode.GDLayaObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDLayaObjects2.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDLayaObjects2[i].getX() < (( gdjs.SchoolCode.GDplayerObjects2.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects2[0].getPointX("")) ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDLayaObjects2[k] = gdjs.SchoolCode.GDLayaObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDLayaObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.SchoolCode.GDLayaObjects2 */
{for(var i = 0, len = gdjs.SchoolCode.GDLayaObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDLayaObjects2[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}{for(var i = 0, len = gdjs.SchoolCode.GDLayaObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDLayaObjects2[i].getBehavior("Flippable").flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Laya"), gdjs.SchoolCode.GDLayaObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDLayaObjects2.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDLayaObjects2[i].getY() <= (( gdjs.SchoolCode.GDplayerObjects2.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects2[0].getPointY("")) ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDLayaObjects2[k] = gdjs.SchoolCode.GDLayaObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDLayaObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.SchoolCode.GDLayaObjects2 */
{for(var i = 0, len = gdjs.SchoolCode.GDLayaObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDLayaObjects2[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Laya"), gdjs.SchoolCode.GDLayaObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDLayaObjects2.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDLayaObjects2[i].getY() >= (( gdjs.SchoolCode.GDplayerObjects2.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects2[0].getPointY("")) ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDLayaObjects2[k] = gdjs.SchoolCode.GDLayaObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDLayaObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.SchoolCode.GDLayaObjects2 */
{for(var i = 0, len = gdjs.SchoolCode.GDLayaObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDLayaObjects2[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Laya"), gdjs.SchoolCode.GDLayaObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDLayaObjects2.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDLayaObjects2[i].getX() > (( gdjs.SchoolCode.GDplayerObjects2.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects2[0].getPointX("")) ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDLayaObjects2[k] = gdjs.SchoolCode.GDLayaObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDLayaObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.SchoolCode.GDLayaObjects2 */
{for(var i = 0, len = gdjs.SchoolCode.GDLayaObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDLayaObjects2[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}{for(var i = 0, len = gdjs.SchoolCode.GDLayaObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDLayaObjects2[i].getBehavior("Flippable").flipX(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Laya"), gdjs.SchoolCode.GDLayaObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects1Objects, gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDLayaObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29260652);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.fadeMusicVolume(runtimeScene, 1, 0, 0.5);
}{gdjs.evtTools.sound.playSound(runtimeScene, "church-temple-bell-gong-dong-sound-effect-3-241681.mp3", false, 100, 1);
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "pause");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "ui");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "Lighting");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "note");
}
{ //Subevents
gdjs.SchoolCode.eventsList68(runtimeScene);} //End of subevents
}

}


};gdjs.SchoolCode.eventsList70 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("NewShapePainter"), gdjs.SchoolCode.GDNewShapePainterObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDNewShapePainterObjects2.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDNewShapePainterObjects2[i].getTimerElapsedTimeInSecondsOrNaN("lightning") >= gdjs.randomInRange(5, 15) ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDNewShapePainterObjects2[k] = gdjs.SchoolCode.GDNewShapePainterObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDNewShapePainterObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "Lighting");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29235868);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.SchoolCode.GDNewShapePainterObjects2 */
{for(var i = 0, len = gdjs.SchoolCode.GDNewShapePainterObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDNewShapePainterObjects2[i].resetTimer("lightning");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "thunder-124463.mp3", false, 100, 1);
}{runtimeScene.getScene().getVariables().getFromIndex(2).setBoolean(true);
}{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(1);
}{for(var i = 0, len = gdjs.SchoolCode.GDNewShapePainterObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDNewShapePainterObjects2[i].getBehavior("FlashTransitionPainter").PaintEffect("240;240;240", 0.1, "Flash", "Both", 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.SchoolCode.eventsList63(runtimeScene);} //End of subevents
}

}


{


gdjs.SchoolCode.eventsList66(runtimeScene);
}


{


gdjs.SchoolCode.eventsList69(runtimeScene);
}


};gdjs.SchoolCode.eventsList71 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("pause_menu"), gdjs.SchoolCode.GDpause_9595menuObjects2);
{for(var i = 0, len = gdjs.SchoolCode.GDpause_9595menuObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDpause_9595menuObjects2[i].getBehavior("Opacity").setOpacity(125);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Pause"), gdjs.SchoolCode.GDPauseObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDPauseObjects2.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDPauseObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDPauseObjects2[k] = gdjs.SchoolCode.GDPauseObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDPauseObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29263556);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.camera.showLayer(runtimeScene, "pause");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "ui");
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("resume"), gdjs.SchoolCode.GDresumeObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDresumeObjects2.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDresumeObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDresumeObjects2[k] = gdjs.SchoolCode.GDresumeObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDresumeObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29264820);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "pause");
}{gdjs.evtTools.camera.showLayer(runtimeScene, "ui");
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Quit_2"), gdjs.SchoolCode.GDQuit_95952Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDQuit_95952Objects1.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDQuit_95952Objects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDQuit_95952Objects1[k] = gdjs.SchoolCode.GDQuit_95952Objects1[i];
        ++k;
    }
}
gdjs.SchoolCode.GDQuit_95952Objects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29266100);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Main Menu", false);
}}

}


};gdjs.SchoolCode.eventsList72 = function(runtimeScene) {

{

gdjs.SchoolCode.GDJoystickObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.SchoolCode.GDJoystickObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Joystick"), gdjs.SchoolCode.GDJoystickObjects3);
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDJoystickObjects3.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDJoystickObjects3[i].IsDirectionPushed8Way("Right", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.SchoolCode.GDJoystickObjects3[k] = gdjs.SchoolCode.GDJoystickObjects3[i];
        ++k;
    }
}
gdjs.SchoolCode.GDJoystickObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.SchoolCode.GDJoystickObjects3.length; j < jLen ; ++j) {
        if ( gdjs.SchoolCode.GDJoystickObjects2_1final.indexOf(gdjs.SchoolCode.GDJoystickObjects3[j]) === -1 )
            gdjs.SchoolCode.GDJoystickObjects2_1final.push(gdjs.SchoolCode.GDJoystickObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Joystick"), gdjs.SchoolCode.GDJoystickObjects3);
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDJoystickObjects3.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDJoystickObjects3[i].IsDirectionPushed8Way("UpRight", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.SchoolCode.GDJoystickObjects3[k] = gdjs.SchoolCode.GDJoystickObjects3[i];
        ++k;
    }
}
gdjs.SchoolCode.GDJoystickObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.SchoolCode.GDJoystickObjects3.length; j < jLen ; ++j) {
        if ( gdjs.SchoolCode.GDJoystickObjects2_1final.indexOf(gdjs.SchoolCode.GDJoystickObjects3[j]) === -1 )
            gdjs.SchoolCode.GDJoystickObjects2_1final.push(gdjs.SchoolCode.GDJoystickObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Joystick"), gdjs.SchoolCode.GDJoystickObjects3);
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDJoystickObjects3.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDJoystickObjects3[i].IsDirectionPushed8Way("DownRight", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.SchoolCode.GDJoystickObjects3[k] = gdjs.SchoolCode.GDJoystickObjects3[i];
        ++k;
    }
}
gdjs.SchoolCode.GDJoystickObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.SchoolCode.GDJoystickObjects3.length; j < jLen ; ++j) {
        if ( gdjs.SchoolCode.GDJoystickObjects2_1final.indexOf(gdjs.SchoolCode.GDJoystickObjects3[j]) === -1 )
            gdjs.SchoolCode.GDJoystickObjects2_1final.push(gdjs.SchoolCode.GDJoystickObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.SchoolCode.GDJoystickObjects2_1final, gdjs.SchoolCode.GDJoystickObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29267484);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects2);
{for(var i = 0, len = gdjs.SchoolCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDplayerObjects2[i].getBehavior("Animation").setAnimationName("player-walk");
}
}{for(var i = 0, len = gdjs.SchoolCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDplayerObjects2[i].getBehavior("Flippable").flipX(false);
}
}}

}


{

gdjs.SchoolCode.GDJoystickObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.SchoolCode.GDJoystickObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Joystick"), gdjs.SchoolCode.GDJoystickObjects3);
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDJoystickObjects3.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDJoystickObjects3[i].IsDirectionPushed8Way("Left", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.SchoolCode.GDJoystickObjects3[k] = gdjs.SchoolCode.GDJoystickObjects3[i];
        ++k;
    }
}
gdjs.SchoolCode.GDJoystickObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.SchoolCode.GDJoystickObjects3.length; j < jLen ; ++j) {
        if ( gdjs.SchoolCode.GDJoystickObjects2_1final.indexOf(gdjs.SchoolCode.GDJoystickObjects3[j]) === -1 )
            gdjs.SchoolCode.GDJoystickObjects2_1final.push(gdjs.SchoolCode.GDJoystickObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Joystick"), gdjs.SchoolCode.GDJoystickObjects3);
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDJoystickObjects3.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDJoystickObjects3[i].IsDirectionPushed8Way("DownLeft", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.SchoolCode.GDJoystickObjects3[k] = gdjs.SchoolCode.GDJoystickObjects3[i];
        ++k;
    }
}
gdjs.SchoolCode.GDJoystickObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.SchoolCode.GDJoystickObjects3.length; j < jLen ; ++j) {
        if ( gdjs.SchoolCode.GDJoystickObjects2_1final.indexOf(gdjs.SchoolCode.GDJoystickObjects3[j]) === -1 )
            gdjs.SchoolCode.GDJoystickObjects2_1final.push(gdjs.SchoolCode.GDJoystickObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Joystick"), gdjs.SchoolCode.GDJoystickObjects3);
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDJoystickObjects3.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDJoystickObjects3[i].IsDirectionPushed8Way("UpLeft", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.SchoolCode.GDJoystickObjects3[k] = gdjs.SchoolCode.GDJoystickObjects3[i];
        ++k;
    }
}
gdjs.SchoolCode.GDJoystickObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.SchoolCode.GDJoystickObjects3.length; j < jLen ; ++j) {
        if ( gdjs.SchoolCode.GDJoystickObjects2_1final.indexOf(gdjs.SchoolCode.GDJoystickObjects3[j]) === -1 )
            gdjs.SchoolCode.GDJoystickObjects2_1final.push(gdjs.SchoolCode.GDJoystickObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.SchoolCode.GDJoystickObjects2_1final, gdjs.SchoolCode.GDJoystickObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29269756);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects2);
{for(var i = 0, len = gdjs.SchoolCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDplayerObjects2[i].getBehavior("Animation").setAnimationName("player-walk");
}
}{for(var i = 0, len = gdjs.SchoolCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDplayerObjects2[i].getBehavior("Flippable").flipX(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Joystick"), gdjs.SchoolCode.GDJoystickObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDJoystickObjects2.length;i<l;++i) {
    if ( !(gdjs.SchoolCode.GDJoystickObjects2[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDJoystickObjects2[k] = gdjs.SchoolCode.GDJoystickObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDJoystickObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29271044);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects2);
{for(var i = 0, len = gdjs.SchoolCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDplayerObjects2[i].getBehavior("Animation").setAnimationName("player");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.SchoolCode.GDE_9595buttonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Joystick"), gdjs.SchoolCode.GDJoystickObjects2);
{gdjs.evtTools.camera.showLayer(runtimeScene, "Mobile");
}{for(var i = 0, len = gdjs.SchoolCode.GDJoystickObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDJoystickObjects2[i].ActivateControl(true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.SchoolCode.GDE_9595buttonObjects2.length ;i < len;++i) {
    gdjs.SchoolCode.GDE_9595buttonObjects2[i].Activate(true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene));
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.SchoolCode.GDE_9595buttonObjects1);
gdjs.copyArray(runtimeScene.getObjects("Joystick"), gdjs.SchoolCode.GDJoystickObjects1);
{gdjs.evtTools.camera.hideLayer(runtimeScene, "Mobile");
}{for(var i = 0, len = gdjs.SchoolCode.GDJoystickObjects1.length ;i < len;++i) {
    gdjs.SchoolCode.GDJoystickObjects1[i].ActivateControl(false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.SchoolCode.GDE_9595buttonObjects1.length ;i < len;++i) {
    gdjs.SchoolCode.GDE_9595buttonObjects1[i].Activate(false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.SchoolCode.eventsList73 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewShapePainter"), gdjs.SchoolCode.GDNewShapePainterObjects1);
gdjs.copyArray(runtimeScene.getObjects("area"), gdjs.SchoolCode.GDareaObjects1);
gdjs.copyArray(runtimeScene.getObjects("floor_3"), gdjs.SchoolCode.GDfloor_95953Objects1);
gdjs.copyArray(runtimeScene.getObjects("hitbox"), gdjs.SchoolCode.GDhitboxObjects1);
gdjs.copyArray(runtimeScene.getObjects("task_bar"), gdjs.SchoolCode.GDtask_9595barObjects1);
gdjs.copyArray(runtimeScene.getObjects("transition"), gdjs.SchoolCode.GDtransitionObjects1);
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "rain-110508.mp3", 1, true, 65, 1);
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 2.5, "", 0);
}{gdjs.evtTools.camera.setCameraY(runtimeScene, 675, "", 0);
}{for(var i = 0, len = gdjs.SchoolCode.GDNewShapePainterObjects1.length ;i < len;++i) {
    gdjs.SchoolCode.GDNewShapePainterObjects1[i].resetTimer("lightning");
}
}{for(var i = 0, len = gdjs.SchoolCode.GDhitboxObjects1.length ;i < len;++i) {
    gdjs.SchoolCode.GDhitboxObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.SchoolCode.GDareaObjects1.length ;i < len;++i) {
    gdjs.SchoolCode.GDareaObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.SchoolCode.GDtransitionObjects1.length ;i < len;++i) {
    gdjs.SchoolCode.GDtransitionObjects1[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 0.2, "Flash", "Backward", 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.SchoolCode.GDtask_9595barObjects1.length ;i < len;++i) {
    gdjs.SchoolCode.GDtask_9595barObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.SchoolCode.GDfloor_95953Objects1.length ;i < len;++i) {
    gdjs.SchoolCode.GDfloor_95953Objects1[i].SetLabelText("Floor:" + gdjs.SchoolCode.GDfloor_95953Objects1[i].getVariables().getFromIndex(0).getAsString(), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.dialogueTree.loadFromJsonFile(runtimeScene, "lore");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "locked");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(10).getChild("blue").getAsNumber() + runtimeScene.getGame().getVariables().getFromIndex(10).getChild("green").getAsNumber() + runtimeScene.getGame().getVariables().getFromIndex(10).getChild("red").getAsNumber() == 0);
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(10).getChild("blue").setNumber(Math.round(gdjs.randomFloatInRange(0, 9)));
}{runtimeScene.getGame().getVariables().getFromIndex(10).getChild("green").setNumber(Math.round(gdjs.randomFloatInRange(0, 9)));
}{runtimeScene.getGame().getVariables().getFromIndex(10).getChild("red").setNumber(Math.round(gdjs.randomFloatInRange(0, 9)));
}{runtimeScene.getGame().getVariables().getFromIndex(15).setNumber(runtimeScene.getGame().getVariables().getFromIndex(10).getChild("green").getAsNumber() + runtimeScene.getGame().getVariables().getFromIndex(10).getChild("red").getAsNumber() * 10 + runtimeScene.getGame().getVariables().getFromIndex(10).getChild("blue").getAsNumber() * 100 + runtimeScene.getGame().getVariables().getFromIndex(10).getChild("green").getAsNumber() * 1000 + runtimeScene.getGame().getVariables().getFromIndex(10).getChild("red").getAsNumber() * 10000 + runtimeScene.getGame().getVariables().getFromIndex(10).getChild("blue").getAsNumber() * 100000 + runtimeScene.getGame().getVariables().getFromIndex(10).getChild("blue").getAsNumber() * 1000000 + runtimeScene.getGame().getVariables().getFromIndex(10).getChild("red").getAsNumber() * 10000000);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("doors"), gdjs.SchoolCode.GDdoorsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDdoorsObjects1.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDdoorsObjects1[i].getVariableString(gdjs.SchoolCode.GDdoorsObjects1[i].getVariables().getFromIndex(0)) == runtimeScene.getGame().getVariables().getFromIndex(0).getAsString() ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDdoorsObjects1[k] = gdjs.SchoolCode.GDdoorsObjects1[i];
        ++k;
    }
}
gdjs.SchoolCode.GDdoorsObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDdoorsObjects1.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDdoorsObjects1[i].getVariableNumber(gdjs.SchoolCode.GDdoorsObjects1[i].getVariables().getFromIndex(1)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDdoorsObjects1[k] = gdjs.SchoolCode.GDdoorsObjects1[i];
        ++k;
    }
}
gdjs.SchoolCode.GDdoorsObjects1.length = k;
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewParticlesEmitter"), gdjs.SchoolCode.GDNewParticlesEmitterObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewParticlesEmitter2"), gdjs.SchoolCode.GDNewParticlesEmitter2Objects1);
/* Reuse gdjs.SchoolCode.GDdoorsObjects1 */
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects1);
{for(var i = 0, len = gdjs.SchoolCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.SchoolCode.GDplayerObjects1[i].setPosition((( gdjs.SchoolCode.GDdoorsObjects1.length === 0 ) ? 0 :gdjs.SchoolCode.GDdoorsObjects1[0].getPointX("Point")),(( gdjs.SchoolCode.GDdoorsObjects1.length === 0 ) ? 0 :gdjs.SchoolCode.GDdoorsObjects1[0].getPointY("Point")) - 15);
}
}{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.SchoolCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects1[0].getPointX("")), "", 0);
}{gdjs.evtTools.camera.setCameraY(runtimeScene, (( gdjs.SchoolCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects1[0].getPointY("")), "", 0);
}{for(var i = 0, len = gdjs.SchoolCode.GDNewParticlesEmitterObjects1.length ;i < len;++i) {
    gdjs.SchoolCode.GDNewParticlesEmitterObjects1[i].setY((( gdjs.SchoolCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects1[0].getPointY("")) - 260);
}
}{for(var i = 0, len = gdjs.SchoolCode.GDNewParticlesEmitter2Objects1.length ;i < len;++i) {
    gdjs.SchoolCode.GDNewParticlesEmitter2Objects1[i].setY((( gdjs.SchoolCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects1[0].getPointY("")) - 260);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("colors"), gdjs.SchoolCode.GDcolorsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDcolorsObjects1.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDcolorsObjects1[i].getVariableNumber(gdjs.SchoolCode.GDcolorsObjects1[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDcolorsObjects1[k] = gdjs.SchoolCode.GDcolorsObjects1[i];
        ++k;
    }
}
gdjs.SchoolCode.GDcolorsObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.SchoolCode.GDcolorsObjects1 */
{for(var i = 0, len = gdjs.SchoolCode.GDcolorsObjects1.length ;i < len;++i) {
    gdjs.SchoolCode.GDcolorsObjects1[i].getBehavior("Text").setText("= " + runtimeScene.getGame().getVariables().getFromIndex(10).getChild("red").getAsString());
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("colors"), gdjs.SchoolCode.GDcolorsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDcolorsObjects1.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDcolorsObjects1[i].getVariableNumber(gdjs.SchoolCode.GDcolorsObjects1[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDcolorsObjects1[k] = gdjs.SchoolCode.GDcolorsObjects1[i];
        ++k;
    }
}
gdjs.SchoolCode.GDcolorsObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.SchoolCode.GDcolorsObjects1 */
{for(var i = 0, len = gdjs.SchoolCode.GDcolorsObjects1.length ;i < len;++i) {
    gdjs.SchoolCode.GDcolorsObjects1[i].getBehavior("Text").setText("= " + runtimeScene.getGame().getVariables().getFromIndex(10).getChild("green").getAsString());
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("colors"), gdjs.SchoolCode.GDcolorsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDcolorsObjects1.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDcolorsObjects1[i].getVariableNumber(gdjs.SchoolCode.GDcolorsObjects1[i].getVariables().getFromIndex(0)) == 2 ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDcolorsObjects1[k] = gdjs.SchoolCode.GDcolorsObjects1[i];
        ++k;
    }
}
gdjs.SchoolCode.GDcolorsObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.SchoolCode.GDcolorsObjects1 */
{for(var i = 0, len = gdjs.SchoolCode.GDcolorsObjects1.length ;i < len;++i) {
    gdjs.SchoolCode.GDcolorsObjects1[i].getBehavior("Text").setText("= " + runtimeScene.getGame().getVariables().getFromIndex(10).getChild("blue").getAsString());
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("doors"), gdjs.SchoolCode.GDdoorsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDdoorsObjects1.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDdoorsObjects1[i].getVariableString(gdjs.SchoolCode.GDdoorsObjects1[i].getVariables().getFromIndex(0)) == runtimeScene.getGame().getVariables().getFromIndex(0).getAsString() ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDdoorsObjects1[k] = gdjs.SchoolCode.GDdoorsObjects1[i];
        ++k;
    }
}
gdjs.SchoolCode.GDdoorsObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDdoorsObjects1.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDdoorsObjects1[i].getVariableNumber(gdjs.SchoolCode.GDdoorsObjects1[i].getVariables().getFromIndex(1)) == runtimeScene.getGame().getVariables().getFromIndex(1).getAsNumber() ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDdoorsObjects1[k] = gdjs.SchoolCode.GDdoorsObjects1[i];
        ++k;
    }
}
gdjs.SchoolCode.GDdoorsObjects1.length = k;
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewParticlesEmitter"), gdjs.SchoolCode.GDNewParticlesEmitterObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewParticlesEmitter2"), gdjs.SchoolCode.GDNewParticlesEmitter2Objects1);
/* Reuse gdjs.SchoolCode.GDdoorsObjects1 */
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects1);
{for(var i = 0, len = gdjs.SchoolCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.SchoolCode.GDplayerObjects1[i].setPosition((( gdjs.SchoolCode.GDdoorsObjects1.length === 0 ) ? 0 :gdjs.SchoolCode.GDdoorsObjects1[0].getPointX("Point")),(( gdjs.SchoolCode.GDdoorsObjects1.length === 0 ) ? 0 :gdjs.SchoolCode.GDdoorsObjects1[0].getPointY("Point")) - 15);
}
}{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.SchoolCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects1[0].getPointX("")), "", 0);
}{gdjs.evtTools.camera.setCameraY(runtimeScene, (( gdjs.SchoolCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects1[0].getPointY("")), "", 0);
}{for(var i = 0, len = gdjs.SchoolCode.GDNewParticlesEmitterObjects1.length ;i < len;++i) {
    gdjs.SchoolCode.GDNewParticlesEmitterObjects1[i].setY((( gdjs.SchoolCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects1[0].getPointY("")) - 260);
}
}{for(var i = 0, len = gdjs.SchoolCode.GDNewParticlesEmitter2Objects1.length ;i < len;++i) {
    gdjs.SchoolCode.GDNewParticlesEmitter2Objects1[i].setY((( gdjs.SchoolCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects1[0].getPointY("")) - 260);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("doors"), gdjs.SchoolCode.GDdoorsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "1";
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDdoorsObjects1.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDdoorsObjects1[i].getVariableNumber(gdjs.SchoolCode.GDdoorsObjects1[i].getVariables().getFromIndex(1)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDdoorsObjects1[k] = gdjs.SchoolCode.GDdoorsObjects1[i];
        ++k;
    }
}
gdjs.SchoolCode.GDdoorsObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDdoorsObjects1.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDdoorsObjects1[i].getVariableString(gdjs.SchoolCode.GDdoorsObjects1[i].getVariables().getFromIndex(0)) == "02" ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDdoorsObjects1[k] = gdjs.SchoolCode.GDdoorsObjects1[i];
        ++k;
    }
}
gdjs.SchoolCode.GDdoorsObjects1.length = k;
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewParticlesEmitter"), gdjs.SchoolCode.GDNewParticlesEmitterObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewParticlesEmitter2"), gdjs.SchoolCode.GDNewParticlesEmitter2Objects1);
/* Reuse gdjs.SchoolCode.GDdoorsObjects1 */
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects1);
{for(var i = 0, len = gdjs.SchoolCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.SchoolCode.GDplayerObjects1[i].setPosition((( gdjs.SchoolCode.GDdoorsObjects1.length === 0 ) ? 0 :gdjs.SchoolCode.GDdoorsObjects1[0].getPointX("Point")),(( gdjs.SchoolCode.GDdoorsObjects1.length === 0 ) ? 0 :gdjs.SchoolCode.GDdoorsObjects1[0].getPointY("Point")) - 15);
}
}{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.SchoolCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects1[0].getPointX("")), "", 0);
}{gdjs.evtTools.camera.setCameraY(runtimeScene, (( gdjs.SchoolCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects1[0].getPointY("")), "", 0);
}{for(var i = 0, len = gdjs.SchoolCode.GDNewParticlesEmitterObjects1.length ;i < len;++i) {
    gdjs.SchoolCode.GDNewParticlesEmitterObjects1[i].setY((( gdjs.SchoolCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects1[0].getPointY("")) - 260);
}
}{for(var i = 0, len = gdjs.SchoolCode.GDNewParticlesEmitter2Objects1.length ;i < len;++i) {
    gdjs.SchoolCode.GDNewParticlesEmitter2Objects1[i].setY((( gdjs.SchoolCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects1[0].getPointY("")) - 260);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("doors"), gdjs.SchoolCode.GDdoorsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "2";
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDdoorsObjects1.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDdoorsObjects1[i].getVariableNumber(gdjs.SchoolCode.GDdoorsObjects1[i].getVariables().getFromIndex(1)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDdoorsObjects1[k] = gdjs.SchoolCode.GDdoorsObjects1[i];
        ++k;
    }
}
gdjs.SchoolCode.GDdoorsObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDdoorsObjects1.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDdoorsObjects1[i].getVariableString(gdjs.SchoolCode.GDdoorsObjects1[i].getVariables().getFromIndex(0)) == "01" ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDdoorsObjects1[k] = gdjs.SchoolCode.GDdoorsObjects1[i];
        ++k;
    }
}
gdjs.SchoolCode.GDdoorsObjects1.length = k;
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewParticlesEmitter"), gdjs.SchoolCode.GDNewParticlesEmitterObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewParticlesEmitter2"), gdjs.SchoolCode.GDNewParticlesEmitter2Objects1);
/* Reuse gdjs.SchoolCode.GDdoorsObjects1 */
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects1);
{for(var i = 0, len = gdjs.SchoolCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.SchoolCode.GDplayerObjects1[i].setPosition((( gdjs.SchoolCode.GDdoorsObjects1.length === 0 ) ? 0 :gdjs.SchoolCode.GDdoorsObjects1[0].getPointX("Point")),(( gdjs.SchoolCode.GDdoorsObjects1.length === 0 ) ? 0 :gdjs.SchoolCode.GDdoorsObjects1[0].getPointY("Point")) - 15);
}
}{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.SchoolCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects1[0].getPointX("")), "", 0);
}{gdjs.evtTools.camera.setCameraY(runtimeScene, (( gdjs.SchoolCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects1[0].getPointY("")), "", 0);
}{for(var i = 0, len = gdjs.SchoolCode.GDNewParticlesEmitterObjects1.length ;i < len;++i) {
    gdjs.SchoolCode.GDNewParticlesEmitterObjects1[i].setY((( gdjs.SchoolCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects1[0].getPointY("")) - 260);
}
}{for(var i = 0, len = gdjs.SchoolCode.GDNewParticlesEmitter2Objects1.length ;i < len;++i) {
    gdjs.SchoolCode.GDNewParticlesEmitter2Objects1[i].setY((( gdjs.SchoolCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects1[0].getPointY("")) - 260);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("doors"), gdjs.SchoolCode.GDdoorsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "3";
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDdoorsObjects1.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDdoorsObjects1[i].getVariableNumber(gdjs.SchoolCode.GDdoorsObjects1[i].getVariables().getFromIndex(1)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDdoorsObjects1[k] = gdjs.SchoolCode.GDdoorsObjects1[i];
        ++k;
    }
}
gdjs.SchoolCode.GDdoorsObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDdoorsObjects1.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDdoorsObjects1[i].getVariableString(gdjs.SchoolCode.GDdoorsObjects1[i].getVariables().getFromIndex(0)) == "04" ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDdoorsObjects1[k] = gdjs.SchoolCode.GDdoorsObjects1[i];
        ++k;
    }
}
gdjs.SchoolCode.GDdoorsObjects1.length = k;
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewParticlesEmitter"), gdjs.SchoolCode.GDNewParticlesEmitterObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewParticlesEmitter2"), gdjs.SchoolCode.GDNewParticlesEmitter2Objects1);
/* Reuse gdjs.SchoolCode.GDdoorsObjects1 */
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects1);
{for(var i = 0, len = gdjs.SchoolCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.SchoolCode.GDplayerObjects1[i].setPosition((( gdjs.SchoolCode.GDdoorsObjects1.length === 0 ) ? 0 :gdjs.SchoolCode.GDdoorsObjects1[0].getPointX("Point")),(( gdjs.SchoolCode.GDdoorsObjects1.length === 0 ) ? 0 :gdjs.SchoolCode.GDdoorsObjects1[0].getPointY("Point")) - 15);
}
}{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.SchoolCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects1[0].getPointX("")), "", 0);
}{gdjs.evtTools.camera.setCameraY(runtimeScene, (( gdjs.SchoolCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects1[0].getPointY("")), "", 0);
}{for(var i = 0, len = gdjs.SchoolCode.GDNewParticlesEmitterObjects1.length ;i < len;++i) {
    gdjs.SchoolCode.GDNewParticlesEmitterObjects1[i].setY((( gdjs.SchoolCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects1[0].getPointY("")) - 260);
}
}{for(var i = 0, len = gdjs.SchoolCode.GDNewParticlesEmitter2Objects1.length ;i < len;++i) {
    gdjs.SchoolCode.GDNewParticlesEmitter2Objects1[i].setY((( gdjs.SchoolCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects1[0].getPointY("")) - 260);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("doors"), gdjs.SchoolCode.GDdoorsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "4";
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDdoorsObjects1.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDdoorsObjects1[i].getVariableNumber(gdjs.SchoolCode.GDdoorsObjects1[i].getVariables().getFromIndex(1)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDdoorsObjects1[k] = gdjs.SchoolCode.GDdoorsObjects1[i];
        ++k;
    }
}
gdjs.SchoolCode.GDdoorsObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDdoorsObjects1.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDdoorsObjects1[i].getVariableString(gdjs.SchoolCode.GDdoorsObjects1[i].getVariables().getFromIndex(0)) == "03" ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDdoorsObjects1[k] = gdjs.SchoolCode.GDdoorsObjects1[i];
        ++k;
    }
}
gdjs.SchoolCode.GDdoorsObjects1.length = k;
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewParticlesEmitter"), gdjs.SchoolCode.GDNewParticlesEmitterObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewParticlesEmitter2"), gdjs.SchoolCode.GDNewParticlesEmitter2Objects1);
/* Reuse gdjs.SchoolCode.GDdoorsObjects1 */
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects1);
{for(var i = 0, len = gdjs.SchoolCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.SchoolCode.GDplayerObjects1[i].setPosition((( gdjs.SchoolCode.GDdoorsObjects1.length === 0 ) ? 0 :gdjs.SchoolCode.GDdoorsObjects1[0].getPointX("Point")),(( gdjs.SchoolCode.GDdoorsObjects1.length === 0 ) ? 0 :gdjs.SchoolCode.GDdoorsObjects1[0].getPointY("Point")) - 15);
}
}{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.SchoolCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects1[0].getPointX("")), "", 0);
}{gdjs.evtTools.camera.setCameraY(runtimeScene, (( gdjs.SchoolCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects1[0].getPointY("")), "", 0);
}{for(var i = 0, len = gdjs.SchoolCode.GDNewParticlesEmitterObjects1.length ;i < len;++i) {
    gdjs.SchoolCode.GDNewParticlesEmitterObjects1[i].setY((( gdjs.SchoolCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects1[0].getPointY("")) - 260);
}
}{for(var i = 0, len = gdjs.SchoolCode.GDNewParticlesEmitter2Objects1.length ;i < len;++i) {
    gdjs.SchoolCode.GDNewParticlesEmitter2Objects1[i].setY((( gdjs.SchoolCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects1[0].getPointY("")) - 260);
}
}}

}


{


gdjs.SchoolCode.eventsList1(runtimeScene);
}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimeScale(runtimeScene) != 0;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Light"), gdjs.SchoolCode.GDLightObjects1);
gdjs.copyArray(runtimeScene.getObjects("Light2"), gdjs.SchoolCode.GDLight2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Light_hand"), gdjs.SchoolCode.GDLight_9595handObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewBitmapText"), gdjs.SchoolCode.GDNewBitmapTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewParticlesEmitter"), gdjs.SchoolCode.GDNewParticlesEmitterObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewParticlesEmitter2"), gdjs.SchoolCode.GDNewParticlesEmitter2Objects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("rail"), gdjs.SchoolCode.GDrailObjects1);
gdjs.copyArray(runtimeScene.getObjects("task_bar"), gdjs.SchoolCode.GDtask_9595barObjects1);
{for(var i = 0, len = gdjs.SchoolCode.GDLight2Objects1.length ;i < len;++i) {
    gdjs.SchoolCode.GDLight2Objects1[i].setPosition((( gdjs.SchoolCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects1[0].getPointX("")),(( gdjs.SchoolCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects1[0].getPointY("")));
}
}{for(var i = 0, len = gdjs.SchoolCode.GDLightObjects1.length ;i < len;++i) {
    gdjs.SchoolCode.GDLightObjects1[i].setPosition((( gdjs.SchoolCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects1[0].getPointX("")),(( gdjs.SchoolCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects1[0].getPointY("")));
}
}{for(var i = 0, len = gdjs.SchoolCode.GDNewParticlesEmitterObjects1.length ;i < len;++i) {
    gdjs.SchoolCode.GDNewParticlesEmitterObjects1[i].setX((( gdjs.SchoolCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects1[0].getPointX("")));
}
}{for(var i = 0, len = gdjs.SchoolCode.GDNewParticlesEmitter2Objects1.length ;i < len;++i) {
    gdjs.SchoolCode.GDNewParticlesEmitter2Objects1[i].setX((( gdjs.SchoolCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects1[0].getPointX("")));
}
}{for(var i = 0, len = gdjs.SchoolCode.GDrailObjects1.length ;i < len;++i) {
    gdjs.SchoolCode.GDrailObjects1[i].setXOffset((( gdjs.SchoolCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects1[0].getPointX("")) / 2);
}
}{for(var i = 0, len = gdjs.SchoolCode.GDtask_9595barObjects1.length ;i < len;++i) {
    gdjs.SchoolCode.GDtask_9595barObjects1[i].setPosition((( gdjs.SchoolCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects1[0].getPointX("fly")) - 32,(( gdjs.SchoolCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.SchoolCode.GDplayerObjects1[0].getPointY("fly")) - 16);
}
}{for(var i = 0, len = gdjs.SchoolCode.GDNewBitmapTextObjects1.length ;i < len;++i) {
    gdjs.SchoolCode.GDNewBitmapTextObjects1[i].setPosition((( gdjs.SchoolCode.GDtask_9595barObjects1.length === 0 ) ? 0 :gdjs.SchoolCode.GDtask_9595barObjects1[0].getCenterXInScene()) - 16,(( gdjs.SchoolCode.GDtask_9595barObjects1.length === 0 ) ? 0 :gdjs.SchoolCode.GDtask_9595barObjects1[0].getCenterYInScene()) - 4);
}
}{for(var i = 0, len = gdjs.SchoolCode.GDLight_9595handObjects1.length ;i < len;++i) {
    gdjs.SchoolCode.GDLight_9595handObjects1[i].setPosition(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0),gdjs.evtTools.input.getCursorY(runtimeScene, "", 0));
}
}}

}


{



}


{



}


{


gdjs.SchoolCode.eventsList36(runtimeScene);
}


{


gdjs.SchoolCode.eventsList37(runtimeScene);
}


{


gdjs.SchoolCode.eventsList50(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("area"), gdjs.SchoolCode.GDareaObjects1);
gdjs.copyArray(runtimeScene.getObjects("doors"), gdjs.SchoolCode.GDdoorsObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects1);
gdjs.SchoolCode.GDE_9595buttonObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects1Objects, gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDdoorsObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDareaObjects1Objects, gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDdoorsObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDdoorsObjects1.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDdoorsObjects1[i].getVariableString(gdjs.SchoolCode.GDdoorsObjects1[i].getVariables().getFromIndex(0)) == "Bathroom-3" ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDdoorsObjects1[k] = gdjs.SchoolCode.GDdoorsObjects1[i];
        ++k;
    }
}
gdjs.SchoolCode.GDdoorsObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.SchoolCode.GDE_9595buttonObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.SchoolCode.GDE_9595buttonObjects2);
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDE_9595buttonObjects2.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDE_9595buttonObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.SchoolCode.GDE_9595buttonObjects2[k] = gdjs.SchoolCode.GDE_9595buttonObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDE_9595buttonObjects2.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.SchoolCode.GDE_9595buttonObjects2.length; j < jLen ; ++j) {
        if ( gdjs.SchoolCode.GDE_9595buttonObjects1_1final.indexOf(gdjs.SchoolCode.GDE_9595buttonObjects2[j]) === -1 )
            gdjs.SchoolCode.GDE_9595buttonObjects1_1final.push(gdjs.SchoolCode.GDE_9595buttonObjects2[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.SchoolCode.GDE_9595buttonObjects1_1final, gdjs.SchoolCode.GDE_9595buttonObjects1);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(16)) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29214828);
}
}
}
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "door-open-46756_nnWlox72.mp3", false, 100, 1);
}
{ //Subevents
gdjs.SchoolCode.eventsList52(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("doors"), gdjs.SchoolCode.GDdoorsObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.SchoolCode.GDplayerObjects1);
gdjs.SchoolCode.GDE_9595buttonObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDplayerObjects1Objects, gdjs.SchoolCode.mapOfGDgdjs_9546SchoolCode_9546GDdoorsObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDdoorsObjects1.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDdoorsObjects1[i].getVariableString(gdjs.SchoolCode.GDdoorsObjects1[i].getVariables().getFromIndex(0)) == "Grandpa's" ) {
        isConditionTrue_0 = true;
        gdjs.SchoolCode.GDdoorsObjects1[k] = gdjs.SchoolCode.GDdoorsObjects1[i];
        ++k;
    }
}
gdjs.SchoolCode.GDdoorsObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.SchoolCode.GDE_9595buttonObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.SchoolCode.GDE_9595buttonObjects2);
for (var i = 0, k = 0, l = gdjs.SchoolCode.GDE_9595buttonObjects2.length;i<l;++i) {
    if ( gdjs.SchoolCode.GDE_9595buttonObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.SchoolCode.GDE_9595buttonObjects2[k] = gdjs.SchoolCode.GDE_9595buttonObjects2[i];
        ++k;
    }
}
gdjs.SchoolCode.GDE_9595buttonObjects2.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.SchoolCode.GDE_9595buttonObjects2.length; j < jLen ; ++j) {
        if ( gdjs.SchoolCode.GDE_9595buttonObjects1_1final.indexOf(gdjs.SchoolCode.GDE_9595buttonObjects2[j]) === -1 )
            gdjs.SchoolCode.GDE_9595buttonObjects1_1final.push(gdjs.SchoolCode.GDE_9595buttonObjects2[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.SchoolCode.GDE_9595buttonObjects1_1final, gdjs.SchoolCode.GDE_9595buttonObjects1);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(16)) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(18)) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29219140);
}
}
}
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "door-open-46756_nnWlox72.mp3", false, 100, 1);
}
{ //Subevents
gdjs.SchoolCode.eventsList54(runtimeScene);} //End of subevents
}

}


{


gdjs.SchoolCode.eventsList61(runtimeScene);
}


{


gdjs.SchoolCode.eventsList70(runtimeScene);
}


{


gdjs.SchoolCode.eventsList71(runtimeScene);
}


{


gdjs.SchoolCode.eventsList72(runtimeScene);
}


};

gdjs.SchoolCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.SchoolCode.GDpuddlesObjects1.length = 0;
gdjs.SchoolCode.GDpuddlesObjects2.length = 0;
gdjs.SchoolCode.GDpuddlesObjects3.length = 0;
gdjs.SchoolCode.GDpuddlesObjects4.length = 0;
gdjs.SchoolCode.GDNewParticlesEmitterObjects1.length = 0;
gdjs.SchoolCode.GDNewParticlesEmitterObjects2.length = 0;
gdjs.SchoolCode.GDNewParticlesEmitterObjects3.length = 0;
gdjs.SchoolCode.GDNewParticlesEmitterObjects4.length = 0;
gdjs.SchoolCode.GDLightObjects1.length = 0;
gdjs.SchoolCode.GDLightObjects2.length = 0;
gdjs.SchoolCode.GDLightObjects3.length = 0;
gdjs.SchoolCode.GDLightObjects4.length = 0;
gdjs.SchoolCode.GDLight2Objects1.length = 0;
gdjs.SchoolCode.GDLight2Objects2.length = 0;
gdjs.SchoolCode.GDLight2Objects3.length = 0;
gdjs.SchoolCode.GDLight2Objects4.length = 0;
gdjs.SchoolCode.GDNewShapePainterObjects1.length = 0;
gdjs.SchoolCode.GDNewShapePainterObjects2.length = 0;
gdjs.SchoolCode.GDNewShapePainterObjects3.length = 0;
gdjs.SchoolCode.GDNewShapePainterObjects4.length = 0;
gdjs.SchoolCode.GDNewParticlesEmitter2Objects1.length = 0;
gdjs.SchoolCode.GDNewParticlesEmitter2Objects2.length = 0;
gdjs.SchoolCode.GDNewParticlesEmitter2Objects3.length = 0;
gdjs.SchoolCode.GDNewParticlesEmitter2Objects4.length = 0;
gdjs.SchoolCode.GDtransitionObjects1.length = 0;
gdjs.SchoolCode.GDtransitionObjects2.length = 0;
gdjs.SchoolCode.GDtransitionObjects3.length = 0;
gdjs.SchoolCode.GDtransitionObjects4.length = 0;
gdjs.SchoolCode.GDfloor_95953Objects1.length = 0;
gdjs.SchoolCode.GDfloor_95953Objects2.length = 0;
gdjs.SchoolCode.GDfloor_95953Objects3.length = 0;
gdjs.SchoolCode.GDfloor_95953Objects4.length = 0;
gdjs.SchoolCode.GDcolorsObjects1.length = 0;
gdjs.SchoolCode.GDcolorsObjects2.length = 0;
gdjs.SchoolCode.GDcolorsObjects3.length = 0;
gdjs.SchoolCode.GDcolorsObjects4.length = 0;
gdjs.SchoolCode.GDnoteObjects1.length = 0;
gdjs.SchoolCode.GDnoteObjects2.length = 0;
gdjs.SchoolCode.GDnoteObjects3.length = 0;
gdjs.SchoolCode.GDnoteObjects4.length = 0;
gdjs.SchoolCode.GDoppacityObjects1.length = 0;
gdjs.SchoolCode.GDoppacityObjects2.length = 0;
gdjs.SchoolCode.GDoppacityObjects3.length = 0;
gdjs.SchoolCode.GDoppacityObjects4.length = 0;
gdjs.SchoolCode.GDcloseObjects1.length = 0;
gdjs.SchoolCode.GDcloseObjects2.length = 0;
gdjs.SchoolCode.GDcloseObjects3.length = 0;
gdjs.SchoolCode.GDcloseObjects4.length = 0;
gdjs.SchoolCode.GDnotesObjects1.length = 0;
gdjs.SchoolCode.GDnotesObjects2.length = 0;
gdjs.SchoolCode.GDnotesObjects3.length = 0;
gdjs.SchoolCode.GDnotesObjects4.length = 0;
gdjs.SchoolCode.GDnote2Objects1.length = 0;
gdjs.SchoolCode.GDnote2Objects2.length = 0;
gdjs.SchoolCode.GDnote2Objects3.length = 0;
gdjs.SchoolCode.GDnote2Objects4.length = 0;
gdjs.SchoolCode.GDLight3Objects1.length = 0;
gdjs.SchoolCode.GDLight3Objects2.length = 0;
gdjs.SchoolCode.GDLight3Objects3.length = 0;
gdjs.SchoolCode.GDLight3Objects4.length = 0;
gdjs.SchoolCode.GDareaObjects1.length = 0;
gdjs.SchoolCode.GDareaObjects2.length = 0;
gdjs.SchoolCode.GDareaObjects3.length = 0;
gdjs.SchoolCode.GDareaObjects4.length = 0;
gdjs.SchoolCode.GDspawn_9595himaObjects1.length = 0;
gdjs.SchoolCode.GDspawn_9595himaObjects2.length = 0;
gdjs.SchoolCode.GDspawn_9595himaObjects3.length = 0;
gdjs.SchoolCode.GDspawn_9595himaObjects4.length = 0;
gdjs.SchoolCode.GDLight_9595handObjects1.length = 0;
gdjs.SchoolCode.GDLight_9595handObjects2.length = 0;
gdjs.SchoolCode.GDLight_9595handObjects3.length = 0;
gdjs.SchoolCode.GDLight_9595handObjects4.length = 0;
gdjs.SchoolCode.GDarea2Objects1.length = 0;
gdjs.SchoolCode.GDarea2Objects2.length = 0;
gdjs.SchoolCode.GDarea2Objects3.length = 0;
gdjs.SchoolCode.GDarea2Objects4.length = 0;
gdjs.SchoolCode.GDCartObjects1.length = 0;
gdjs.SchoolCode.GDCartObjects2.length = 0;
gdjs.SchoolCode.GDCartObjects3.length = 0;
gdjs.SchoolCode.GDCartObjects4.length = 0;
gdjs.SchoolCode.GDWallObjects1.length = 0;
gdjs.SchoolCode.GDWallObjects2.length = 0;
gdjs.SchoolCode.GDWallObjects3.length = 0;
gdjs.SchoolCode.GDWallObjects4.length = 0;
gdjs.SchoolCode.GDfloorObjects1.length = 0;
gdjs.SchoolCode.GDfloorObjects2.length = 0;
gdjs.SchoolCode.GDfloorObjects3.length = 0;
gdjs.SchoolCode.GDfloorObjects4.length = 0;
gdjs.SchoolCode.GDdoorsObjects1.length = 0;
gdjs.SchoolCode.GDdoorsObjects2.length = 0;
gdjs.SchoolCode.GDdoorsObjects3.length = 0;
gdjs.SchoolCode.GDdoorsObjects4.length = 0;
gdjs.SchoolCode.GDobjectsObjects1.length = 0;
gdjs.SchoolCode.GDobjectsObjects2.length = 0;
gdjs.SchoolCode.GDobjectsObjects3.length = 0;
gdjs.SchoolCode.GDobjectsObjects4.length = 0;
gdjs.SchoolCode.GDwallobjectObjects1.length = 0;
gdjs.SchoolCode.GDwallobjectObjects2.length = 0;
gdjs.SchoolCode.GDwallobjectObjects3.length = 0;
gdjs.SchoolCode.GDwallobjectObjects4.length = 0;
gdjs.SchoolCode.GDwindowObjects1.length = 0;
gdjs.SchoolCode.GDwindowObjects2.length = 0;
gdjs.SchoolCode.GDwindowObjects3.length = 0;
gdjs.SchoolCode.GDwindowObjects4.length = 0;
gdjs.SchoolCode.GDrailObjects1.length = 0;
gdjs.SchoolCode.GDrailObjects2.length = 0;
gdjs.SchoolCode.GDrailObjects3.length = 0;
gdjs.SchoolCode.GDrailObjects4.length = 0;
gdjs.SchoolCode.GDplayerObjects1.length = 0;
gdjs.SchoolCode.GDplayerObjects2.length = 0;
gdjs.SchoolCode.GDplayerObjects3.length = 0;
gdjs.SchoolCode.GDplayerObjects4.length = 0;
gdjs.SchoolCode.GDhitboxObjects1.length = 0;
gdjs.SchoolCode.GDhitboxObjects2.length = 0;
gdjs.SchoolCode.GDhitboxObjects3.length = 0;
gdjs.SchoolCode.GDhitboxObjects4.length = 0;
gdjs.SchoolCode.GDMainlightObjects1.length = 0;
gdjs.SchoolCode.GDMainlightObjects2.length = 0;
gdjs.SchoolCode.GDMainlightObjects3.length = 0;
gdjs.SchoolCode.GDMainlightObjects4.length = 0;
gdjs.SchoolCode.GDsmalllightObjects1.length = 0;
gdjs.SchoolCode.GDsmalllightObjects2.length = 0;
gdjs.SchoolCode.GDsmalllightObjects3.length = 0;
gdjs.SchoolCode.GDsmalllightObjects4.length = 0;
gdjs.SchoolCode.GDNewBitmapTextObjects1.length = 0;
gdjs.SchoolCode.GDNewBitmapTextObjects2.length = 0;
gdjs.SchoolCode.GDNewBitmapTextObjects3.length = 0;
gdjs.SchoolCode.GDNewBitmapTextObjects4.length = 0;
gdjs.SchoolCode.GDtask_9595barObjects1.length = 0;
gdjs.SchoolCode.GDtask_9595barObjects2.length = 0;
gdjs.SchoolCode.GDtask_9595barObjects3.length = 0;
gdjs.SchoolCode.GDtask_9595barObjects4.length = 0;
gdjs.SchoolCode.GDcharectersObjects1.length = 0;
gdjs.SchoolCode.GDcharectersObjects2.length = 0;
gdjs.SchoolCode.GDcharectersObjects3.length = 0;
gdjs.SchoolCode.GDcharectersObjects4.length = 0;
gdjs.SchoolCode.GDcharecters22Objects1.length = 0;
gdjs.SchoolCode.GDcharecters22Objects2.length = 0;
gdjs.SchoolCode.GDcharecters22Objects3.length = 0;
gdjs.SchoolCode.GDcharecters22Objects4.length = 0;
gdjs.SchoolCode.GDPauseObjects1.length = 0;
gdjs.SchoolCode.GDPauseObjects2.length = 0;
gdjs.SchoolCode.GDPauseObjects3.length = 0;
gdjs.SchoolCode.GDPauseObjects4.length = 0;
gdjs.SchoolCode.GDresumeObjects1.length = 0;
gdjs.SchoolCode.GDresumeObjects2.length = 0;
gdjs.SchoolCode.GDresumeObjects3.length = 0;
gdjs.SchoolCode.GDresumeObjects4.length = 0;
gdjs.SchoolCode.GDQuit_95952Objects1.length = 0;
gdjs.SchoolCode.GDQuit_95952Objects2.length = 0;
gdjs.SchoolCode.GDQuit_95952Objects3.length = 0;
gdjs.SchoolCode.GDQuit_95952Objects4.length = 0;
gdjs.SchoolCode.GDpause_9595menuObjects1.length = 0;
gdjs.SchoolCode.GDpause_9595menuObjects2.length = 0;
gdjs.SchoolCode.GDpause_9595menuObjects3.length = 0;
gdjs.SchoolCode.GDpause_9595menuObjects4.length = 0;
gdjs.SchoolCode.GDHimaObjects1.length = 0;
gdjs.SchoolCode.GDHimaObjects2.length = 0;
gdjs.SchoolCode.GDHimaObjects3.length = 0;
gdjs.SchoolCode.GDHimaObjects4.length = 0;
gdjs.SchoolCode.GDLayaObjects1.length = 0;
gdjs.SchoolCode.GDLayaObjects2.length = 0;
gdjs.SchoolCode.GDLayaObjects3.length = 0;
gdjs.SchoolCode.GDLayaObjects4.length = 0;
gdjs.SchoolCode.GDJoystickObjects1.length = 0;
gdjs.SchoolCode.GDJoystickObjects2.length = 0;
gdjs.SchoolCode.GDJoystickObjects3.length = 0;
gdjs.SchoolCode.GDJoystickObjects4.length = 0;
gdjs.SchoolCode.GDE_9595buttonObjects1.length = 0;
gdjs.SchoolCode.GDE_9595buttonObjects2.length = 0;
gdjs.SchoolCode.GDE_9595buttonObjects3.length = 0;
gdjs.SchoolCode.GDE_9595buttonObjects4.length = 0;

gdjs.SchoolCode.eventsList73(runtimeScene);
gdjs.SchoolCode.GDpuddlesObjects1.length = 0;
gdjs.SchoolCode.GDpuddlesObjects2.length = 0;
gdjs.SchoolCode.GDpuddlesObjects3.length = 0;
gdjs.SchoolCode.GDpuddlesObjects4.length = 0;
gdjs.SchoolCode.GDNewParticlesEmitterObjects1.length = 0;
gdjs.SchoolCode.GDNewParticlesEmitterObjects2.length = 0;
gdjs.SchoolCode.GDNewParticlesEmitterObjects3.length = 0;
gdjs.SchoolCode.GDNewParticlesEmitterObjects4.length = 0;
gdjs.SchoolCode.GDLightObjects1.length = 0;
gdjs.SchoolCode.GDLightObjects2.length = 0;
gdjs.SchoolCode.GDLightObjects3.length = 0;
gdjs.SchoolCode.GDLightObjects4.length = 0;
gdjs.SchoolCode.GDLight2Objects1.length = 0;
gdjs.SchoolCode.GDLight2Objects2.length = 0;
gdjs.SchoolCode.GDLight2Objects3.length = 0;
gdjs.SchoolCode.GDLight2Objects4.length = 0;
gdjs.SchoolCode.GDNewShapePainterObjects1.length = 0;
gdjs.SchoolCode.GDNewShapePainterObjects2.length = 0;
gdjs.SchoolCode.GDNewShapePainterObjects3.length = 0;
gdjs.SchoolCode.GDNewShapePainterObjects4.length = 0;
gdjs.SchoolCode.GDNewParticlesEmitter2Objects1.length = 0;
gdjs.SchoolCode.GDNewParticlesEmitter2Objects2.length = 0;
gdjs.SchoolCode.GDNewParticlesEmitter2Objects3.length = 0;
gdjs.SchoolCode.GDNewParticlesEmitter2Objects4.length = 0;
gdjs.SchoolCode.GDtransitionObjects1.length = 0;
gdjs.SchoolCode.GDtransitionObjects2.length = 0;
gdjs.SchoolCode.GDtransitionObjects3.length = 0;
gdjs.SchoolCode.GDtransitionObjects4.length = 0;
gdjs.SchoolCode.GDfloor_95953Objects1.length = 0;
gdjs.SchoolCode.GDfloor_95953Objects2.length = 0;
gdjs.SchoolCode.GDfloor_95953Objects3.length = 0;
gdjs.SchoolCode.GDfloor_95953Objects4.length = 0;
gdjs.SchoolCode.GDcolorsObjects1.length = 0;
gdjs.SchoolCode.GDcolorsObjects2.length = 0;
gdjs.SchoolCode.GDcolorsObjects3.length = 0;
gdjs.SchoolCode.GDcolorsObjects4.length = 0;
gdjs.SchoolCode.GDnoteObjects1.length = 0;
gdjs.SchoolCode.GDnoteObjects2.length = 0;
gdjs.SchoolCode.GDnoteObjects3.length = 0;
gdjs.SchoolCode.GDnoteObjects4.length = 0;
gdjs.SchoolCode.GDoppacityObjects1.length = 0;
gdjs.SchoolCode.GDoppacityObjects2.length = 0;
gdjs.SchoolCode.GDoppacityObjects3.length = 0;
gdjs.SchoolCode.GDoppacityObjects4.length = 0;
gdjs.SchoolCode.GDcloseObjects1.length = 0;
gdjs.SchoolCode.GDcloseObjects2.length = 0;
gdjs.SchoolCode.GDcloseObjects3.length = 0;
gdjs.SchoolCode.GDcloseObjects4.length = 0;
gdjs.SchoolCode.GDnotesObjects1.length = 0;
gdjs.SchoolCode.GDnotesObjects2.length = 0;
gdjs.SchoolCode.GDnotesObjects3.length = 0;
gdjs.SchoolCode.GDnotesObjects4.length = 0;
gdjs.SchoolCode.GDnote2Objects1.length = 0;
gdjs.SchoolCode.GDnote2Objects2.length = 0;
gdjs.SchoolCode.GDnote2Objects3.length = 0;
gdjs.SchoolCode.GDnote2Objects4.length = 0;
gdjs.SchoolCode.GDLight3Objects1.length = 0;
gdjs.SchoolCode.GDLight3Objects2.length = 0;
gdjs.SchoolCode.GDLight3Objects3.length = 0;
gdjs.SchoolCode.GDLight3Objects4.length = 0;
gdjs.SchoolCode.GDareaObjects1.length = 0;
gdjs.SchoolCode.GDareaObjects2.length = 0;
gdjs.SchoolCode.GDareaObjects3.length = 0;
gdjs.SchoolCode.GDareaObjects4.length = 0;
gdjs.SchoolCode.GDspawn_9595himaObjects1.length = 0;
gdjs.SchoolCode.GDspawn_9595himaObjects2.length = 0;
gdjs.SchoolCode.GDspawn_9595himaObjects3.length = 0;
gdjs.SchoolCode.GDspawn_9595himaObjects4.length = 0;
gdjs.SchoolCode.GDLight_9595handObjects1.length = 0;
gdjs.SchoolCode.GDLight_9595handObjects2.length = 0;
gdjs.SchoolCode.GDLight_9595handObjects3.length = 0;
gdjs.SchoolCode.GDLight_9595handObjects4.length = 0;
gdjs.SchoolCode.GDarea2Objects1.length = 0;
gdjs.SchoolCode.GDarea2Objects2.length = 0;
gdjs.SchoolCode.GDarea2Objects3.length = 0;
gdjs.SchoolCode.GDarea2Objects4.length = 0;
gdjs.SchoolCode.GDCartObjects1.length = 0;
gdjs.SchoolCode.GDCartObjects2.length = 0;
gdjs.SchoolCode.GDCartObjects3.length = 0;
gdjs.SchoolCode.GDCartObjects4.length = 0;
gdjs.SchoolCode.GDWallObjects1.length = 0;
gdjs.SchoolCode.GDWallObjects2.length = 0;
gdjs.SchoolCode.GDWallObjects3.length = 0;
gdjs.SchoolCode.GDWallObjects4.length = 0;
gdjs.SchoolCode.GDfloorObjects1.length = 0;
gdjs.SchoolCode.GDfloorObjects2.length = 0;
gdjs.SchoolCode.GDfloorObjects3.length = 0;
gdjs.SchoolCode.GDfloorObjects4.length = 0;
gdjs.SchoolCode.GDdoorsObjects1.length = 0;
gdjs.SchoolCode.GDdoorsObjects2.length = 0;
gdjs.SchoolCode.GDdoorsObjects3.length = 0;
gdjs.SchoolCode.GDdoorsObjects4.length = 0;
gdjs.SchoolCode.GDobjectsObjects1.length = 0;
gdjs.SchoolCode.GDobjectsObjects2.length = 0;
gdjs.SchoolCode.GDobjectsObjects3.length = 0;
gdjs.SchoolCode.GDobjectsObjects4.length = 0;
gdjs.SchoolCode.GDwallobjectObjects1.length = 0;
gdjs.SchoolCode.GDwallobjectObjects2.length = 0;
gdjs.SchoolCode.GDwallobjectObjects3.length = 0;
gdjs.SchoolCode.GDwallobjectObjects4.length = 0;
gdjs.SchoolCode.GDwindowObjects1.length = 0;
gdjs.SchoolCode.GDwindowObjects2.length = 0;
gdjs.SchoolCode.GDwindowObjects3.length = 0;
gdjs.SchoolCode.GDwindowObjects4.length = 0;
gdjs.SchoolCode.GDrailObjects1.length = 0;
gdjs.SchoolCode.GDrailObjects2.length = 0;
gdjs.SchoolCode.GDrailObjects3.length = 0;
gdjs.SchoolCode.GDrailObjects4.length = 0;
gdjs.SchoolCode.GDplayerObjects1.length = 0;
gdjs.SchoolCode.GDplayerObjects2.length = 0;
gdjs.SchoolCode.GDplayerObjects3.length = 0;
gdjs.SchoolCode.GDplayerObjects4.length = 0;
gdjs.SchoolCode.GDhitboxObjects1.length = 0;
gdjs.SchoolCode.GDhitboxObjects2.length = 0;
gdjs.SchoolCode.GDhitboxObjects3.length = 0;
gdjs.SchoolCode.GDhitboxObjects4.length = 0;
gdjs.SchoolCode.GDMainlightObjects1.length = 0;
gdjs.SchoolCode.GDMainlightObjects2.length = 0;
gdjs.SchoolCode.GDMainlightObjects3.length = 0;
gdjs.SchoolCode.GDMainlightObjects4.length = 0;
gdjs.SchoolCode.GDsmalllightObjects1.length = 0;
gdjs.SchoolCode.GDsmalllightObjects2.length = 0;
gdjs.SchoolCode.GDsmalllightObjects3.length = 0;
gdjs.SchoolCode.GDsmalllightObjects4.length = 0;
gdjs.SchoolCode.GDNewBitmapTextObjects1.length = 0;
gdjs.SchoolCode.GDNewBitmapTextObjects2.length = 0;
gdjs.SchoolCode.GDNewBitmapTextObjects3.length = 0;
gdjs.SchoolCode.GDNewBitmapTextObjects4.length = 0;
gdjs.SchoolCode.GDtask_9595barObjects1.length = 0;
gdjs.SchoolCode.GDtask_9595barObjects2.length = 0;
gdjs.SchoolCode.GDtask_9595barObjects3.length = 0;
gdjs.SchoolCode.GDtask_9595barObjects4.length = 0;
gdjs.SchoolCode.GDcharectersObjects1.length = 0;
gdjs.SchoolCode.GDcharectersObjects2.length = 0;
gdjs.SchoolCode.GDcharectersObjects3.length = 0;
gdjs.SchoolCode.GDcharectersObjects4.length = 0;
gdjs.SchoolCode.GDcharecters22Objects1.length = 0;
gdjs.SchoolCode.GDcharecters22Objects2.length = 0;
gdjs.SchoolCode.GDcharecters22Objects3.length = 0;
gdjs.SchoolCode.GDcharecters22Objects4.length = 0;
gdjs.SchoolCode.GDPauseObjects1.length = 0;
gdjs.SchoolCode.GDPauseObjects2.length = 0;
gdjs.SchoolCode.GDPauseObjects3.length = 0;
gdjs.SchoolCode.GDPauseObjects4.length = 0;
gdjs.SchoolCode.GDresumeObjects1.length = 0;
gdjs.SchoolCode.GDresumeObjects2.length = 0;
gdjs.SchoolCode.GDresumeObjects3.length = 0;
gdjs.SchoolCode.GDresumeObjects4.length = 0;
gdjs.SchoolCode.GDQuit_95952Objects1.length = 0;
gdjs.SchoolCode.GDQuit_95952Objects2.length = 0;
gdjs.SchoolCode.GDQuit_95952Objects3.length = 0;
gdjs.SchoolCode.GDQuit_95952Objects4.length = 0;
gdjs.SchoolCode.GDpause_9595menuObjects1.length = 0;
gdjs.SchoolCode.GDpause_9595menuObjects2.length = 0;
gdjs.SchoolCode.GDpause_9595menuObjects3.length = 0;
gdjs.SchoolCode.GDpause_9595menuObjects4.length = 0;
gdjs.SchoolCode.GDHimaObjects1.length = 0;
gdjs.SchoolCode.GDHimaObjects2.length = 0;
gdjs.SchoolCode.GDHimaObjects3.length = 0;
gdjs.SchoolCode.GDHimaObjects4.length = 0;
gdjs.SchoolCode.GDLayaObjects1.length = 0;
gdjs.SchoolCode.GDLayaObjects2.length = 0;
gdjs.SchoolCode.GDLayaObjects3.length = 0;
gdjs.SchoolCode.GDLayaObjects4.length = 0;
gdjs.SchoolCode.GDJoystickObjects1.length = 0;
gdjs.SchoolCode.GDJoystickObjects2.length = 0;
gdjs.SchoolCode.GDJoystickObjects3.length = 0;
gdjs.SchoolCode.GDJoystickObjects4.length = 0;
gdjs.SchoolCode.GDE_9595buttonObjects1.length = 0;
gdjs.SchoolCode.GDE_9595buttonObjects2.length = 0;
gdjs.SchoolCode.GDE_9595buttonObjects3.length = 0;
gdjs.SchoolCode.GDE_9595buttonObjects4.length = 0;


return;

}

gdjs['SchoolCode'] = gdjs.SchoolCode;
