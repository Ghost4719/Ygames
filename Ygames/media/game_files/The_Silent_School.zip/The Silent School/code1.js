gdjs.PastCode = {};
gdjs.PastCode.localVariables = [];
gdjs.PastCode.GDE_9595buttonObjects2_1final = [];

gdjs.PastCode.GDE_9595buttonObjects3_1final = [];

gdjs.PastCode.GDJoystickObjects2_1final = [];

gdjs.PastCode.GDpuddlesObjects1= [];
gdjs.PastCode.GDpuddlesObjects2= [];
gdjs.PastCode.GDpuddlesObjects3= [];
gdjs.PastCode.GDpuddlesObjects4= [];
gdjs.PastCode.GDNewParticlesEmitterObjects1= [];
gdjs.PastCode.GDNewParticlesEmitterObjects2= [];
gdjs.PastCode.GDNewParticlesEmitterObjects3= [];
gdjs.PastCode.GDNewParticlesEmitterObjects4= [];
gdjs.PastCode.GDLightObjects1= [];
gdjs.PastCode.GDLightObjects2= [];
gdjs.PastCode.GDLightObjects3= [];
gdjs.PastCode.GDLightObjects4= [];
gdjs.PastCode.GDLight2Objects1= [];
gdjs.PastCode.GDLight2Objects2= [];
gdjs.PastCode.GDLight2Objects3= [];
gdjs.PastCode.GDLight2Objects4= [];
gdjs.PastCode.GDNewShapePainterObjects1= [];
gdjs.PastCode.GDNewShapePainterObjects2= [];
gdjs.PastCode.GDNewShapePainterObjects3= [];
gdjs.PastCode.GDNewShapePainterObjects4= [];
gdjs.PastCode.GDNewParticlesEmitter2Objects1= [];
gdjs.PastCode.GDNewParticlesEmitter2Objects2= [];
gdjs.PastCode.GDNewParticlesEmitter2Objects3= [];
gdjs.PastCode.GDNewParticlesEmitter2Objects4= [];
gdjs.PastCode.GDtransitionObjects1= [];
gdjs.PastCode.GDtransitionObjects2= [];
gdjs.PastCode.GDtransitionObjects3= [];
gdjs.PastCode.GDtransitionObjects4= [];
gdjs.PastCode.GDfloor_95953Objects1= [];
gdjs.PastCode.GDfloor_95953Objects2= [];
gdjs.PastCode.GDfloor_95953Objects3= [];
gdjs.PastCode.GDfloor_95953Objects4= [];
gdjs.PastCode.GDcolorsObjects1= [];
gdjs.PastCode.GDcolorsObjects2= [];
gdjs.PastCode.GDcolorsObjects3= [];
gdjs.PastCode.GDcolorsObjects4= [];
gdjs.PastCode.GDnoteObjects1= [];
gdjs.PastCode.GDnoteObjects2= [];
gdjs.PastCode.GDnoteObjects3= [];
gdjs.PastCode.GDnoteObjects4= [];
gdjs.PastCode.GDoppacityObjects1= [];
gdjs.PastCode.GDoppacityObjects2= [];
gdjs.PastCode.GDoppacityObjects3= [];
gdjs.PastCode.GDoppacityObjects4= [];
gdjs.PastCode.GDcloseObjects1= [];
gdjs.PastCode.GDcloseObjects2= [];
gdjs.PastCode.GDcloseObjects3= [];
gdjs.PastCode.GDcloseObjects4= [];
gdjs.PastCode.GDnotesObjects1= [];
gdjs.PastCode.GDnotesObjects2= [];
gdjs.PastCode.GDnotesObjects3= [];
gdjs.PastCode.GDnotesObjects4= [];
gdjs.PastCode.GDnote2Objects1= [];
gdjs.PastCode.GDnote2Objects2= [];
gdjs.PastCode.GDnote2Objects3= [];
gdjs.PastCode.GDnote2Objects4= [];
gdjs.PastCode.GDLight3Objects1= [];
gdjs.PastCode.GDLight3Objects2= [];
gdjs.PastCode.GDLight3Objects3= [];
gdjs.PastCode.GDLight3Objects4= [];
gdjs.PastCode.GDareaObjects1= [];
gdjs.PastCode.GDareaObjects2= [];
gdjs.PastCode.GDareaObjects3= [];
gdjs.PastCode.GDareaObjects4= [];
gdjs.PastCode.GDspawn_9595himaObjects1= [];
gdjs.PastCode.GDspawn_9595himaObjects2= [];
gdjs.PastCode.GDspawn_9595himaObjects3= [];
gdjs.PastCode.GDspawn_9595himaObjects4= [];
gdjs.PastCode.GDLight_9595handObjects1= [];
gdjs.PastCode.GDLight_9595handObjects2= [];
gdjs.PastCode.GDLight_9595handObjects3= [];
gdjs.PastCode.GDLight_9595handObjects4= [];
gdjs.PastCode.GDarea2Objects1= [];
gdjs.PastCode.GDarea2Objects2= [];
gdjs.PastCode.GDarea2Objects3= [];
gdjs.PastCode.GDarea2Objects4= [];
gdjs.PastCode.GDtext_9595boxObjects1= [];
gdjs.PastCode.GDtext_9595boxObjects2= [];
gdjs.PastCode.GDtext_9595boxObjects3= [];
gdjs.PastCode.GDtext_9595boxObjects4= [];
gdjs.PastCode.GDtipObjects1= [];
gdjs.PastCode.GDtipObjects2= [];
gdjs.PastCode.GDtipObjects3= [];
gdjs.PastCode.GDtipObjects4= [];
gdjs.PastCode.GDNameObjects1= [];
gdjs.PastCode.GDNameObjects2= [];
gdjs.PastCode.GDNameObjects3= [];
gdjs.PastCode.GDNameObjects4= [];
gdjs.PastCode.GDDialogeObjects1= [];
gdjs.PastCode.GDDialogeObjects2= [];
gdjs.PastCode.GDDialogeObjects3= [];
gdjs.PastCode.GDDialogeObjects4= [];
gdjs.PastCode.GDcharecters2Objects1= [];
gdjs.PastCode.GDcharecters2Objects2= [];
gdjs.PastCode.GDcharecters2Objects3= [];
gdjs.PastCode.GDcharecters2Objects4= [];
gdjs.PastCode.GDShootingstarObjects1= [];
gdjs.PastCode.GDShootingstarObjects2= [];
gdjs.PastCode.GDShootingstarObjects3= [];
gdjs.PastCode.GDShootingstarObjects4= [];
gdjs.PastCode.GDShootingstar2Objects1= [];
gdjs.PastCode.GDShootingstar2Objects2= [];
gdjs.PastCode.GDShootingstar2Objects3= [];
gdjs.PastCode.GDShootingstar2Objects4= [];
gdjs.PastCode.GDWallObjects1= [];
gdjs.PastCode.GDWallObjects2= [];
gdjs.PastCode.GDWallObjects3= [];
gdjs.PastCode.GDWallObjects4= [];
gdjs.PastCode.GDfloorObjects1= [];
gdjs.PastCode.GDfloorObjects2= [];
gdjs.PastCode.GDfloorObjects3= [];
gdjs.PastCode.GDfloorObjects4= [];
gdjs.PastCode.GDdoorsObjects1= [];
gdjs.PastCode.GDdoorsObjects2= [];
gdjs.PastCode.GDdoorsObjects3= [];
gdjs.PastCode.GDdoorsObjects4= [];
gdjs.PastCode.GDobjectsObjects1= [];
gdjs.PastCode.GDobjectsObjects2= [];
gdjs.PastCode.GDobjectsObjects3= [];
gdjs.PastCode.GDobjectsObjects4= [];
gdjs.PastCode.GDwallobjectObjects1= [];
gdjs.PastCode.GDwallobjectObjects2= [];
gdjs.PastCode.GDwallobjectObjects3= [];
gdjs.PastCode.GDwallobjectObjects4= [];
gdjs.PastCode.GDwindowObjects1= [];
gdjs.PastCode.GDwindowObjects2= [];
gdjs.PastCode.GDwindowObjects3= [];
gdjs.PastCode.GDwindowObjects4= [];
gdjs.PastCode.GDrailObjects1= [];
gdjs.PastCode.GDrailObjects2= [];
gdjs.PastCode.GDrailObjects3= [];
gdjs.PastCode.GDrailObjects4= [];
gdjs.PastCode.GDplayerObjects1= [];
gdjs.PastCode.GDplayerObjects2= [];
gdjs.PastCode.GDplayerObjects3= [];
gdjs.PastCode.GDplayerObjects4= [];
gdjs.PastCode.GDhitboxObjects1= [];
gdjs.PastCode.GDhitboxObjects2= [];
gdjs.PastCode.GDhitboxObjects3= [];
gdjs.PastCode.GDhitboxObjects4= [];
gdjs.PastCode.GDMainlightObjects1= [];
gdjs.PastCode.GDMainlightObjects2= [];
gdjs.PastCode.GDMainlightObjects3= [];
gdjs.PastCode.GDMainlightObjects4= [];
gdjs.PastCode.GDsmalllightObjects1= [];
gdjs.PastCode.GDsmalllightObjects2= [];
gdjs.PastCode.GDsmalllightObjects3= [];
gdjs.PastCode.GDsmalllightObjects4= [];
gdjs.PastCode.GDNewBitmapTextObjects1= [];
gdjs.PastCode.GDNewBitmapTextObjects2= [];
gdjs.PastCode.GDNewBitmapTextObjects3= [];
gdjs.PastCode.GDNewBitmapTextObjects4= [];
gdjs.PastCode.GDtask_9595barObjects1= [];
gdjs.PastCode.GDtask_9595barObjects2= [];
gdjs.PastCode.GDtask_9595barObjects3= [];
gdjs.PastCode.GDtask_9595barObjects4= [];
gdjs.PastCode.GDcharectersObjects1= [];
gdjs.PastCode.GDcharectersObjects2= [];
gdjs.PastCode.GDcharectersObjects3= [];
gdjs.PastCode.GDcharectersObjects4= [];
gdjs.PastCode.GDcharecters22Objects1= [];
gdjs.PastCode.GDcharecters22Objects2= [];
gdjs.PastCode.GDcharecters22Objects3= [];
gdjs.PastCode.GDcharecters22Objects4= [];
gdjs.PastCode.GDPauseObjects1= [];
gdjs.PastCode.GDPauseObjects2= [];
gdjs.PastCode.GDPauseObjects3= [];
gdjs.PastCode.GDPauseObjects4= [];
gdjs.PastCode.GDresumeObjects1= [];
gdjs.PastCode.GDresumeObjects2= [];
gdjs.PastCode.GDresumeObjects3= [];
gdjs.PastCode.GDresumeObjects4= [];
gdjs.PastCode.GDQuit_95952Objects1= [];
gdjs.PastCode.GDQuit_95952Objects2= [];
gdjs.PastCode.GDQuit_95952Objects3= [];
gdjs.PastCode.GDQuit_95952Objects4= [];
gdjs.PastCode.GDpause_9595menuObjects1= [];
gdjs.PastCode.GDpause_9595menuObjects2= [];
gdjs.PastCode.GDpause_9595menuObjects3= [];
gdjs.PastCode.GDpause_9595menuObjects4= [];
gdjs.PastCode.GDHimaObjects1= [];
gdjs.PastCode.GDHimaObjects2= [];
gdjs.PastCode.GDHimaObjects3= [];
gdjs.PastCode.GDHimaObjects4= [];
gdjs.PastCode.GDLayaObjects1= [];
gdjs.PastCode.GDLayaObjects2= [];
gdjs.PastCode.GDLayaObjects3= [];
gdjs.PastCode.GDLayaObjects4= [];
gdjs.PastCode.GDJoystickObjects1= [];
gdjs.PastCode.GDJoystickObjects2= [];
gdjs.PastCode.GDJoystickObjects3= [];
gdjs.PastCode.GDJoystickObjects4= [];
gdjs.PastCode.GDE_9595buttonObjects1= [];
gdjs.PastCode.GDE_9595buttonObjects2= [];
gdjs.PastCode.GDE_9595buttonObjects3= [];
gdjs.PastCode.GDE_9595buttonObjects4= [];


gdjs.PastCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.PastCode.GDplayerObjects2, gdjs.PastCode.GDplayerObjects3);

{for(var i = 0, len = gdjs.PastCode.GDplayerObjects3.length ;i < len;++i) {
    gdjs.PastCode.GDplayerObjects3[i].getBehavior("Flippable").flipX(false);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if (isConditionTrue_0) {
/* Reuse gdjs.PastCode.GDplayerObjects2 */
{for(var i = 0, len = gdjs.PastCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.PastCode.GDplayerObjects2[i].getBehavior("Flippable").flipX(true);
}
}}

}


};gdjs.PastCode.mapOfGDgdjs_9546PastCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.PastCode.GDplayerObjects2});
gdjs.PastCode.mapOfGDgdjs_9546PastCode_9546GDWallObjects2Objects = Hashtable.newFrom({"Wall": gdjs.PastCode.GDWallObjects2});
gdjs.PastCode.mapOfGDgdjs_9546PastCode_9546GDWallObjects2Objects = Hashtable.newFrom({"Wall": gdjs.PastCode.GDWallObjects2});
gdjs.PastCode.mapOfGDgdjs_9546PastCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.PastCode.GDplayerObjects2});
gdjs.PastCode.mapOfGDgdjs_9546PastCode_9546GDhitboxObjects2Objects = Hashtable.newFrom({"hitbox": gdjs.PastCode.GDhitboxObjects2});
gdjs.PastCode.mapOfGDgdjs_9546PastCode_9546GDhitboxObjects2Objects = Hashtable.newFrom({"hitbox": gdjs.PastCode.GDhitboxObjects2});
gdjs.PastCode.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.PastCode.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PastCode.GDplayerObjects2.length;i<l;++i) {
    if ( gdjs.PastCode.GDplayerObjects2[i].getBehavior("TopDownMovement").isMoving() ) {
        isConditionTrue_0 = true;
        gdjs.PastCode.GDplayerObjects2[k] = gdjs.PastCode.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.PastCode.GDplayerObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.PastCode.GDplayerObjects2 */
{for(var i = 0, len = gdjs.PastCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.PastCode.GDplayerObjects2[i].getBehavior("Animation").setAnimationName("player-walk");
}
}
{ //Subevents
gdjs.PastCode.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.PastCode.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PastCode.GDplayerObjects2.length;i<l;++i) {
    if ( !(gdjs.PastCode.GDplayerObjects2[i].getBehavior("TopDownMovement").isMoving()) ) {
        isConditionTrue_0 = true;
        gdjs.PastCode.GDplayerObjects2[k] = gdjs.PastCode.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.PastCode.GDplayerObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.PastCode.GDplayerObjects2 */
{for(var i = 0, len = gdjs.PastCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.PastCode.GDplayerObjects2[i].getBehavior("Animation").setAnimationName("player");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Wall"), gdjs.PastCode.GDWallObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.PastCode.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PastCode.mapOfGDgdjs_9546PastCode_9546GDplayerObjects2Objects, gdjs.PastCode.mapOfGDgdjs_9546PastCode_9546GDWallObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.PastCode.GDWallObjects2 */
/* Reuse gdjs.PastCode.GDplayerObjects2 */
{for(var i = 0, len = gdjs.PastCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.PastCode.GDplayerObjects2[i].separateFromObjectsList(gdjs.PastCode.mapOfGDgdjs_9546PastCode_9546GDWallObjects2Objects, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("hitbox"), gdjs.PastCode.GDhitboxObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.PastCode.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PastCode.mapOfGDgdjs_9546PastCode_9546GDplayerObjects2Objects, gdjs.PastCode.mapOfGDgdjs_9546PastCode_9546GDhitboxObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.PastCode.GDhitboxObjects2 */
/* Reuse gdjs.PastCode.GDplayerObjects2 */
{for(var i = 0, len = gdjs.PastCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.PastCode.GDplayerObjects2[i].separateFromObjectsList(gdjs.PastCode.mapOfGDgdjs_9546PastCode_9546GDhitboxObjects2Objects, false);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.PastCode.GDplayerObjects2);
{for(var i = 0, len = gdjs.PastCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.PastCode.GDplayerObjects2[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "s");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.PastCode.GDplayerObjects2);
{for(var i = 0, len = gdjs.PastCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.PastCode.GDplayerObjects2[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.PastCode.GDplayerObjects2);
{for(var i = 0, len = gdjs.PastCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.PastCode.GDplayerObjects2[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.PastCode.GDplayerObjects1);
{for(var i = 0, len = gdjs.PastCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.PastCode.GDplayerObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


};gdjs.PastCode.mapOfGDgdjs_9546PastCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.PastCode.GDplayerObjects2});
gdjs.PastCode.mapOfGDgdjs_9546PastCode_9546GDdoorsObjects2Objects = Hashtable.newFrom({"doors": gdjs.PastCode.GDdoorsObjects2});
gdjs.PastCode.mapOfGDgdjs_9546PastCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.PastCode.GDplayerObjects2});
gdjs.PastCode.mapOfGDgdjs_9546PastCode_9546GDdoorsObjects2Objects = Hashtable.newFrom({"doors": gdjs.PastCode.GDdoorsObjects2});
gdjs.PastCode.asyncCallback29460132 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.PastCode.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Past", false);
}gdjs.PastCode.localVariables.length = 0;
}
gdjs.PastCode.eventsList2 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.PastCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.PastCode.asyncCallback29460132(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.PastCode.asyncCallback29459476 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.PastCode.localVariables);
gdjs.copyArray(runtimeScene.getObjects("transition"), gdjs.PastCode.GDtransitionObjects3);
{runtimeScene.getGame().getVariables().getFromIndex(0).setString("Lift");
}{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(4);
}{for(var i = 0, len = gdjs.PastCode.GDtransitionObjects3.length ;i < len;++i) {
    gdjs.PastCode.GDtransitionObjects3[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 0.2, "Flash", "Forward", 100, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.PastCode.eventsList2(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.PastCode.localVariables.length = 0;
}
gdjs.PastCode.eventsList3 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.PastCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.PastCode.asyncCallback29459476(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.PastCode.mapOfGDgdjs_9546PastCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.PastCode.GDplayerObjects2});
gdjs.PastCode.mapOfGDgdjs_9546PastCode_9546GDdoorsObjects2Objects = Hashtable.newFrom({"doors": gdjs.PastCode.GDdoorsObjects2});
gdjs.PastCode.asyncCallback29463380 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.PastCode.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Past", false);
}gdjs.PastCode.localVariables.length = 0;
}
gdjs.PastCode.eventsList4 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.PastCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.PastCode.asyncCallback29463380(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.PastCode.asyncCallback29460980 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.PastCode.localVariables);
gdjs.copyArray(runtimeScene.getObjects("transition"), gdjs.PastCode.GDtransitionObjects3);
{runtimeScene.getGame().getVariables().getFromIndex(0).setString("Lift");
}{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(1);
}{for(var i = 0, len = gdjs.PastCode.GDtransitionObjects3.length ;i < len;++i) {
    gdjs.PastCode.GDtransitionObjects3[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 0.2, "Flash", "Forward", 100, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.PastCode.eventsList4(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.PastCode.localVariables.length = 0;
}
gdjs.PastCode.eventsList5 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.PastCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.PastCode.asyncCallback29460980(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.PastCode.mapOfGDgdjs_9546PastCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.PastCode.GDplayerObjects2});
gdjs.PastCode.mapOfGDgdjs_9546PastCode_9546GDdoorsObjects2Objects = Hashtable.newFrom({"doors": gdjs.PastCode.GDdoorsObjects2});
gdjs.PastCode.mapOfGDgdjs_9546PastCode_9546GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.PastCode.GDplayerObjects1});
gdjs.PastCode.mapOfGDgdjs_9546PastCode_9546GDdoorsObjects1Objects = Hashtable.newFrom({"doors": gdjs.PastCode.GDdoorsObjects1});
gdjs.PastCode.eventsList6 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("doors"), gdjs.PastCode.GDdoorsObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.PastCode.GDplayerObjects2);
gdjs.PastCode.GDE_9595buttonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PastCode.mapOfGDgdjs_9546PastCode_9546GDplayerObjects2Objects, gdjs.PastCode.mapOfGDgdjs_9546PastCode_9546GDdoorsObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PastCode.GDdoorsObjects2.length;i<l;++i) {
    if ( gdjs.PastCode.GDdoorsObjects2[i].getVariableString(gdjs.PastCode.GDdoorsObjects2[i].getVariables().getFromIndex(0)) != "Lift" ) {
        isConditionTrue_0 = true;
        gdjs.PastCode.GDdoorsObjects2[k] = gdjs.PastCode.GDdoorsObjects2[i];
        ++k;
    }
}
gdjs.PastCode.GDdoorsObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.PastCode.GDE_9595buttonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.PastCode.GDE_9595buttonObjects3);
for (var i = 0, k = 0, l = gdjs.PastCode.GDE_9595buttonObjects3.length;i<l;++i) {
    if ( gdjs.PastCode.GDE_9595buttonObjects3[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.PastCode.GDE_9595buttonObjects3[k] = gdjs.PastCode.GDE_9595buttonObjects3[i];
        ++k;
    }
}
gdjs.PastCode.GDE_9595buttonObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.PastCode.GDE_9595buttonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.PastCode.GDE_9595buttonObjects2_1final.indexOf(gdjs.PastCode.GDE_9595buttonObjects3[j]) === -1 )
            gdjs.PastCode.GDE_9595buttonObjects2_1final.push(gdjs.PastCode.GDE_9595buttonObjects3[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.PastCode.GDE_9595buttonObjects2_1final, gdjs.PastCode.GDE_9595buttonObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "locked") >= 2;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29457028);
}
}
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "door-bang-1wav-14449.mp3", false, 100, 1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "locked");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("doors"), gdjs.PastCode.GDdoorsObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.PastCode.GDplayerObjects2);
gdjs.PastCode.GDE_9595buttonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PastCode.mapOfGDgdjs_9546PastCode_9546GDplayerObjects2Objects, gdjs.PastCode.mapOfGDgdjs_9546PastCode_9546GDdoorsObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PastCode.GDdoorsObjects2.length;i<l;++i) {
    if ( gdjs.PastCode.GDdoorsObjects2[i].getVariableString(gdjs.PastCode.GDdoorsObjects2[i].getVariables().getFromIndex(0)) == "Lift" ) {
        isConditionTrue_0 = true;
        gdjs.PastCode.GDdoorsObjects2[k] = gdjs.PastCode.GDdoorsObjects2[i];
        ++k;
    }
}
gdjs.PastCode.GDdoorsObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PastCode.GDdoorsObjects2.length;i<l;++i) {
    if ( gdjs.PastCode.GDdoorsObjects2[i].getVariableNumber(gdjs.PastCode.GDdoorsObjects2[i].getVariables().getFromIndex(1)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.PastCode.GDdoorsObjects2[k] = gdjs.PastCode.GDdoorsObjects2[i];
        ++k;
    }
}
gdjs.PastCode.GDdoorsObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.PastCode.GDE_9595buttonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.PastCode.GDE_9595buttonObjects3);
for (var i = 0, k = 0, l = gdjs.PastCode.GDE_9595buttonObjects3.length;i<l;++i) {
    if ( gdjs.PastCode.GDE_9595buttonObjects3[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.PastCode.GDE_9595buttonObjects3[k] = gdjs.PastCode.GDE_9595buttonObjects3[i];
        ++k;
    }
}
gdjs.PastCode.GDE_9595buttonObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.PastCode.GDE_9595buttonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.PastCode.GDE_9595buttonObjects2_1final.indexOf(gdjs.PastCode.GDE_9595buttonObjects3[j]) === -1 )
            gdjs.PastCode.GDE_9595buttonObjects2_1final.push(gdjs.PastCode.GDE_9595buttonObjects3[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.PastCode.GDE_9595buttonObjects2_1final, gdjs.PastCode.GDE_9595buttonObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29459244);
}
}
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "door-open-46756_nnWlox72.mp3", false, 100, 1);
}
{ //Subevents
gdjs.PastCode.eventsList3(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("doors"), gdjs.PastCode.GDdoorsObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.PastCode.GDplayerObjects2);
gdjs.PastCode.GDE_9595buttonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PastCode.mapOfGDgdjs_9546PastCode_9546GDplayerObjects2Objects, gdjs.PastCode.mapOfGDgdjs_9546PastCode_9546GDdoorsObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PastCode.GDdoorsObjects2.length;i<l;++i) {
    if ( gdjs.PastCode.GDdoorsObjects2[i].getVariableString(gdjs.PastCode.GDdoorsObjects2[i].getVariables().getFromIndex(0)) == "Lift" ) {
        isConditionTrue_0 = true;
        gdjs.PastCode.GDdoorsObjects2[k] = gdjs.PastCode.GDdoorsObjects2[i];
        ++k;
    }
}
gdjs.PastCode.GDdoorsObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PastCode.GDdoorsObjects2.length;i<l;++i) {
    if ( gdjs.PastCode.GDdoorsObjects2[i].getVariableNumber(gdjs.PastCode.GDdoorsObjects2[i].getVariables().getFromIndex(1)) == 4 ) {
        isConditionTrue_0 = true;
        gdjs.PastCode.GDdoorsObjects2[k] = gdjs.PastCode.GDdoorsObjects2[i];
        ++k;
    }
}
gdjs.PastCode.GDdoorsObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.PastCode.GDE_9595buttonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.PastCode.GDE_9595buttonObjects3);
for (var i = 0, k = 0, l = gdjs.PastCode.GDE_9595buttonObjects3.length;i<l;++i) {
    if ( gdjs.PastCode.GDE_9595buttonObjects3[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.PastCode.GDE_9595buttonObjects3[k] = gdjs.PastCode.GDE_9595buttonObjects3[i];
        ++k;
    }
}
gdjs.PastCode.GDE_9595buttonObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.PastCode.GDE_9595buttonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.PastCode.GDE_9595buttonObjects2_1final.indexOf(gdjs.PastCode.GDE_9595buttonObjects3[j]) === -1 )
            gdjs.PastCode.GDE_9595buttonObjects2_1final.push(gdjs.PastCode.GDE_9595buttonObjects3[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.PastCode.GDE_9595buttonObjects2_1final, gdjs.PastCode.GDE_9595buttonObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29462132);
}
}
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "door-open-46756_nnWlox72.mp3", false, 100, 1);
}
{ //Subevents
gdjs.PastCode.eventsList5(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("doors"), gdjs.PastCode.GDdoorsObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.PastCode.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PastCode.mapOfGDgdjs_9546PastCode_9546GDplayerObjects2Objects, gdjs.PastCode.mapOfGDgdjs_9546PastCode_9546GDdoorsObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29464268);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewBitmapText"), gdjs.PastCode.GDNewBitmapTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("task_bar"), gdjs.PastCode.GDtask_9595barObjects2);
{for(var i = 0, len = gdjs.PastCode.GDtask_9595barObjects2.length ;i < len;++i) {
    gdjs.PastCode.GDtask_9595barObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.PastCode.GDNewBitmapTextObjects2.length ;i < len;++i) {
    gdjs.PastCode.GDNewBitmapTextObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.PastCode.GDNewBitmapTextObjects2.length ;i < len;++i) {
    gdjs.PastCode.GDNewBitmapTextObjects2[i].getBehavior("Text").setText("Enter?");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("doors"), gdjs.PastCode.GDdoorsObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.PastCode.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PastCode.mapOfGDgdjs_9546PastCode_9546GDplayerObjects1Objects, gdjs.PastCode.mapOfGDgdjs_9546PastCode_9546GDdoorsObjects1Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29465412);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewBitmapText"), gdjs.PastCode.GDNewBitmapTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("task_bar"), gdjs.PastCode.GDtask_9595barObjects1);
{for(var i = 0, len = gdjs.PastCode.GDtask_9595barObjects1.length ;i < len;++i) {
    gdjs.PastCode.GDtask_9595barObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.PastCode.GDNewBitmapTextObjects1.length ;i < len;++i) {
    gdjs.PastCode.GDNewBitmapTextObjects1[i].hide();
}
}}

}


};gdjs.PastCode.mapOfGDgdjs_9546PastCode_9546GDplayerObjects3Objects = Hashtable.newFrom({"player": gdjs.PastCode.GDplayerObjects3});
gdjs.PastCode.mapOfGDgdjs_9546PastCode_9546GDShootingstarObjects3Objects = Hashtable.newFrom({"Shootingstar": gdjs.PastCode.GDShootingstarObjects3});
gdjs.PastCode.asyncCallback29469636 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.PastCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("Shootingstar"), gdjs.PastCode.GDShootingstarObjects4);

{for(var i = 0, len = gdjs.PastCode.GDShootingstarObjects4.length ;i < len;++i) {
    gdjs.PastCode.GDShootingstarObjects4[i].activateBehavior("BoidsMovement", true);
}
}{for(var i = 0, len = gdjs.PastCode.GDShootingstarObjects4.length ;i < len;++i) {
    gdjs.PastCode.GDShootingstarObjects4[i].getBehavior("Animation").setAnimationName("idle");
}
}gdjs.PastCode.localVariables.length = 0;
}
gdjs.PastCode.eventsList7 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.PastCode.localVariables);
for (const obj of gdjs.PastCode.GDShootingstarObjects3) asyncObjectsList.addObject("Shootingstar", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.PastCode.asyncCallback29469636(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.PastCode.mapOfGDgdjs_9546PastCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.PastCode.GDplayerObjects2});
gdjs.PastCode.mapOfGDgdjs_9546PastCode_9546GDShootingstarObjects2Objects = Hashtable.newFrom({"Shootingstar": gdjs.PastCode.GDShootingstarObjects2});
gdjs.PastCode.asyncCallback29473068 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.PastCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("Shootingstar"), gdjs.PastCode.GDShootingstarObjects3);

{for(var i = 0, len = gdjs.PastCode.GDShootingstarObjects3.length ;i < len;++i) {
    gdjs.PastCode.GDShootingstarObjects3[i].activateBehavior("BoidsMovement", true);
}
}{for(var i = 0, len = gdjs.PastCode.GDShootingstarObjects3.length ;i < len;++i) {
    gdjs.PastCode.GDShootingstarObjects3[i].getBehavior("Animation").setAnimationName("idle");
}
}gdjs.PastCode.localVariables.length = 0;
}
gdjs.PastCode.eventsList8 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.PastCode.localVariables);
for (const obj of gdjs.PastCode.GDShootingstarObjects2) asyncObjectsList.addObject("Shootingstar", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.PastCode.asyncCallback29473068(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.PastCode.eventsList9 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Shootingstar"), gdjs.PastCode.GDShootingstarObjects3);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.PastCode.GDplayerObjects3);
gdjs.PastCode.GDE_9595buttonObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.PastCode.GDE_9595buttonObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.PastCode.GDE_9595buttonObjects4);
for (var i = 0, k = 0, l = gdjs.PastCode.GDE_9595buttonObjects4.length;i<l;++i) {
    if ( gdjs.PastCode.GDE_9595buttonObjects4[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.PastCode.GDE_9595buttonObjects4[k] = gdjs.PastCode.GDE_9595buttonObjects4[i];
        ++k;
    }
}
gdjs.PastCode.GDE_9595buttonObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.PastCode.GDE_9595buttonObjects4.length; j < jLen ; ++j) {
        if ( gdjs.PastCode.GDE_9595buttonObjects3_1final.indexOf(gdjs.PastCode.GDE_9595buttonObjects4[j]) === -1 )
            gdjs.PastCode.GDE_9595buttonObjects3_1final.push(gdjs.PastCode.GDE_9595buttonObjects4[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.PastCode.GDE_9595buttonObjects3_1final, gdjs.PastCode.GDE_9595buttonObjects3);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.PastCode.mapOfGDgdjs_9546PastCode_9546GDplayerObjects3Objects, gdjs.PastCode.mapOfGDgdjs_9546PastCode_9546GDShootingstarObjects3Objects, 80, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PastCode.GDShootingstarObjects3.length;i<l;++i) {
    if ( gdjs.PastCode.GDShootingstarObjects3[i].getX() < (( gdjs.PastCode.GDplayerObjects3.length === 0 ) ? 0 :gdjs.PastCode.GDplayerObjects3[0].getCenterXInScene()) ) {
        isConditionTrue_0 = true;
        gdjs.PastCode.GDShootingstarObjects3[k] = gdjs.PastCode.GDShootingstarObjects3[i];
        ++k;
    }
}
gdjs.PastCode.GDShootingstarObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "conversation"));
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Name"), gdjs.PastCode.GDNameObjects3);
/* Reuse gdjs.PastCode.GDShootingstarObjects3 */
gdjs.copyArray(runtimeScene.getObjects("Shootingstar2"), gdjs.PastCode.GDShootingstar2Objects3);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollspeed");
}{gdjs.dialogueTree.startFrom("Start");
}{for(var i = 0, len = gdjs.PastCode.GDNameObjects3.length ;i < len;++i) {
    gdjs.PastCode.GDNameObjects3[i].getBehavior("Text").setText("ShootingStar");
}
}{for(var i = 0, len = gdjs.PastCode.GDShootingstar2Objects3.length ;i < len;++i) {
    gdjs.PastCode.GDShootingstar2Objects3[i].resetTimer("dance");
}
}{for(var i = 0, len = gdjs.PastCode.GDShootingstarObjects3.length ;i < len;++i) {
    gdjs.PastCode.GDShootingstarObjects3[i].activateBehavior("BoidsMovement", false);
}
}{for(var i = 0, len = gdjs.PastCode.GDShootingstarObjects3.length ;i < len;++i) {
    gdjs.PastCode.GDShootingstarObjects3[i].getBehavior("Flippable").flipX(true);
}
}{for(var i = 0, len = gdjs.PastCode.GDShootingstarObjects3.length ;i < len;++i) {
    gdjs.PastCode.GDShootingstarObjects3[i].getBehavior("Animation").setAnimationName("alert");
}
}
{ //Subevents
gdjs.PastCode.eventsList7(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Shootingstar"), gdjs.PastCode.GDShootingstarObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.PastCode.GDplayerObjects2);
gdjs.PastCode.GDE_9595buttonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.PastCode.GDE_9595buttonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.PastCode.GDE_9595buttonObjects3);
for (var i = 0, k = 0, l = gdjs.PastCode.GDE_9595buttonObjects3.length;i<l;++i) {
    if ( gdjs.PastCode.GDE_9595buttonObjects3[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.PastCode.GDE_9595buttonObjects3[k] = gdjs.PastCode.GDE_9595buttonObjects3[i];
        ++k;
    }
}
gdjs.PastCode.GDE_9595buttonObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.PastCode.GDE_9595buttonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.PastCode.GDE_9595buttonObjects2_1final.indexOf(gdjs.PastCode.GDE_9595buttonObjects3[j]) === -1 )
            gdjs.PastCode.GDE_9595buttonObjects2_1final.push(gdjs.PastCode.GDE_9595buttonObjects3[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.PastCode.GDE_9595buttonObjects2_1final, gdjs.PastCode.GDE_9595buttonObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.PastCode.mapOfGDgdjs_9546PastCode_9546GDplayerObjects2Objects, gdjs.PastCode.mapOfGDgdjs_9546PastCode_9546GDShootingstarObjects2Objects, 80, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PastCode.GDShootingstarObjects2.length;i<l;++i) {
    if ( !(gdjs.PastCode.GDShootingstarObjects2[i].getX() < (( gdjs.PastCode.GDplayerObjects2.length === 0 ) ? 0 :gdjs.PastCode.GDplayerObjects2[0].getCenterXInScene())) ) {
        isConditionTrue_0 = true;
        gdjs.PastCode.GDShootingstarObjects2[k] = gdjs.PastCode.GDShootingstarObjects2[i];
        ++k;
    }
}
gdjs.PastCode.GDShootingstarObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "conversation"));
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Name"), gdjs.PastCode.GDNameObjects2);
/* Reuse gdjs.PastCode.GDShootingstarObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Shootingstar2"), gdjs.PastCode.GDShootingstar2Objects2);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollspeed");
}{gdjs.dialogueTree.startFrom("Start");
}{for(var i = 0, len = gdjs.PastCode.GDNameObjects2.length ;i < len;++i) {
    gdjs.PastCode.GDNameObjects2[i].getBehavior("Text").setText("ShootingStar");
}
}{for(var i = 0, len = gdjs.PastCode.GDShootingstar2Objects2.length ;i < len;++i) {
    gdjs.PastCode.GDShootingstar2Objects2[i].resetTimer("dance");
}
}{for(var i = 0, len = gdjs.PastCode.GDShootingstarObjects2.length ;i < len;++i) {
    gdjs.PastCode.GDShootingstarObjects2[i].activateBehavior("BoidsMovement", false);
}
}{for(var i = 0, len = gdjs.PastCode.GDShootingstarObjects2.length ;i < len;++i) {
    gdjs.PastCode.GDShootingstarObjects2[i].getBehavior("Flippable").flipX(false);
}
}
{ //Subevents
gdjs.PastCode.eventsList8(runtimeScene);} //End of subevents
}

}


};gdjs.PastCode.mapOfGDgdjs_9546PastCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.PastCode.GDplayerObjects2});
gdjs.PastCode.mapOfGDgdjs_9546PastCode_9546GDShootingstarObjects2Objects = Hashtable.newFrom({"Shootingstar": gdjs.PastCode.GDShootingstarObjects2});
gdjs.PastCode.mapOfGDgdjs_9546PastCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.PastCode.GDplayerObjects2});
gdjs.PastCode.mapOfGDgdjs_9546PastCode_9546GDShootingstarObjects2Objects = Hashtable.newFrom({"Shootingstar": gdjs.PastCode.GDShootingstarObjects2});
gdjs.PastCode.eventsList10 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "scrollspeed") >= runtimeScene.getGame().getVariables().getFromIndex(2).getAsNumber();
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.hasClippedScrollingCompleted());
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "New sound effect", false, 50, gdjs.random(2));
}{gdjs.dialogueTree.scrollClippedText();
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollspeed");
}}

}


{

gdjs.PastCode.GDE_9595buttonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.PastCode.GDE_9595buttonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.PastCode.GDE_9595buttonObjects3);
for (var i = 0, k = 0, l = gdjs.PastCode.GDE_9595buttonObjects3.length;i<l;++i) {
    if ( gdjs.PastCode.GDE_9595buttonObjects3[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.PastCode.GDE_9595buttonObjects3[k] = gdjs.PastCode.GDE_9595buttonObjects3[i];
        ++k;
    }
}
gdjs.PastCode.GDE_9595buttonObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.PastCode.GDE_9595buttonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.PastCode.GDE_9595buttonObjects2_1final.indexOf(gdjs.PastCode.GDE_9595buttonObjects3[j]) === -1 )
            gdjs.PastCode.GDE_9595buttonObjects2_1final.push(gdjs.PastCode.GDE_9595buttonObjects3[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.PastCode.GDE_9595buttonObjects2_1final, gdjs.PastCode.GDE_9595buttonObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.dialogueTree.hasClippedScrollingCompleted();
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29483028);
}
}
}
if (isConditionTrue_0) {
{gdjs.dialogueTree.goToNextDialogueLine();
}}

}


{

gdjs.PastCode.GDE_9595buttonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.PastCode.GDE_9595buttonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.PastCode.GDE_9595buttonObjects3);
for (var i = 0, k = 0, l = gdjs.PastCode.GDE_9595buttonObjects3.length;i<l;++i) {
    if ( gdjs.PastCode.GDE_9595buttonObjects3[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.PastCode.GDE_9595buttonObjects3[k] = gdjs.PastCode.GDE_9595buttonObjects3[i];
        ++k;
    }
}
gdjs.PastCode.GDE_9595buttonObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.PastCode.GDE_9595buttonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.PastCode.GDE_9595buttonObjects2_1final.indexOf(gdjs.PastCode.GDE_9595buttonObjects3[j]) === -1 )
            gdjs.PastCode.GDE_9595buttonObjects2_1final.push(gdjs.PastCode.GDE_9595buttonObjects3[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.PastCode.GDE_9595buttonObjects2_1final, gdjs.PastCode.GDE_9595buttonObjects2);
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(2).setNumber(0.01);
}}

}


{

gdjs.PastCode.GDE_9595buttonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.PastCode.GDE_9595buttonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.PastCode.GDE_9595buttonObjects3);
for (var i = 0, k = 0, l = gdjs.PastCode.GDE_9595buttonObjects3.length;i<l;++i) {
    if ( !(gdjs.PastCode.GDE_9595buttonObjects3[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_1 = true;
        gdjs.PastCode.GDE_9595buttonObjects3[k] = gdjs.PastCode.GDE_9595buttonObjects3[i];
        ++k;
    }
}
gdjs.PastCode.GDE_9595buttonObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.PastCode.GDE_9595buttonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.PastCode.GDE_9595buttonObjects2_1final.indexOf(gdjs.PastCode.GDE_9595buttonObjects3[j]) === -1 )
            gdjs.PastCode.GDE_9595buttonObjects2_1final.push(gdjs.PastCode.GDE_9595buttonObjects3[j]);
    }
}
}
{
isConditionTrue_1 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "e"));
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.PastCode.GDE_9595buttonObjects2_1final, gdjs.PastCode.GDE_9595buttonObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29485276);
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(2).setNumber(0.05);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Space");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29486260);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.PastCode.GDDialogeObjects1 */
{for(var i = 0, len = gdjs.PastCode.GDDialogeObjects1.length ;i < len;++i) {
    gdjs.PastCode.GDDialogeObjects1[i].getBehavior("Text").setText(gdjs.dialogueTree.getLineText());
}
}{gdjs.dialogueTree.goToNextDialogueLine();
}}

}


};gdjs.PastCode.eventsList11 = function(runtimeScene) {

{


gdjs.PastCode.eventsList9(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("Shootingstar"), gdjs.PastCode.GDShootingstarObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.PastCode.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.PastCode.mapOfGDgdjs_9546PastCode_9546GDplayerObjects2Objects, gdjs.PastCode.mapOfGDgdjs_9546PastCode_9546GDShootingstarObjects2Objects, 80, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29473284);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause"));
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewBitmapText"), gdjs.PastCode.GDNewBitmapTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("task_bar"), gdjs.PastCode.GDtask_9595barObjects2);
{for(var i = 0, len = gdjs.PastCode.GDtask_9595barObjects2.length ;i < len;++i) {
    gdjs.PastCode.GDtask_9595barObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.PastCode.GDNewBitmapTextObjects2.length ;i < len;++i) {
    gdjs.PastCode.GDNewBitmapTextObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.PastCode.GDNewBitmapTextObjects2.length ;i < len;++i) {
    gdjs.PastCode.GDNewBitmapTextObjects2[i].getBehavior("Text").setText("talk?");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Shootingstar"), gdjs.PastCode.GDShootingstarObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.PastCode.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.PastCode.mapOfGDgdjs_9546PastCode_9546GDplayerObjects2Objects, gdjs.PastCode.mapOfGDgdjs_9546PastCode_9546GDShootingstarObjects2Objects, 80, true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29475716);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewBitmapText"), gdjs.PastCode.GDNewBitmapTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("task_bar"), gdjs.PastCode.GDtask_9595barObjects2);
{for(var i = 0, len = gdjs.PastCode.GDtask_9595barObjects2.length ;i < len;++i) {
    gdjs.PastCode.GDtask_9595barObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.PastCode.GDNewBitmapTextObjects2.length ;i < len;++i) {
    gdjs.PastCode.GDNewBitmapTextObjects2[i].hide();
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.dialogueTree.isRunning();
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Joystick"), gdjs.PastCode.GDJoystickObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.PastCode.GDplayerObjects2);
{gdjs.evtTools.camera.showLayer(runtimeScene, "conversation");
}{for(var i = 0, len = gdjs.PastCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.PastCode.GDplayerObjects2[i].activateBehavior("TopDownMovement", false);
}
}{for(var i = 0, len = gdjs.PastCode.GDJoystickObjects2.length ;i < len;++i) {
    gdjs.PastCode.GDJoystickObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.PastCode.GDJoystickObjects2.length ;i < len;++i) {
    gdjs.PastCode.GDJoystickObjects2[i].ActivateControl(false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "scrollspeed") >= 2;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29478164);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Joystick"), gdjs.PastCode.GDJoystickObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.PastCode.GDplayerObjects2);
{gdjs.evtTools.camera.hideLayer(runtimeScene, "conversation");
}{for(var i = 0, len = gdjs.PastCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.PastCode.GDplayerObjects2[i].activateBehavior("TopDownMovement", true);
}
}{gdjs.evtTools.runtimeScene.removeTimer(runtimeScene, "scrollspeed");
}{for(var i = 0, len = gdjs.PastCode.GDJoystickObjects2.length ;i < len;++i) {
    gdjs.PastCode.GDJoystickObjects2[i].hide(false);
}
}{runtimeScene.getGame().getVariables().getFromIndex(0).setString("Lost in time");
}{runtimeScene.getGame().getVariables().getFromIndex(18).setNumber(3);
}{for(var i = 0, len = gdjs.PastCode.GDJoystickObjects2.length ;i < len;++i) {
    gdjs.PastCode.GDJoystickObjects2[i].ActivateControl(true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "School", false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.dialogueTree.isDialogueLineType("text");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Dialoge"), gdjs.PastCode.GDDialogeObjects1);
{for(var i = 0, len = gdjs.PastCode.GDDialogeObjects1.length ;i < len;++i) {
    gdjs.PastCode.GDDialogeObjects1[i].getBehavior("Text").setText(gdjs.dialogueTree.getClippedLineText());
}
}
{ //Subevents
gdjs.PastCode.eventsList10(runtimeScene);} //End of subevents
}

}


};gdjs.PastCode.eventsList12 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("pause_menu"), gdjs.PastCode.GDpause_9595menuObjects2);
{for(var i = 0, len = gdjs.PastCode.GDpause_9595menuObjects2.length ;i < len;++i) {
    gdjs.PastCode.GDpause_9595menuObjects2[i].getBehavior("Opacity").setOpacity(125);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Pause"), gdjs.PastCode.GDPauseObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PastCode.GDPauseObjects2.length;i<l;++i) {
    if ( gdjs.PastCode.GDPauseObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.PastCode.GDPauseObjects2[k] = gdjs.PastCode.GDPauseObjects2[i];
        ++k;
    }
}
gdjs.PastCode.GDPauseObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29488156);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.camera.showLayer(runtimeScene, "pause");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "ui");
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("resume"), gdjs.PastCode.GDresumeObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PastCode.GDresumeObjects2.length;i<l;++i) {
    if ( gdjs.PastCode.GDresumeObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.PastCode.GDresumeObjects2[k] = gdjs.PastCode.GDresumeObjects2[i];
        ++k;
    }
}
gdjs.PastCode.GDresumeObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29489420);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "pause");
}{gdjs.evtTools.camera.showLayer(runtimeScene, "ui");
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Quit_2"), gdjs.PastCode.GDQuit_95952Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PastCode.GDQuit_95952Objects1.length;i<l;++i) {
    if ( gdjs.PastCode.GDQuit_95952Objects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.PastCode.GDQuit_95952Objects1[k] = gdjs.PastCode.GDQuit_95952Objects1[i];
        ++k;
    }
}
gdjs.PastCode.GDQuit_95952Objects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29490700);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Main Menu", false);
}}

}


};gdjs.PastCode.eventsList13 = function(runtimeScene) {

{

gdjs.PastCode.GDJoystickObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.PastCode.GDJoystickObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Joystick"), gdjs.PastCode.GDJoystickObjects3);
for (var i = 0, k = 0, l = gdjs.PastCode.GDJoystickObjects3.length;i<l;++i) {
    if ( gdjs.PastCode.GDJoystickObjects3[i].IsDirectionPushed8Way("Right", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.PastCode.GDJoystickObjects3[k] = gdjs.PastCode.GDJoystickObjects3[i];
        ++k;
    }
}
gdjs.PastCode.GDJoystickObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.PastCode.GDJoystickObjects3.length; j < jLen ; ++j) {
        if ( gdjs.PastCode.GDJoystickObjects2_1final.indexOf(gdjs.PastCode.GDJoystickObjects3[j]) === -1 )
            gdjs.PastCode.GDJoystickObjects2_1final.push(gdjs.PastCode.GDJoystickObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Joystick"), gdjs.PastCode.GDJoystickObjects3);
for (var i = 0, k = 0, l = gdjs.PastCode.GDJoystickObjects3.length;i<l;++i) {
    if ( gdjs.PastCode.GDJoystickObjects3[i].IsDirectionPushed8Way("UpRight", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.PastCode.GDJoystickObjects3[k] = gdjs.PastCode.GDJoystickObjects3[i];
        ++k;
    }
}
gdjs.PastCode.GDJoystickObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.PastCode.GDJoystickObjects3.length; j < jLen ; ++j) {
        if ( gdjs.PastCode.GDJoystickObjects2_1final.indexOf(gdjs.PastCode.GDJoystickObjects3[j]) === -1 )
            gdjs.PastCode.GDJoystickObjects2_1final.push(gdjs.PastCode.GDJoystickObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Joystick"), gdjs.PastCode.GDJoystickObjects3);
for (var i = 0, k = 0, l = gdjs.PastCode.GDJoystickObjects3.length;i<l;++i) {
    if ( gdjs.PastCode.GDJoystickObjects3[i].IsDirectionPushed8Way("DownRight", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.PastCode.GDJoystickObjects3[k] = gdjs.PastCode.GDJoystickObjects3[i];
        ++k;
    }
}
gdjs.PastCode.GDJoystickObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.PastCode.GDJoystickObjects3.length; j < jLen ; ++j) {
        if ( gdjs.PastCode.GDJoystickObjects2_1final.indexOf(gdjs.PastCode.GDJoystickObjects3[j]) === -1 )
            gdjs.PastCode.GDJoystickObjects2_1final.push(gdjs.PastCode.GDJoystickObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.PastCode.GDJoystickObjects2_1final, gdjs.PastCode.GDJoystickObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29492084);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.PastCode.GDplayerObjects2);
{for(var i = 0, len = gdjs.PastCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.PastCode.GDplayerObjects2[i].getBehavior("Animation").setAnimationName("player-walk");
}
}{for(var i = 0, len = gdjs.PastCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.PastCode.GDplayerObjects2[i].getBehavior("Flippable").flipX(false);
}
}}

}


{

gdjs.PastCode.GDJoystickObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.PastCode.GDJoystickObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Joystick"), gdjs.PastCode.GDJoystickObjects3);
for (var i = 0, k = 0, l = gdjs.PastCode.GDJoystickObjects3.length;i<l;++i) {
    if ( gdjs.PastCode.GDJoystickObjects3[i].IsDirectionPushed8Way("Left", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.PastCode.GDJoystickObjects3[k] = gdjs.PastCode.GDJoystickObjects3[i];
        ++k;
    }
}
gdjs.PastCode.GDJoystickObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.PastCode.GDJoystickObjects3.length; j < jLen ; ++j) {
        if ( gdjs.PastCode.GDJoystickObjects2_1final.indexOf(gdjs.PastCode.GDJoystickObjects3[j]) === -1 )
            gdjs.PastCode.GDJoystickObjects2_1final.push(gdjs.PastCode.GDJoystickObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Joystick"), gdjs.PastCode.GDJoystickObjects3);
for (var i = 0, k = 0, l = gdjs.PastCode.GDJoystickObjects3.length;i<l;++i) {
    if ( gdjs.PastCode.GDJoystickObjects3[i].IsDirectionPushed8Way("DownLeft", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.PastCode.GDJoystickObjects3[k] = gdjs.PastCode.GDJoystickObjects3[i];
        ++k;
    }
}
gdjs.PastCode.GDJoystickObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.PastCode.GDJoystickObjects3.length; j < jLen ; ++j) {
        if ( gdjs.PastCode.GDJoystickObjects2_1final.indexOf(gdjs.PastCode.GDJoystickObjects3[j]) === -1 )
            gdjs.PastCode.GDJoystickObjects2_1final.push(gdjs.PastCode.GDJoystickObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Joystick"), gdjs.PastCode.GDJoystickObjects3);
for (var i = 0, k = 0, l = gdjs.PastCode.GDJoystickObjects3.length;i<l;++i) {
    if ( gdjs.PastCode.GDJoystickObjects3[i].IsDirectionPushed8Way("UpLeft", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.PastCode.GDJoystickObjects3[k] = gdjs.PastCode.GDJoystickObjects3[i];
        ++k;
    }
}
gdjs.PastCode.GDJoystickObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.PastCode.GDJoystickObjects3.length; j < jLen ; ++j) {
        if ( gdjs.PastCode.GDJoystickObjects2_1final.indexOf(gdjs.PastCode.GDJoystickObjects3[j]) === -1 )
            gdjs.PastCode.GDJoystickObjects2_1final.push(gdjs.PastCode.GDJoystickObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.PastCode.GDJoystickObjects2_1final, gdjs.PastCode.GDJoystickObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29494356);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.PastCode.GDplayerObjects2);
{for(var i = 0, len = gdjs.PastCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.PastCode.GDplayerObjects2[i].getBehavior("Animation").setAnimationName("player-walk");
}
}{for(var i = 0, len = gdjs.PastCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.PastCode.GDplayerObjects2[i].getBehavior("Flippable").flipX(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Joystick"), gdjs.PastCode.GDJoystickObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PastCode.GDJoystickObjects2.length;i<l;++i) {
    if ( !(gdjs.PastCode.GDJoystickObjects2[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.PastCode.GDJoystickObjects2[k] = gdjs.PastCode.GDJoystickObjects2[i];
        ++k;
    }
}
gdjs.PastCode.GDJoystickObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29495644);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.PastCode.GDplayerObjects2);
{for(var i = 0, len = gdjs.PastCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.PastCode.GDplayerObjects2[i].getBehavior("Animation").setAnimationName("player");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.PastCode.GDE_9595buttonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Joystick"), gdjs.PastCode.GDJoystickObjects2);
{gdjs.evtTools.camera.showLayer(runtimeScene, "Mobile");
}{for(var i = 0, len = gdjs.PastCode.GDJoystickObjects2.length ;i < len;++i) {
    gdjs.PastCode.GDJoystickObjects2[i].ActivateControl(true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.PastCode.GDE_9595buttonObjects2.length ;i < len;++i) {
    gdjs.PastCode.GDE_9595buttonObjects2[i].Activate(true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene));
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.PastCode.GDE_9595buttonObjects1);
gdjs.copyArray(runtimeScene.getObjects("Joystick"), gdjs.PastCode.GDJoystickObjects1);
{gdjs.evtTools.camera.hideLayer(runtimeScene, "Mobile");
}{for(var i = 0, len = gdjs.PastCode.GDJoystickObjects1.length ;i < len;++i) {
    gdjs.PastCode.GDJoystickObjects1[i].ActivateControl(false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.PastCode.GDE_9595buttonObjects1.length ;i < len;++i) {
    gdjs.PastCode.GDE_9595buttonObjects1[i].Activate(false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.PastCode.mapOfGDgdjs_9546PastCode_9546GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.PastCode.GDplayerObjects1});
gdjs.PastCode.mapOfGDgdjs_9546PastCode_9546GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.PastCode.GDplayerObjects1});
gdjs.PastCode.mapOfGDgdjs_9546PastCode_9546GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.PastCode.GDplayerObjects1});
gdjs.PastCode.mapOfGDgdjs_9546PastCode_9546GDareaObjects1Objects = Hashtable.newFrom({"area": gdjs.PastCode.GDareaObjects1});
gdjs.PastCode.eventsList14 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Shootingstar"), gdjs.PastCode.GDShootingstarObjects1);
gdjs.copyArray(runtimeScene.getObjects("area"), gdjs.PastCode.GDareaObjects1);
gdjs.copyArray(runtimeScene.getObjects("floor_3"), gdjs.PastCode.GDfloor_95953Objects1);
gdjs.copyArray(runtimeScene.getObjects("hitbox"), gdjs.PastCode.GDhitboxObjects1);
gdjs.copyArray(runtimeScene.getObjects("task_bar"), gdjs.PastCode.GDtask_9595barObjects1);
gdjs.copyArray(runtimeScene.getObjects("transition"), gdjs.PastCode.GDtransitionObjects1);
{for(var i = 0, len = gdjs.PastCode.GDShootingstarObjects1.length ;i < len;++i) {
    gdjs.PastCode.GDShootingstarObjects1[i].activateBehavior("BoidsMovement", false);
}
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 2.5, "", 0);
}{gdjs.evtTools.camera.setCameraY(runtimeScene, 675, "", 0);
}{for(var i = 0, len = gdjs.PastCode.GDhitboxObjects1.length ;i < len;++i) {
    gdjs.PastCode.GDhitboxObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.PastCode.GDareaObjects1.length ;i < len;++i) {
    gdjs.PastCode.GDareaObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.PastCode.GDtransitionObjects1.length ;i < len;++i) {
    gdjs.PastCode.GDtransitionObjects1[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 0.2, "Flash", "Backward", 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.PastCode.GDtask_9595barObjects1.length ;i < len;++i) {
    gdjs.PastCode.GDtask_9595barObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.PastCode.GDfloor_95953Objects1.length ;i < len;++i) {
    gdjs.PastCode.GDfloor_95953Objects1[i].SetLabelText("Floor:" + gdjs.PastCode.GDfloor_95953Objects1[i].getVariables().getFromIndex(0).getAsString(), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "locked");
}{gdjs.dialogueTree.loadFromJsonFile(runtimeScene, "Star");
}{for(var i = 0, len = gdjs.PastCode.GDShootingstarObjects1.length ;i < len;++i) {
    gdjs.PastCode.GDShootingstarObjects1[i].resetTimer("dance");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("doors"), gdjs.PastCode.GDdoorsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PastCode.GDdoorsObjects1.length;i<l;++i) {
    if ( gdjs.PastCode.GDdoorsObjects1[i].getVariableString(gdjs.PastCode.GDdoorsObjects1[i].getVariables().getFromIndex(0)) == runtimeScene.getGame().getVariables().getFromIndex(0).getAsString() ) {
        isConditionTrue_0 = true;
        gdjs.PastCode.GDdoorsObjects1[k] = gdjs.PastCode.GDdoorsObjects1[i];
        ++k;
    }
}
gdjs.PastCode.GDdoorsObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PastCode.GDdoorsObjects1.length;i<l;++i) {
    if ( gdjs.PastCode.GDdoorsObjects1[i].getVariableNumber(gdjs.PastCode.GDdoorsObjects1[i].getVariables().getFromIndex(1)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.PastCode.GDdoorsObjects1[k] = gdjs.PastCode.GDdoorsObjects1[i];
        ++k;
    }
}
gdjs.PastCode.GDdoorsObjects1.length = k;
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewParticlesEmitter"), gdjs.PastCode.GDNewParticlesEmitterObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewParticlesEmitter2"), gdjs.PastCode.GDNewParticlesEmitter2Objects1);
/* Reuse gdjs.PastCode.GDdoorsObjects1 */
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.PastCode.GDplayerObjects1);
{for(var i = 0, len = gdjs.PastCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.PastCode.GDplayerObjects1[i].setPosition((( gdjs.PastCode.GDdoorsObjects1.length === 0 ) ? 0 :gdjs.PastCode.GDdoorsObjects1[0].getPointX("Point")),(( gdjs.PastCode.GDdoorsObjects1.length === 0 ) ? 0 :gdjs.PastCode.GDdoorsObjects1[0].getPointY("Point")) - 15);
}
}{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.PastCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.PastCode.GDplayerObjects1[0].getPointX("")), "", 0);
}{gdjs.evtTools.camera.setCameraY(runtimeScene, (( gdjs.PastCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.PastCode.GDplayerObjects1[0].getPointY("")), "", 0);
}{for(var i = 0, len = gdjs.PastCode.GDNewParticlesEmitterObjects1.length ;i < len;++i) {
    gdjs.PastCode.GDNewParticlesEmitterObjects1[i].setY((( gdjs.PastCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.PastCode.GDplayerObjects1[0].getPointY("")) - 260);
}
}{for(var i = 0, len = gdjs.PastCode.GDNewParticlesEmitter2Objects1.length ;i < len;++i) {
    gdjs.PastCode.GDNewParticlesEmitter2Objects1[i].setY((( gdjs.PastCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.PastCode.GDplayerObjects1[0].getPointY("")) - 260);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("doors"), gdjs.PastCode.GDdoorsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PastCode.GDdoorsObjects1.length;i<l;++i) {
    if ( gdjs.PastCode.GDdoorsObjects1[i].getVariableString(gdjs.PastCode.GDdoorsObjects1[i].getVariables().getFromIndex(0)) == runtimeScene.getGame().getVariables().getFromIndex(0).getAsString() ) {
        isConditionTrue_0 = true;
        gdjs.PastCode.GDdoorsObjects1[k] = gdjs.PastCode.GDdoorsObjects1[i];
        ++k;
    }
}
gdjs.PastCode.GDdoorsObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PastCode.GDdoorsObjects1.length;i<l;++i) {
    if ( gdjs.PastCode.GDdoorsObjects1[i].getVariableNumber(gdjs.PastCode.GDdoorsObjects1[i].getVariables().getFromIndex(1)) == runtimeScene.getGame().getVariables().getFromIndex(1).getAsNumber() ) {
        isConditionTrue_0 = true;
        gdjs.PastCode.GDdoorsObjects1[k] = gdjs.PastCode.GDdoorsObjects1[i];
        ++k;
    }
}
gdjs.PastCode.GDdoorsObjects1.length = k;
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewParticlesEmitter"), gdjs.PastCode.GDNewParticlesEmitterObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewParticlesEmitter2"), gdjs.PastCode.GDNewParticlesEmitter2Objects1);
/* Reuse gdjs.PastCode.GDdoorsObjects1 */
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.PastCode.GDplayerObjects1);
{for(var i = 0, len = gdjs.PastCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.PastCode.GDplayerObjects1[i].setPosition((( gdjs.PastCode.GDdoorsObjects1.length === 0 ) ? 0 :gdjs.PastCode.GDdoorsObjects1[0].getPointX("Point")),(( gdjs.PastCode.GDdoorsObjects1.length === 0 ) ? 0 :gdjs.PastCode.GDdoorsObjects1[0].getPointY("Point")) - 15);
}
}{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.PastCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.PastCode.GDplayerObjects1[0].getPointX("")), "", 0);
}{gdjs.evtTools.camera.setCameraY(runtimeScene, (( gdjs.PastCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.PastCode.GDplayerObjects1[0].getPointY("")), "", 0);
}{for(var i = 0, len = gdjs.PastCode.GDNewParticlesEmitterObjects1.length ;i < len;++i) {
    gdjs.PastCode.GDNewParticlesEmitterObjects1[i].setY((( gdjs.PastCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.PastCode.GDplayerObjects1[0].getPointY("")) - 260);
}
}{for(var i = 0, len = gdjs.PastCode.GDNewParticlesEmitter2Objects1.length ;i < len;++i) {
    gdjs.PastCode.GDNewParticlesEmitter2Objects1[i].setY((( gdjs.PastCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.PastCode.GDplayerObjects1[0].getPointY("")) - 260);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("doors"), gdjs.PastCode.GDdoorsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "1";
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PastCode.GDdoorsObjects1.length;i<l;++i) {
    if ( gdjs.PastCode.GDdoorsObjects1[i].getVariableNumber(gdjs.PastCode.GDdoorsObjects1[i].getVariables().getFromIndex(1)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.PastCode.GDdoorsObjects1[k] = gdjs.PastCode.GDdoorsObjects1[i];
        ++k;
    }
}
gdjs.PastCode.GDdoorsObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PastCode.GDdoorsObjects1.length;i<l;++i) {
    if ( gdjs.PastCode.GDdoorsObjects1[i].getVariableString(gdjs.PastCode.GDdoorsObjects1[i].getVariables().getFromIndex(0)) == "02" ) {
        isConditionTrue_0 = true;
        gdjs.PastCode.GDdoorsObjects1[k] = gdjs.PastCode.GDdoorsObjects1[i];
        ++k;
    }
}
gdjs.PastCode.GDdoorsObjects1.length = k;
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewParticlesEmitter"), gdjs.PastCode.GDNewParticlesEmitterObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewParticlesEmitter2"), gdjs.PastCode.GDNewParticlesEmitter2Objects1);
/* Reuse gdjs.PastCode.GDdoorsObjects1 */
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.PastCode.GDplayerObjects1);
{for(var i = 0, len = gdjs.PastCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.PastCode.GDplayerObjects1[i].setPosition((( gdjs.PastCode.GDdoorsObjects1.length === 0 ) ? 0 :gdjs.PastCode.GDdoorsObjects1[0].getPointX("Point")),(( gdjs.PastCode.GDdoorsObjects1.length === 0 ) ? 0 :gdjs.PastCode.GDdoorsObjects1[0].getPointY("Point")) - 15);
}
}{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.PastCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.PastCode.GDplayerObjects1[0].getPointX("")), "", 0);
}{gdjs.evtTools.camera.setCameraY(runtimeScene, (( gdjs.PastCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.PastCode.GDplayerObjects1[0].getPointY("")), "", 0);
}{for(var i = 0, len = gdjs.PastCode.GDNewParticlesEmitterObjects1.length ;i < len;++i) {
    gdjs.PastCode.GDNewParticlesEmitterObjects1[i].setY((( gdjs.PastCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.PastCode.GDplayerObjects1[0].getPointY("")) - 260);
}
}{for(var i = 0, len = gdjs.PastCode.GDNewParticlesEmitter2Objects1.length ;i < len;++i) {
    gdjs.PastCode.GDNewParticlesEmitter2Objects1[i].setY((( gdjs.PastCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.PastCode.GDplayerObjects1[0].getPointY("")) - 260);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("doors"), gdjs.PastCode.GDdoorsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "2";
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PastCode.GDdoorsObjects1.length;i<l;++i) {
    if ( gdjs.PastCode.GDdoorsObjects1[i].getVariableNumber(gdjs.PastCode.GDdoorsObjects1[i].getVariables().getFromIndex(1)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.PastCode.GDdoorsObjects1[k] = gdjs.PastCode.GDdoorsObjects1[i];
        ++k;
    }
}
gdjs.PastCode.GDdoorsObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PastCode.GDdoorsObjects1.length;i<l;++i) {
    if ( gdjs.PastCode.GDdoorsObjects1[i].getVariableString(gdjs.PastCode.GDdoorsObjects1[i].getVariables().getFromIndex(0)) == "01" ) {
        isConditionTrue_0 = true;
        gdjs.PastCode.GDdoorsObjects1[k] = gdjs.PastCode.GDdoorsObjects1[i];
        ++k;
    }
}
gdjs.PastCode.GDdoorsObjects1.length = k;
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewParticlesEmitter"), gdjs.PastCode.GDNewParticlesEmitterObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewParticlesEmitter2"), gdjs.PastCode.GDNewParticlesEmitter2Objects1);
/* Reuse gdjs.PastCode.GDdoorsObjects1 */
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.PastCode.GDplayerObjects1);
{for(var i = 0, len = gdjs.PastCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.PastCode.GDplayerObjects1[i].setPosition((( gdjs.PastCode.GDdoorsObjects1.length === 0 ) ? 0 :gdjs.PastCode.GDdoorsObjects1[0].getPointX("Point")),(( gdjs.PastCode.GDdoorsObjects1.length === 0 ) ? 0 :gdjs.PastCode.GDdoorsObjects1[0].getPointY("Point")) - 15);
}
}{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.PastCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.PastCode.GDplayerObjects1[0].getPointX("")), "", 0);
}{gdjs.evtTools.camera.setCameraY(runtimeScene, (( gdjs.PastCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.PastCode.GDplayerObjects1[0].getPointY("")), "", 0);
}{for(var i = 0, len = gdjs.PastCode.GDNewParticlesEmitterObjects1.length ;i < len;++i) {
    gdjs.PastCode.GDNewParticlesEmitterObjects1[i].setY((( gdjs.PastCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.PastCode.GDplayerObjects1[0].getPointY("")) - 260);
}
}{for(var i = 0, len = gdjs.PastCode.GDNewParticlesEmitter2Objects1.length ;i < len;++i) {
    gdjs.PastCode.GDNewParticlesEmitter2Objects1[i].setY((( gdjs.PastCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.PastCode.GDplayerObjects1[0].getPointY("")) - 260);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("doors"), gdjs.PastCode.GDdoorsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "3";
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PastCode.GDdoorsObjects1.length;i<l;++i) {
    if ( gdjs.PastCode.GDdoorsObjects1[i].getVariableNumber(gdjs.PastCode.GDdoorsObjects1[i].getVariables().getFromIndex(1)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.PastCode.GDdoorsObjects1[k] = gdjs.PastCode.GDdoorsObjects1[i];
        ++k;
    }
}
gdjs.PastCode.GDdoorsObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PastCode.GDdoorsObjects1.length;i<l;++i) {
    if ( gdjs.PastCode.GDdoorsObjects1[i].getVariableString(gdjs.PastCode.GDdoorsObjects1[i].getVariables().getFromIndex(0)) == "04" ) {
        isConditionTrue_0 = true;
        gdjs.PastCode.GDdoorsObjects1[k] = gdjs.PastCode.GDdoorsObjects1[i];
        ++k;
    }
}
gdjs.PastCode.GDdoorsObjects1.length = k;
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewParticlesEmitter"), gdjs.PastCode.GDNewParticlesEmitterObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewParticlesEmitter2"), gdjs.PastCode.GDNewParticlesEmitter2Objects1);
/* Reuse gdjs.PastCode.GDdoorsObjects1 */
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.PastCode.GDplayerObjects1);
{for(var i = 0, len = gdjs.PastCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.PastCode.GDplayerObjects1[i].setPosition((( gdjs.PastCode.GDdoorsObjects1.length === 0 ) ? 0 :gdjs.PastCode.GDdoorsObjects1[0].getPointX("Point")),(( gdjs.PastCode.GDdoorsObjects1.length === 0 ) ? 0 :gdjs.PastCode.GDdoorsObjects1[0].getPointY("Point")) - 15);
}
}{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.PastCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.PastCode.GDplayerObjects1[0].getPointX("")), "", 0);
}{gdjs.evtTools.camera.setCameraY(runtimeScene, (( gdjs.PastCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.PastCode.GDplayerObjects1[0].getPointY("")), "", 0);
}{for(var i = 0, len = gdjs.PastCode.GDNewParticlesEmitterObjects1.length ;i < len;++i) {
    gdjs.PastCode.GDNewParticlesEmitterObjects1[i].setY((( gdjs.PastCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.PastCode.GDplayerObjects1[0].getPointY("")) - 260);
}
}{for(var i = 0, len = gdjs.PastCode.GDNewParticlesEmitter2Objects1.length ;i < len;++i) {
    gdjs.PastCode.GDNewParticlesEmitter2Objects1[i].setY((( gdjs.PastCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.PastCode.GDplayerObjects1[0].getPointY("")) - 260);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("doors"), gdjs.PastCode.GDdoorsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "4";
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PastCode.GDdoorsObjects1.length;i<l;++i) {
    if ( gdjs.PastCode.GDdoorsObjects1[i].getVariableNumber(gdjs.PastCode.GDdoorsObjects1[i].getVariables().getFromIndex(1)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.PastCode.GDdoorsObjects1[k] = gdjs.PastCode.GDdoorsObjects1[i];
        ++k;
    }
}
gdjs.PastCode.GDdoorsObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PastCode.GDdoorsObjects1.length;i<l;++i) {
    if ( gdjs.PastCode.GDdoorsObjects1[i].getVariableString(gdjs.PastCode.GDdoorsObjects1[i].getVariables().getFromIndex(0)) == "03" ) {
        isConditionTrue_0 = true;
        gdjs.PastCode.GDdoorsObjects1[k] = gdjs.PastCode.GDdoorsObjects1[i];
        ++k;
    }
}
gdjs.PastCode.GDdoorsObjects1.length = k;
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewParticlesEmitter"), gdjs.PastCode.GDNewParticlesEmitterObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewParticlesEmitter2"), gdjs.PastCode.GDNewParticlesEmitter2Objects1);
/* Reuse gdjs.PastCode.GDdoorsObjects1 */
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.PastCode.GDplayerObjects1);
{for(var i = 0, len = gdjs.PastCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.PastCode.GDplayerObjects1[i].setPosition((( gdjs.PastCode.GDdoorsObjects1.length === 0 ) ? 0 :gdjs.PastCode.GDdoorsObjects1[0].getPointX("Point")),(( gdjs.PastCode.GDdoorsObjects1.length === 0 ) ? 0 :gdjs.PastCode.GDdoorsObjects1[0].getPointY("Point")) - 15);
}
}{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.PastCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.PastCode.GDplayerObjects1[0].getPointX("")), "", 0);
}{gdjs.evtTools.camera.setCameraY(runtimeScene, (( gdjs.PastCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.PastCode.GDplayerObjects1[0].getPointY("")), "", 0);
}{for(var i = 0, len = gdjs.PastCode.GDNewParticlesEmitterObjects1.length ;i < len;++i) {
    gdjs.PastCode.GDNewParticlesEmitterObjects1[i].setY((( gdjs.PastCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.PastCode.GDplayerObjects1[0].getPointY("")) - 260);
}
}{for(var i = 0, len = gdjs.PastCode.GDNewParticlesEmitter2Objects1.length ;i < len;++i) {
    gdjs.PastCode.GDNewParticlesEmitter2Objects1[i].setY((( gdjs.PastCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.PastCode.GDplayerObjects1[0].getPointY("")) - 260);
}
}}

}


{


gdjs.PastCode.eventsList1(runtimeScene);
}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimeScale(runtimeScene) != 0;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Light"), gdjs.PastCode.GDLightObjects1);
gdjs.copyArray(runtimeScene.getObjects("Light2"), gdjs.PastCode.GDLight2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Light_hand"), gdjs.PastCode.GDLight_9595handObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewBitmapText"), gdjs.PastCode.GDNewBitmapTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewParticlesEmitter"), gdjs.PastCode.GDNewParticlesEmitterObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewParticlesEmitter2"), gdjs.PastCode.GDNewParticlesEmitter2Objects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.PastCode.GDplayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("rail"), gdjs.PastCode.GDrailObjects1);
gdjs.copyArray(runtimeScene.getObjects("task_bar"), gdjs.PastCode.GDtask_9595barObjects1);
{for(var i = 0, len = gdjs.PastCode.GDLight2Objects1.length ;i < len;++i) {
    gdjs.PastCode.GDLight2Objects1[i].setPosition((( gdjs.PastCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.PastCode.GDplayerObjects1[0].getPointX("")),(( gdjs.PastCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.PastCode.GDplayerObjects1[0].getPointY("")));
}
}{for(var i = 0, len = gdjs.PastCode.GDLightObjects1.length ;i < len;++i) {
    gdjs.PastCode.GDLightObjects1[i].setPosition((( gdjs.PastCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.PastCode.GDplayerObjects1[0].getPointX("")),(( gdjs.PastCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.PastCode.GDplayerObjects1[0].getPointY("")));
}
}{for(var i = 0, len = gdjs.PastCode.GDNewParticlesEmitterObjects1.length ;i < len;++i) {
    gdjs.PastCode.GDNewParticlesEmitterObjects1[i].setX((( gdjs.PastCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.PastCode.GDplayerObjects1[0].getPointX("")));
}
}{for(var i = 0, len = gdjs.PastCode.GDNewParticlesEmitter2Objects1.length ;i < len;++i) {
    gdjs.PastCode.GDNewParticlesEmitter2Objects1[i].setX((( gdjs.PastCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.PastCode.GDplayerObjects1[0].getPointX("")));
}
}{for(var i = 0, len = gdjs.PastCode.GDrailObjects1.length ;i < len;++i) {
    gdjs.PastCode.GDrailObjects1[i].setXOffset((( gdjs.PastCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.PastCode.GDplayerObjects1[0].getPointX("")) / 2);
}
}{for(var i = 0, len = gdjs.PastCode.GDtask_9595barObjects1.length ;i < len;++i) {
    gdjs.PastCode.GDtask_9595barObjects1[i].setPosition((( gdjs.PastCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.PastCode.GDplayerObjects1[0].getPointX("fly")) - 32,(( gdjs.PastCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.PastCode.GDplayerObjects1[0].getPointY("fly")) - 16);
}
}{for(var i = 0, len = gdjs.PastCode.GDNewBitmapTextObjects1.length ;i < len;++i) {
    gdjs.PastCode.GDNewBitmapTextObjects1[i].setPosition((( gdjs.PastCode.GDtask_9595barObjects1.length === 0 ) ? 0 :gdjs.PastCode.GDtask_9595barObjects1[0].getCenterXInScene()) - 16,(( gdjs.PastCode.GDtask_9595barObjects1.length === 0 ) ? 0 :gdjs.PastCode.GDtask_9595barObjects1[0].getCenterYInScene()) - 4);
}
}{for(var i = 0, len = gdjs.PastCode.GDLight_9595handObjects1.length ;i < len;++i) {
    gdjs.PastCode.GDLight_9595handObjects1[i].setPosition(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0),gdjs.evtTools.input.getCursorY(runtimeScene, "", 0));
}
}}

}


{



}


{



}


{


gdjs.PastCode.eventsList6(runtimeScene);
}


{


gdjs.PastCode.eventsList11(runtimeScene);
}


{


gdjs.PastCode.eventsList12(runtimeScene);
}


{


gdjs.PastCode.eventsList13(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("Shootingstar"), gdjs.PastCode.GDShootingstarObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PastCode.GDShootingstarObjects1.length;i<l;++i) {
    if ( gdjs.PastCode.GDShootingstarObjects1[i].getTimerElapsedTimeInSecondsOrNaN("dance") >= 0.5 ) {
        isConditionTrue_0 = true;
        gdjs.PastCode.GDShootingstarObjects1[k] = gdjs.PastCode.GDShootingstarObjects1[i];
        ++k;
    }
}
gdjs.PastCode.GDShootingstarObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.PastCode.GDShootingstarObjects1 */
{for(var i = 0, len = gdjs.PastCode.GDShootingstarObjects1.length ;i < len;++i) {
    gdjs.PastCode.GDShootingstarObjects1[i].getBehavior("Tween").addObjectScaleXTween2("dance", gdjs.randomInRange(0.8, 1.2), "linear", gdjs.randomInRange(2, 4), false, true);
}
}{for(var i = 0, len = gdjs.PastCode.GDShootingstarObjects1.length ;i < len;++i) {
    gdjs.PastCode.GDShootingstarObjects1[i].getBehavior("Tween").addObjectScaleYTween2("dance", gdjs.randomInRange(0.8, 1.2), "linear", gdjs.randomInRange(2, 4), false, true);
}
}{for(var i = 0, len = gdjs.PastCode.GDShootingstarObjects1.length ;i < len;++i) {
    gdjs.PastCode.GDShootingstarObjects1[i].resetTimer("dance");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Shootingstar2"), gdjs.PastCode.GDShootingstar2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PastCode.GDShootingstar2Objects1.length;i<l;++i) {
    if ( gdjs.PastCode.GDShootingstar2Objects1[i].getTimerElapsedTimeInSecondsOrNaN("dance") >= 0.5 ) {
        isConditionTrue_0 = true;
        gdjs.PastCode.GDShootingstar2Objects1[k] = gdjs.PastCode.GDShootingstar2Objects1[i];
        ++k;
    }
}
gdjs.PastCode.GDShootingstar2Objects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.PastCode.GDShootingstar2Objects1 */
{for(var i = 0, len = gdjs.PastCode.GDShootingstar2Objects1.length ;i < len;++i) {
    gdjs.PastCode.GDShootingstar2Objects1[i].getBehavior("Tween").addObjectScaleXTween2("dance", gdjs.randomInRange(3.8, 2.2), "linear", gdjs.randomInRange(2, 4), false, true);
}
}{for(var i = 0, len = gdjs.PastCode.GDShootingstar2Objects1.length ;i < len;++i) {
    gdjs.PastCode.GDShootingstar2Objects1[i].getBehavior("Tween").addObjectScaleYTween2("dance", gdjs.randomInRange(3.8, 2.2), "linear", gdjs.randomInRange(2, 4), false, true);
}
}{for(var i = 0, len = gdjs.PastCode.GDShootingstar2Objects1.length ;i < len;++i) {
    gdjs.PastCode.GDShootingstar2Objects1[i].resetTimer("dance");
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Shootingstar"), gdjs.PastCode.GDShootingstarObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.PastCode.GDplayerObjects1);
{for(var i = 0, len = gdjs.PastCode.GDShootingstarObjects1.length ;i < len;++i) {
    gdjs.PastCode.GDShootingstarObjects1[i].getBehavior("BoidsMovement").MoveToObject(gdjs.PastCode.mapOfGDgdjs_9546PastCode_9546GDplayerObjects1Objects, 5, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.PastCode.GDShootingstarObjects1.length ;i < len;++i) {
    gdjs.PastCode.GDShootingstarObjects1[i].getBehavior("BoidsMovement").AvoidObject(gdjs.PastCode.mapOfGDgdjs_9546PastCode_9546GDplayerObjects1Objects, 50, 8, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Shootingstar"), gdjs.PastCode.GDShootingstarObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.PastCode.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PastCode.GDShootingstarObjects1.length;i<l;++i) {
    if ( gdjs.PastCode.GDShootingstarObjects1[i].getX() < (( gdjs.PastCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.PastCode.GDplayerObjects1[0].getCenterXInScene()) ) {
        isConditionTrue_0 = true;
        gdjs.PastCode.GDShootingstarObjects1[k] = gdjs.PastCode.GDShootingstarObjects1[i];
        ++k;
    }
}
gdjs.PastCode.GDShootingstarObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29503236);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.PastCode.GDShootingstarObjects1 */
{for(var i = 0, len = gdjs.PastCode.GDShootingstarObjects1.length ;i < len;++i) {
    gdjs.PastCode.GDShootingstarObjects1[i].getBehavior("Flippable").flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Shootingstar"), gdjs.PastCode.GDShootingstarObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.PastCode.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PastCode.GDShootingstarObjects1.length;i<l;++i) {
    if ( !(gdjs.PastCode.GDShootingstarObjects1[i].getX() < (( gdjs.PastCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.PastCode.GDplayerObjects1[0].getCenterXInScene())) ) {
        isConditionTrue_0 = true;
        gdjs.PastCode.GDShootingstarObjects1[k] = gdjs.PastCode.GDShootingstarObjects1[i];
        ++k;
    }
}
gdjs.PastCode.GDShootingstarObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.dialogueTree.isRunning();
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29504564);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.PastCode.GDShootingstarObjects1 */
{for(var i = 0, len = gdjs.PastCode.GDShootingstarObjects1.length ;i < len;++i) {
    gdjs.PastCode.GDShootingstarObjects1[i].getBehavior("Flippable").flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Shootingstar"), gdjs.PastCode.GDShootingstarObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.PastCode.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PastCode.GDShootingstarObjects1.length;i<l;++i) {
    if ( !(gdjs.PastCode.GDShootingstarObjects1[i].getX() < (( gdjs.PastCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.PastCode.GDplayerObjects1[0].getCenterXInScene())) ) {
        isConditionTrue_0 = true;
        gdjs.PastCode.GDShootingstarObjects1[k] = gdjs.PastCode.GDShootingstarObjects1[i];
        ++k;
    }
}
gdjs.PastCode.GDShootingstarObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29505252);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.PastCode.GDShootingstarObjects1 */
{for(var i = 0, len = gdjs.PastCode.GDShootingstarObjects1.length ;i < len;++i) {
    gdjs.PastCode.GDShootingstarObjects1[i].getBehavior("Flippable").flipX(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Shootingstar"), gdjs.PastCode.GDShootingstarObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.PastCode.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.PastCode.GDShootingstarObjects1.length;i<l;++i) {
    if ( gdjs.PastCode.GDShootingstarObjects1[i].getX() < (( gdjs.PastCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.PastCode.GDplayerObjects1[0].getCenterXInScene()) ) {
        isConditionTrue_0 = true;
        gdjs.PastCode.GDShootingstarObjects1[k] = gdjs.PastCode.GDShootingstarObjects1[i];
        ++k;
    }
}
gdjs.PastCode.GDShootingstarObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.dialogueTree.isRunning();
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29506316);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.PastCode.GDShootingstarObjects1 */
{for(var i = 0, len = gdjs.PastCode.GDShootingstarObjects1.length ;i < len;++i) {
    gdjs.PastCode.GDShootingstarObjects1[i].getBehavior("Flippable").flipX(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("area"), gdjs.PastCode.GDareaObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.PastCode.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PastCode.mapOfGDgdjs_9546PastCode_9546GDplayerObjects1Objects, gdjs.PastCode.mapOfGDgdjs_9546PastCode_9546GDareaObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29506124);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Shootingstar"), gdjs.PastCode.GDShootingstarObjects1);
{for(var i = 0, len = gdjs.PastCode.GDShootingstarObjects1.length ;i < len;++i) {
    gdjs.PastCode.GDShootingstarObjects1[i].activateBehavior("BoidsMovement", true);
}
}}

}


};

gdjs.PastCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.PastCode.GDpuddlesObjects1.length = 0;
gdjs.PastCode.GDpuddlesObjects2.length = 0;
gdjs.PastCode.GDpuddlesObjects3.length = 0;
gdjs.PastCode.GDpuddlesObjects4.length = 0;
gdjs.PastCode.GDNewParticlesEmitterObjects1.length = 0;
gdjs.PastCode.GDNewParticlesEmitterObjects2.length = 0;
gdjs.PastCode.GDNewParticlesEmitterObjects3.length = 0;
gdjs.PastCode.GDNewParticlesEmitterObjects4.length = 0;
gdjs.PastCode.GDLightObjects1.length = 0;
gdjs.PastCode.GDLightObjects2.length = 0;
gdjs.PastCode.GDLightObjects3.length = 0;
gdjs.PastCode.GDLightObjects4.length = 0;
gdjs.PastCode.GDLight2Objects1.length = 0;
gdjs.PastCode.GDLight2Objects2.length = 0;
gdjs.PastCode.GDLight2Objects3.length = 0;
gdjs.PastCode.GDLight2Objects4.length = 0;
gdjs.PastCode.GDNewShapePainterObjects1.length = 0;
gdjs.PastCode.GDNewShapePainterObjects2.length = 0;
gdjs.PastCode.GDNewShapePainterObjects3.length = 0;
gdjs.PastCode.GDNewShapePainterObjects4.length = 0;
gdjs.PastCode.GDNewParticlesEmitter2Objects1.length = 0;
gdjs.PastCode.GDNewParticlesEmitter2Objects2.length = 0;
gdjs.PastCode.GDNewParticlesEmitter2Objects3.length = 0;
gdjs.PastCode.GDNewParticlesEmitter2Objects4.length = 0;
gdjs.PastCode.GDtransitionObjects1.length = 0;
gdjs.PastCode.GDtransitionObjects2.length = 0;
gdjs.PastCode.GDtransitionObjects3.length = 0;
gdjs.PastCode.GDtransitionObjects4.length = 0;
gdjs.PastCode.GDfloor_95953Objects1.length = 0;
gdjs.PastCode.GDfloor_95953Objects2.length = 0;
gdjs.PastCode.GDfloor_95953Objects3.length = 0;
gdjs.PastCode.GDfloor_95953Objects4.length = 0;
gdjs.PastCode.GDcolorsObjects1.length = 0;
gdjs.PastCode.GDcolorsObjects2.length = 0;
gdjs.PastCode.GDcolorsObjects3.length = 0;
gdjs.PastCode.GDcolorsObjects4.length = 0;
gdjs.PastCode.GDnoteObjects1.length = 0;
gdjs.PastCode.GDnoteObjects2.length = 0;
gdjs.PastCode.GDnoteObjects3.length = 0;
gdjs.PastCode.GDnoteObjects4.length = 0;
gdjs.PastCode.GDoppacityObjects1.length = 0;
gdjs.PastCode.GDoppacityObjects2.length = 0;
gdjs.PastCode.GDoppacityObjects3.length = 0;
gdjs.PastCode.GDoppacityObjects4.length = 0;
gdjs.PastCode.GDcloseObjects1.length = 0;
gdjs.PastCode.GDcloseObjects2.length = 0;
gdjs.PastCode.GDcloseObjects3.length = 0;
gdjs.PastCode.GDcloseObjects4.length = 0;
gdjs.PastCode.GDnotesObjects1.length = 0;
gdjs.PastCode.GDnotesObjects2.length = 0;
gdjs.PastCode.GDnotesObjects3.length = 0;
gdjs.PastCode.GDnotesObjects4.length = 0;
gdjs.PastCode.GDnote2Objects1.length = 0;
gdjs.PastCode.GDnote2Objects2.length = 0;
gdjs.PastCode.GDnote2Objects3.length = 0;
gdjs.PastCode.GDnote2Objects4.length = 0;
gdjs.PastCode.GDLight3Objects1.length = 0;
gdjs.PastCode.GDLight3Objects2.length = 0;
gdjs.PastCode.GDLight3Objects3.length = 0;
gdjs.PastCode.GDLight3Objects4.length = 0;
gdjs.PastCode.GDareaObjects1.length = 0;
gdjs.PastCode.GDareaObjects2.length = 0;
gdjs.PastCode.GDareaObjects3.length = 0;
gdjs.PastCode.GDareaObjects4.length = 0;
gdjs.PastCode.GDspawn_9595himaObjects1.length = 0;
gdjs.PastCode.GDspawn_9595himaObjects2.length = 0;
gdjs.PastCode.GDspawn_9595himaObjects3.length = 0;
gdjs.PastCode.GDspawn_9595himaObjects4.length = 0;
gdjs.PastCode.GDLight_9595handObjects1.length = 0;
gdjs.PastCode.GDLight_9595handObjects2.length = 0;
gdjs.PastCode.GDLight_9595handObjects3.length = 0;
gdjs.PastCode.GDLight_9595handObjects4.length = 0;
gdjs.PastCode.GDarea2Objects1.length = 0;
gdjs.PastCode.GDarea2Objects2.length = 0;
gdjs.PastCode.GDarea2Objects3.length = 0;
gdjs.PastCode.GDarea2Objects4.length = 0;
gdjs.PastCode.GDtext_9595boxObjects1.length = 0;
gdjs.PastCode.GDtext_9595boxObjects2.length = 0;
gdjs.PastCode.GDtext_9595boxObjects3.length = 0;
gdjs.PastCode.GDtext_9595boxObjects4.length = 0;
gdjs.PastCode.GDtipObjects1.length = 0;
gdjs.PastCode.GDtipObjects2.length = 0;
gdjs.PastCode.GDtipObjects3.length = 0;
gdjs.PastCode.GDtipObjects4.length = 0;
gdjs.PastCode.GDNameObjects1.length = 0;
gdjs.PastCode.GDNameObjects2.length = 0;
gdjs.PastCode.GDNameObjects3.length = 0;
gdjs.PastCode.GDNameObjects4.length = 0;
gdjs.PastCode.GDDialogeObjects1.length = 0;
gdjs.PastCode.GDDialogeObjects2.length = 0;
gdjs.PastCode.GDDialogeObjects3.length = 0;
gdjs.PastCode.GDDialogeObjects4.length = 0;
gdjs.PastCode.GDcharecters2Objects1.length = 0;
gdjs.PastCode.GDcharecters2Objects2.length = 0;
gdjs.PastCode.GDcharecters2Objects3.length = 0;
gdjs.PastCode.GDcharecters2Objects4.length = 0;
gdjs.PastCode.GDShootingstarObjects1.length = 0;
gdjs.PastCode.GDShootingstarObjects2.length = 0;
gdjs.PastCode.GDShootingstarObjects3.length = 0;
gdjs.PastCode.GDShootingstarObjects4.length = 0;
gdjs.PastCode.GDShootingstar2Objects1.length = 0;
gdjs.PastCode.GDShootingstar2Objects2.length = 0;
gdjs.PastCode.GDShootingstar2Objects3.length = 0;
gdjs.PastCode.GDShootingstar2Objects4.length = 0;
gdjs.PastCode.GDWallObjects1.length = 0;
gdjs.PastCode.GDWallObjects2.length = 0;
gdjs.PastCode.GDWallObjects3.length = 0;
gdjs.PastCode.GDWallObjects4.length = 0;
gdjs.PastCode.GDfloorObjects1.length = 0;
gdjs.PastCode.GDfloorObjects2.length = 0;
gdjs.PastCode.GDfloorObjects3.length = 0;
gdjs.PastCode.GDfloorObjects4.length = 0;
gdjs.PastCode.GDdoorsObjects1.length = 0;
gdjs.PastCode.GDdoorsObjects2.length = 0;
gdjs.PastCode.GDdoorsObjects3.length = 0;
gdjs.PastCode.GDdoorsObjects4.length = 0;
gdjs.PastCode.GDobjectsObjects1.length = 0;
gdjs.PastCode.GDobjectsObjects2.length = 0;
gdjs.PastCode.GDobjectsObjects3.length = 0;
gdjs.PastCode.GDobjectsObjects4.length = 0;
gdjs.PastCode.GDwallobjectObjects1.length = 0;
gdjs.PastCode.GDwallobjectObjects2.length = 0;
gdjs.PastCode.GDwallobjectObjects3.length = 0;
gdjs.PastCode.GDwallobjectObjects4.length = 0;
gdjs.PastCode.GDwindowObjects1.length = 0;
gdjs.PastCode.GDwindowObjects2.length = 0;
gdjs.PastCode.GDwindowObjects3.length = 0;
gdjs.PastCode.GDwindowObjects4.length = 0;
gdjs.PastCode.GDrailObjects1.length = 0;
gdjs.PastCode.GDrailObjects2.length = 0;
gdjs.PastCode.GDrailObjects3.length = 0;
gdjs.PastCode.GDrailObjects4.length = 0;
gdjs.PastCode.GDplayerObjects1.length = 0;
gdjs.PastCode.GDplayerObjects2.length = 0;
gdjs.PastCode.GDplayerObjects3.length = 0;
gdjs.PastCode.GDplayerObjects4.length = 0;
gdjs.PastCode.GDhitboxObjects1.length = 0;
gdjs.PastCode.GDhitboxObjects2.length = 0;
gdjs.PastCode.GDhitboxObjects3.length = 0;
gdjs.PastCode.GDhitboxObjects4.length = 0;
gdjs.PastCode.GDMainlightObjects1.length = 0;
gdjs.PastCode.GDMainlightObjects2.length = 0;
gdjs.PastCode.GDMainlightObjects3.length = 0;
gdjs.PastCode.GDMainlightObjects4.length = 0;
gdjs.PastCode.GDsmalllightObjects1.length = 0;
gdjs.PastCode.GDsmalllightObjects2.length = 0;
gdjs.PastCode.GDsmalllightObjects3.length = 0;
gdjs.PastCode.GDsmalllightObjects4.length = 0;
gdjs.PastCode.GDNewBitmapTextObjects1.length = 0;
gdjs.PastCode.GDNewBitmapTextObjects2.length = 0;
gdjs.PastCode.GDNewBitmapTextObjects3.length = 0;
gdjs.PastCode.GDNewBitmapTextObjects4.length = 0;
gdjs.PastCode.GDtask_9595barObjects1.length = 0;
gdjs.PastCode.GDtask_9595barObjects2.length = 0;
gdjs.PastCode.GDtask_9595barObjects3.length = 0;
gdjs.PastCode.GDtask_9595barObjects4.length = 0;
gdjs.PastCode.GDcharectersObjects1.length = 0;
gdjs.PastCode.GDcharectersObjects2.length = 0;
gdjs.PastCode.GDcharectersObjects3.length = 0;
gdjs.PastCode.GDcharectersObjects4.length = 0;
gdjs.PastCode.GDcharecters22Objects1.length = 0;
gdjs.PastCode.GDcharecters22Objects2.length = 0;
gdjs.PastCode.GDcharecters22Objects3.length = 0;
gdjs.PastCode.GDcharecters22Objects4.length = 0;
gdjs.PastCode.GDPauseObjects1.length = 0;
gdjs.PastCode.GDPauseObjects2.length = 0;
gdjs.PastCode.GDPauseObjects3.length = 0;
gdjs.PastCode.GDPauseObjects4.length = 0;
gdjs.PastCode.GDresumeObjects1.length = 0;
gdjs.PastCode.GDresumeObjects2.length = 0;
gdjs.PastCode.GDresumeObjects3.length = 0;
gdjs.PastCode.GDresumeObjects4.length = 0;
gdjs.PastCode.GDQuit_95952Objects1.length = 0;
gdjs.PastCode.GDQuit_95952Objects2.length = 0;
gdjs.PastCode.GDQuit_95952Objects3.length = 0;
gdjs.PastCode.GDQuit_95952Objects4.length = 0;
gdjs.PastCode.GDpause_9595menuObjects1.length = 0;
gdjs.PastCode.GDpause_9595menuObjects2.length = 0;
gdjs.PastCode.GDpause_9595menuObjects3.length = 0;
gdjs.PastCode.GDpause_9595menuObjects4.length = 0;
gdjs.PastCode.GDHimaObjects1.length = 0;
gdjs.PastCode.GDHimaObjects2.length = 0;
gdjs.PastCode.GDHimaObjects3.length = 0;
gdjs.PastCode.GDHimaObjects4.length = 0;
gdjs.PastCode.GDLayaObjects1.length = 0;
gdjs.PastCode.GDLayaObjects2.length = 0;
gdjs.PastCode.GDLayaObjects3.length = 0;
gdjs.PastCode.GDLayaObjects4.length = 0;
gdjs.PastCode.GDJoystickObjects1.length = 0;
gdjs.PastCode.GDJoystickObjects2.length = 0;
gdjs.PastCode.GDJoystickObjects3.length = 0;
gdjs.PastCode.GDJoystickObjects4.length = 0;
gdjs.PastCode.GDE_9595buttonObjects1.length = 0;
gdjs.PastCode.GDE_9595buttonObjects2.length = 0;
gdjs.PastCode.GDE_9595buttonObjects3.length = 0;
gdjs.PastCode.GDE_9595buttonObjects4.length = 0;

gdjs.PastCode.eventsList14(runtimeScene);
gdjs.PastCode.GDpuddlesObjects1.length = 0;
gdjs.PastCode.GDpuddlesObjects2.length = 0;
gdjs.PastCode.GDpuddlesObjects3.length = 0;
gdjs.PastCode.GDpuddlesObjects4.length = 0;
gdjs.PastCode.GDNewParticlesEmitterObjects1.length = 0;
gdjs.PastCode.GDNewParticlesEmitterObjects2.length = 0;
gdjs.PastCode.GDNewParticlesEmitterObjects3.length = 0;
gdjs.PastCode.GDNewParticlesEmitterObjects4.length = 0;
gdjs.PastCode.GDLightObjects1.length = 0;
gdjs.PastCode.GDLightObjects2.length = 0;
gdjs.PastCode.GDLightObjects3.length = 0;
gdjs.PastCode.GDLightObjects4.length = 0;
gdjs.PastCode.GDLight2Objects1.length = 0;
gdjs.PastCode.GDLight2Objects2.length = 0;
gdjs.PastCode.GDLight2Objects3.length = 0;
gdjs.PastCode.GDLight2Objects4.length = 0;
gdjs.PastCode.GDNewShapePainterObjects1.length = 0;
gdjs.PastCode.GDNewShapePainterObjects2.length = 0;
gdjs.PastCode.GDNewShapePainterObjects3.length = 0;
gdjs.PastCode.GDNewShapePainterObjects4.length = 0;
gdjs.PastCode.GDNewParticlesEmitter2Objects1.length = 0;
gdjs.PastCode.GDNewParticlesEmitter2Objects2.length = 0;
gdjs.PastCode.GDNewParticlesEmitter2Objects3.length = 0;
gdjs.PastCode.GDNewParticlesEmitter2Objects4.length = 0;
gdjs.PastCode.GDtransitionObjects1.length = 0;
gdjs.PastCode.GDtransitionObjects2.length = 0;
gdjs.PastCode.GDtransitionObjects3.length = 0;
gdjs.PastCode.GDtransitionObjects4.length = 0;
gdjs.PastCode.GDfloor_95953Objects1.length = 0;
gdjs.PastCode.GDfloor_95953Objects2.length = 0;
gdjs.PastCode.GDfloor_95953Objects3.length = 0;
gdjs.PastCode.GDfloor_95953Objects4.length = 0;
gdjs.PastCode.GDcolorsObjects1.length = 0;
gdjs.PastCode.GDcolorsObjects2.length = 0;
gdjs.PastCode.GDcolorsObjects3.length = 0;
gdjs.PastCode.GDcolorsObjects4.length = 0;
gdjs.PastCode.GDnoteObjects1.length = 0;
gdjs.PastCode.GDnoteObjects2.length = 0;
gdjs.PastCode.GDnoteObjects3.length = 0;
gdjs.PastCode.GDnoteObjects4.length = 0;
gdjs.PastCode.GDoppacityObjects1.length = 0;
gdjs.PastCode.GDoppacityObjects2.length = 0;
gdjs.PastCode.GDoppacityObjects3.length = 0;
gdjs.PastCode.GDoppacityObjects4.length = 0;
gdjs.PastCode.GDcloseObjects1.length = 0;
gdjs.PastCode.GDcloseObjects2.length = 0;
gdjs.PastCode.GDcloseObjects3.length = 0;
gdjs.PastCode.GDcloseObjects4.length = 0;
gdjs.PastCode.GDnotesObjects1.length = 0;
gdjs.PastCode.GDnotesObjects2.length = 0;
gdjs.PastCode.GDnotesObjects3.length = 0;
gdjs.PastCode.GDnotesObjects4.length = 0;
gdjs.PastCode.GDnote2Objects1.length = 0;
gdjs.PastCode.GDnote2Objects2.length = 0;
gdjs.PastCode.GDnote2Objects3.length = 0;
gdjs.PastCode.GDnote2Objects4.length = 0;
gdjs.PastCode.GDLight3Objects1.length = 0;
gdjs.PastCode.GDLight3Objects2.length = 0;
gdjs.PastCode.GDLight3Objects3.length = 0;
gdjs.PastCode.GDLight3Objects4.length = 0;
gdjs.PastCode.GDareaObjects1.length = 0;
gdjs.PastCode.GDareaObjects2.length = 0;
gdjs.PastCode.GDareaObjects3.length = 0;
gdjs.PastCode.GDareaObjects4.length = 0;
gdjs.PastCode.GDspawn_9595himaObjects1.length = 0;
gdjs.PastCode.GDspawn_9595himaObjects2.length = 0;
gdjs.PastCode.GDspawn_9595himaObjects3.length = 0;
gdjs.PastCode.GDspawn_9595himaObjects4.length = 0;
gdjs.PastCode.GDLight_9595handObjects1.length = 0;
gdjs.PastCode.GDLight_9595handObjects2.length = 0;
gdjs.PastCode.GDLight_9595handObjects3.length = 0;
gdjs.PastCode.GDLight_9595handObjects4.length = 0;
gdjs.PastCode.GDarea2Objects1.length = 0;
gdjs.PastCode.GDarea2Objects2.length = 0;
gdjs.PastCode.GDarea2Objects3.length = 0;
gdjs.PastCode.GDarea2Objects4.length = 0;
gdjs.PastCode.GDtext_9595boxObjects1.length = 0;
gdjs.PastCode.GDtext_9595boxObjects2.length = 0;
gdjs.PastCode.GDtext_9595boxObjects3.length = 0;
gdjs.PastCode.GDtext_9595boxObjects4.length = 0;
gdjs.PastCode.GDtipObjects1.length = 0;
gdjs.PastCode.GDtipObjects2.length = 0;
gdjs.PastCode.GDtipObjects3.length = 0;
gdjs.PastCode.GDtipObjects4.length = 0;
gdjs.PastCode.GDNameObjects1.length = 0;
gdjs.PastCode.GDNameObjects2.length = 0;
gdjs.PastCode.GDNameObjects3.length = 0;
gdjs.PastCode.GDNameObjects4.length = 0;
gdjs.PastCode.GDDialogeObjects1.length = 0;
gdjs.PastCode.GDDialogeObjects2.length = 0;
gdjs.PastCode.GDDialogeObjects3.length = 0;
gdjs.PastCode.GDDialogeObjects4.length = 0;
gdjs.PastCode.GDcharecters2Objects1.length = 0;
gdjs.PastCode.GDcharecters2Objects2.length = 0;
gdjs.PastCode.GDcharecters2Objects3.length = 0;
gdjs.PastCode.GDcharecters2Objects4.length = 0;
gdjs.PastCode.GDShootingstarObjects1.length = 0;
gdjs.PastCode.GDShootingstarObjects2.length = 0;
gdjs.PastCode.GDShootingstarObjects3.length = 0;
gdjs.PastCode.GDShootingstarObjects4.length = 0;
gdjs.PastCode.GDShootingstar2Objects1.length = 0;
gdjs.PastCode.GDShootingstar2Objects2.length = 0;
gdjs.PastCode.GDShootingstar2Objects3.length = 0;
gdjs.PastCode.GDShootingstar2Objects4.length = 0;
gdjs.PastCode.GDWallObjects1.length = 0;
gdjs.PastCode.GDWallObjects2.length = 0;
gdjs.PastCode.GDWallObjects3.length = 0;
gdjs.PastCode.GDWallObjects4.length = 0;
gdjs.PastCode.GDfloorObjects1.length = 0;
gdjs.PastCode.GDfloorObjects2.length = 0;
gdjs.PastCode.GDfloorObjects3.length = 0;
gdjs.PastCode.GDfloorObjects4.length = 0;
gdjs.PastCode.GDdoorsObjects1.length = 0;
gdjs.PastCode.GDdoorsObjects2.length = 0;
gdjs.PastCode.GDdoorsObjects3.length = 0;
gdjs.PastCode.GDdoorsObjects4.length = 0;
gdjs.PastCode.GDobjectsObjects1.length = 0;
gdjs.PastCode.GDobjectsObjects2.length = 0;
gdjs.PastCode.GDobjectsObjects3.length = 0;
gdjs.PastCode.GDobjectsObjects4.length = 0;
gdjs.PastCode.GDwallobjectObjects1.length = 0;
gdjs.PastCode.GDwallobjectObjects2.length = 0;
gdjs.PastCode.GDwallobjectObjects3.length = 0;
gdjs.PastCode.GDwallobjectObjects4.length = 0;
gdjs.PastCode.GDwindowObjects1.length = 0;
gdjs.PastCode.GDwindowObjects2.length = 0;
gdjs.PastCode.GDwindowObjects3.length = 0;
gdjs.PastCode.GDwindowObjects4.length = 0;
gdjs.PastCode.GDrailObjects1.length = 0;
gdjs.PastCode.GDrailObjects2.length = 0;
gdjs.PastCode.GDrailObjects3.length = 0;
gdjs.PastCode.GDrailObjects4.length = 0;
gdjs.PastCode.GDplayerObjects1.length = 0;
gdjs.PastCode.GDplayerObjects2.length = 0;
gdjs.PastCode.GDplayerObjects3.length = 0;
gdjs.PastCode.GDplayerObjects4.length = 0;
gdjs.PastCode.GDhitboxObjects1.length = 0;
gdjs.PastCode.GDhitboxObjects2.length = 0;
gdjs.PastCode.GDhitboxObjects3.length = 0;
gdjs.PastCode.GDhitboxObjects4.length = 0;
gdjs.PastCode.GDMainlightObjects1.length = 0;
gdjs.PastCode.GDMainlightObjects2.length = 0;
gdjs.PastCode.GDMainlightObjects3.length = 0;
gdjs.PastCode.GDMainlightObjects4.length = 0;
gdjs.PastCode.GDsmalllightObjects1.length = 0;
gdjs.PastCode.GDsmalllightObjects2.length = 0;
gdjs.PastCode.GDsmalllightObjects3.length = 0;
gdjs.PastCode.GDsmalllightObjects4.length = 0;
gdjs.PastCode.GDNewBitmapTextObjects1.length = 0;
gdjs.PastCode.GDNewBitmapTextObjects2.length = 0;
gdjs.PastCode.GDNewBitmapTextObjects3.length = 0;
gdjs.PastCode.GDNewBitmapTextObjects4.length = 0;
gdjs.PastCode.GDtask_9595barObjects1.length = 0;
gdjs.PastCode.GDtask_9595barObjects2.length = 0;
gdjs.PastCode.GDtask_9595barObjects3.length = 0;
gdjs.PastCode.GDtask_9595barObjects4.length = 0;
gdjs.PastCode.GDcharectersObjects1.length = 0;
gdjs.PastCode.GDcharectersObjects2.length = 0;
gdjs.PastCode.GDcharectersObjects3.length = 0;
gdjs.PastCode.GDcharectersObjects4.length = 0;
gdjs.PastCode.GDcharecters22Objects1.length = 0;
gdjs.PastCode.GDcharecters22Objects2.length = 0;
gdjs.PastCode.GDcharecters22Objects3.length = 0;
gdjs.PastCode.GDcharecters22Objects4.length = 0;
gdjs.PastCode.GDPauseObjects1.length = 0;
gdjs.PastCode.GDPauseObjects2.length = 0;
gdjs.PastCode.GDPauseObjects3.length = 0;
gdjs.PastCode.GDPauseObjects4.length = 0;
gdjs.PastCode.GDresumeObjects1.length = 0;
gdjs.PastCode.GDresumeObjects2.length = 0;
gdjs.PastCode.GDresumeObjects3.length = 0;
gdjs.PastCode.GDresumeObjects4.length = 0;
gdjs.PastCode.GDQuit_95952Objects1.length = 0;
gdjs.PastCode.GDQuit_95952Objects2.length = 0;
gdjs.PastCode.GDQuit_95952Objects3.length = 0;
gdjs.PastCode.GDQuit_95952Objects4.length = 0;
gdjs.PastCode.GDpause_9595menuObjects1.length = 0;
gdjs.PastCode.GDpause_9595menuObjects2.length = 0;
gdjs.PastCode.GDpause_9595menuObjects3.length = 0;
gdjs.PastCode.GDpause_9595menuObjects4.length = 0;
gdjs.PastCode.GDHimaObjects1.length = 0;
gdjs.PastCode.GDHimaObjects2.length = 0;
gdjs.PastCode.GDHimaObjects3.length = 0;
gdjs.PastCode.GDHimaObjects4.length = 0;
gdjs.PastCode.GDLayaObjects1.length = 0;
gdjs.PastCode.GDLayaObjects2.length = 0;
gdjs.PastCode.GDLayaObjects3.length = 0;
gdjs.PastCode.GDLayaObjects4.length = 0;
gdjs.PastCode.GDJoystickObjects1.length = 0;
gdjs.PastCode.GDJoystickObjects2.length = 0;
gdjs.PastCode.GDJoystickObjects3.length = 0;
gdjs.PastCode.GDJoystickObjects4.length = 0;
gdjs.PastCode.GDE_9595buttonObjects1.length = 0;
gdjs.PastCode.GDE_9595buttonObjects2.length = 0;
gdjs.PastCode.GDE_9595buttonObjects3.length = 0;
gdjs.PastCode.GDE_9595buttonObjects4.length = 0;


return;

}

gdjs['PastCode'] = gdjs.PastCode;
