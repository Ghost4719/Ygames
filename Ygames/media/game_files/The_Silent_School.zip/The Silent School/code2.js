gdjs.RoomsCode = {};
gdjs.RoomsCode.localVariables = [];
gdjs.RoomsCode.GDE_9595buttonObjects1_1final = [];

gdjs.RoomsCode.GDE_9595buttonObjects2_1final = [];

gdjs.RoomsCode.GDE_9595buttonObjects3_1final = [];

gdjs.RoomsCode.GDJoystickObjects2_1final = [];

gdjs.RoomsCode.forEachIndex3 = 0;

gdjs.RoomsCode.forEachObjects3 = [];

gdjs.RoomsCode.forEachTemporary3 = null;

gdjs.RoomsCode.forEachTotalCount3 = 0;

gdjs.RoomsCode.GDgrandpa_9595sObjects1= [];
gdjs.RoomsCode.GDgrandpa_9595sObjects2= [];
gdjs.RoomsCode.GDgrandpa_9595sObjects3= [];
gdjs.RoomsCode.GDgrandpa_9595sObjects4= [];
gdjs.RoomsCode.GDgrandpa_9595sObjects5= [];
gdjs.RoomsCode.GDwallObjects1= [];
gdjs.RoomsCode.GDwallObjects2= [];
gdjs.RoomsCode.GDwallObjects3= [];
gdjs.RoomsCode.GDwallObjects4= [];
gdjs.RoomsCode.GDwallObjects5= [];
gdjs.RoomsCode.GDRoomsObjects1= [];
gdjs.RoomsCode.GDRoomsObjects2= [];
gdjs.RoomsCode.GDRoomsObjects3= [];
gdjs.RoomsCode.GDRoomsObjects4= [];
gdjs.RoomsCode.GDRoomsObjects5= [];
gdjs.RoomsCode.GDPixelFlameObjects1= [];
gdjs.RoomsCode.GDPixelFlameObjects2= [];
gdjs.RoomsCode.GDPixelFlameObjects3= [];
gdjs.RoomsCode.GDPixelFlameObjects4= [];
gdjs.RoomsCode.GDPixelFlameObjects5= [];
gdjs.RoomsCode.GDPixelSmokeObjects1= [];
gdjs.RoomsCode.GDPixelSmokeObjects2= [];
gdjs.RoomsCode.GDPixelSmokeObjects3= [];
gdjs.RoomsCode.GDPixelSmokeObjects4= [];
gdjs.RoomsCode.GDPixelSmokeObjects5= [];
gdjs.RoomsCode.GDfireObjects1= [];
gdjs.RoomsCode.GDfireObjects2= [];
gdjs.RoomsCode.GDfireObjects3= [];
gdjs.RoomsCode.GDfireObjects4= [];
gdjs.RoomsCode.GDfireObjects5= [];
gdjs.RoomsCode.GDsmalllight2Objects1= [];
gdjs.RoomsCode.GDsmalllight2Objects2= [];
gdjs.RoomsCode.GDsmalllight2Objects3= [];
gdjs.RoomsCode.GDsmalllight2Objects4= [];
gdjs.RoomsCode.GDsmalllight2Objects5= [];
gdjs.RoomsCode.GDkey_9595padObjects1= [];
gdjs.RoomsCode.GDkey_9595padObjects2= [];
gdjs.RoomsCode.GDkey_9595padObjects3= [];
gdjs.RoomsCode.GDkey_9595padObjects4= [];
gdjs.RoomsCode.GDkey_9595padObjects5= [];
gdjs.RoomsCode.GDcollisionObjects1= [];
gdjs.RoomsCode.GDcollisionObjects2= [];
gdjs.RoomsCode.GDcollisionObjects3= [];
gdjs.RoomsCode.GDcollisionObjects4= [];
gdjs.RoomsCode.GDcollisionObjects5= [];
gdjs.RoomsCode.GDkey_9595pad2Objects1= [];
gdjs.RoomsCode.GDkey_9595pad2Objects2= [];
gdjs.RoomsCode.GDkey_9595pad2Objects3= [];
gdjs.RoomsCode.GDkey_9595pad2Objects4= [];
gdjs.RoomsCode.GDkey_9595pad2Objects5= [];
gdjs.RoomsCode.GDtransitionObjects1= [];
gdjs.RoomsCode.GDtransitionObjects2= [];
gdjs.RoomsCode.GDtransitionObjects3= [];
gdjs.RoomsCode.GDtransitionObjects4= [];
gdjs.RoomsCode.GDtransitionObjects5= [];
gdjs.RoomsCode.GDexitObjects1= [];
gdjs.RoomsCode.GDexitObjects2= [];
gdjs.RoomsCode.GDexitObjects3= [];
gdjs.RoomsCode.GDexitObjects4= [];
gdjs.RoomsCode.GDexitObjects5= [];
gdjs.RoomsCode.GDtext_9595boxObjects1= [];
gdjs.RoomsCode.GDtext_9595boxObjects2= [];
gdjs.RoomsCode.GDtext_9595boxObjects3= [];
gdjs.RoomsCode.GDtext_9595boxObjects4= [];
gdjs.RoomsCode.GDtext_9595boxObjects5= [];
gdjs.RoomsCode.GDcharecters2Objects1= [];
gdjs.RoomsCode.GDcharecters2Objects2= [];
gdjs.RoomsCode.GDcharecters2Objects3= [];
gdjs.RoomsCode.GDcharecters2Objects4= [];
gdjs.RoomsCode.GDcharecters2Objects5= [];
gdjs.RoomsCode.GDNameObjects1= [];
gdjs.RoomsCode.GDNameObjects2= [];
gdjs.RoomsCode.GDNameObjects3= [];
gdjs.RoomsCode.GDNameObjects4= [];
gdjs.RoomsCode.GDNameObjects5= [];
gdjs.RoomsCode.GDDialogeObjects1= [];
gdjs.RoomsCode.GDDialogeObjects2= [];
gdjs.RoomsCode.GDDialogeObjects3= [];
gdjs.RoomsCode.GDDialogeObjects4= [];
gdjs.RoomsCode.GDDialogeObjects5= [];
gdjs.RoomsCode.GDarrowObjects1= [];
gdjs.RoomsCode.GDarrowObjects2= [];
gdjs.RoomsCode.GDarrowObjects3= [];
gdjs.RoomsCode.GDarrowObjects4= [];
gdjs.RoomsCode.GDarrowObjects5= [];
gdjs.RoomsCode.GDoptionsObjects1= [];
gdjs.RoomsCode.GDoptionsObjects2= [];
gdjs.RoomsCode.GDoptionsObjects3= [];
gdjs.RoomsCode.GDoptionsObjects4= [];
gdjs.RoomsCode.GDoptionsObjects5= [];
gdjs.RoomsCode.GDtipObjects1= [];
gdjs.RoomsCode.GDtipObjects2= [];
gdjs.RoomsCode.GDtipObjects3= [];
gdjs.RoomsCode.GDtipObjects4= [];
gdjs.RoomsCode.GDtipObjects5= [];
gdjs.RoomsCode.GDpasswordObjects1= [];
gdjs.RoomsCode.GDpasswordObjects2= [];
gdjs.RoomsCode.GDpasswordObjects3= [];
gdjs.RoomsCode.GDpasswordObjects4= [];
gdjs.RoomsCode.GDpasswordObjects5= [];
gdjs.RoomsCode.GDopenObjects1= [];
gdjs.RoomsCode.GDopenObjects2= [];
gdjs.RoomsCode.GDopenObjects3= [];
gdjs.RoomsCode.GDopenObjects4= [];
gdjs.RoomsCode.GDopenObjects5= [];
gdjs.RoomsCode.GDcloseObjects1= [];
gdjs.RoomsCode.GDcloseObjects2= [];
gdjs.RoomsCode.GDcloseObjects3= [];
gdjs.RoomsCode.GDcloseObjects4= [];
gdjs.RoomsCode.GDcloseObjects5= [];
gdjs.RoomsCode.GDcountdownObjects1= [];
gdjs.RoomsCode.GDcountdownObjects2= [];
gdjs.RoomsCode.GDcountdownObjects3= [];
gdjs.RoomsCode.GDcountdownObjects4= [];
gdjs.RoomsCode.GDcountdownObjects5= [];
gdjs.RoomsCode.GDtip2Objects1= [];
gdjs.RoomsCode.GDtip2Objects2= [];
gdjs.RoomsCode.GDtip2Objects3= [];
gdjs.RoomsCode.GDtip2Objects4= [];
gdjs.RoomsCode.GDtip2Objects5= [];
gdjs.RoomsCode.GDred_9595greenObjects1= [];
gdjs.RoomsCode.GDred_9595greenObjects2= [];
gdjs.RoomsCode.GDred_9595greenObjects3= [];
gdjs.RoomsCode.GDred_9595greenObjects4= [];
gdjs.RoomsCode.GDred_9595greenObjects5= [];
gdjs.RoomsCode.GDtip3Objects1= [];
gdjs.RoomsCode.GDtip3Objects2= [];
gdjs.RoomsCode.GDtip3Objects3= [];
gdjs.RoomsCode.GDtip3Objects4= [];
gdjs.RoomsCode.GDtip3Objects5= [];
gdjs.RoomsCode.GDobjects2Objects1= [];
gdjs.RoomsCode.GDobjects2Objects2= [];
gdjs.RoomsCode.GDobjects2Objects3= [];
gdjs.RoomsCode.GDobjects2Objects4= [];
gdjs.RoomsCode.GDobjects2Objects5= [];
gdjs.RoomsCode.GDWallObjects1= [];
gdjs.RoomsCode.GDWallObjects2= [];
gdjs.RoomsCode.GDWallObjects3= [];
gdjs.RoomsCode.GDWallObjects4= [];
gdjs.RoomsCode.GDWallObjects5= [];
gdjs.RoomsCode.GDfloorObjects1= [];
gdjs.RoomsCode.GDfloorObjects2= [];
gdjs.RoomsCode.GDfloorObjects3= [];
gdjs.RoomsCode.GDfloorObjects4= [];
gdjs.RoomsCode.GDfloorObjects5= [];
gdjs.RoomsCode.GDdoorsObjects1= [];
gdjs.RoomsCode.GDdoorsObjects2= [];
gdjs.RoomsCode.GDdoorsObjects3= [];
gdjs.RoomsCode.GDdoorsObjects4= [];
gdjs.RoomsCode.GDdoorsObjects5= [];
gdjs.RoomsCode.GDobjectsObjects1= [];
gdjs.RoomsCode.GDobjectsObjects2= [];
gdjs.RoomsCode.GDobjectsObjects3= [];
gdjs.RoomsCode.GDobjectsObjects4= [];
gdjs.RoomsCode.GDobjectsObjects5= [];
gdjs.RoomsCode.GDwallobjectObjects1= [];
gdjs.RoomsCode.GDwallobjectObjects2= [];
gdjs.RoomsCode.GDwallobjectObjects3= [];
gdjs.RoomsCode.GDwallobjectObjects4= [];
gdjs.RoomsCode.GDwallobjectObjects5= [];
gdjs.RoomsCode.GDwindowObjects1= [];
gdjs.RoomsCode.GDwindowObjects2= [];
gdjs.RoomsCode.GDwindowObjects3= [];
gdjs.RoomsCode.GDwindowObjects4= [];
gdjs.RoomsCode.GDwindowObjects5= [];
gdjs.RoomsCode.GDrailObjects1= [];
gdjs.RoomsCode.GDrailObjects2= [];
gdjs.RoomsCode.GDrailObjects3= [];
gdjs.RoomsCode.GDrailObjects4= [];
gdjs.RoomsCode.GDrailObjects5= [];
gdjs.RoomsCode.GDplayerObjects1= [];
gdjs.RoomsCode.GDplayerObjects2= [];
gdjs.RoomsCode.GDplayerObjects3= [];
gdjs.RoomsCode.GDplayerObjects4= [];
gdjs.RoomsCode.GDplayerObjects5= [];
gdjs.RoomsCode.GDhitboxObjects1= [];
gdjs.RoomsCode.GDhitboxObjects2= [];
gdjs.RoomsCode.GDhitboxObjects3= [];
gdjs.RoomsCode.GDhitboxObjects4= [];
gdjs.RoomsCode.GDhitboxObjects5= [];
gdjs.RoomsCode.GDMainlightObjects1= [];
gdjs.RoomsCode.GDMainlightObjects2= [];
gdjs.RoomsCode.GDMainlightObjects3= [];
gdjs.RoomsCode.GDMainlightObjects4= [];
gdjs.RoomsCode.GDMainlightObjects5= [];
gdjs.RoomsCode.GDsmalllightObjects1= [];
gdjs.RoomsCode.GDsmalllightObjects2= [];
gdjs.RoomsCode.GDsmalllightObjects3= [];
gdjs.RoomsCode.GDsmalllightObjects4= [];
gdjs.RoomsCode.GDsmalllightObjects5= [];
gdjs.RoomsCode.GDNewBitmapTextObjects1= [];
gdjs.RoomsCode.GDNewBitmapTextObjects2= [];
gdjs.RoomsCode.GDNewBitmapTextObjects3= [];
gdjs.RoomsCode.GDNewBitmapTextObjects4= [];
gdjs.RoomsCode.GDNewBitmapTextObjects5= [];
gdjs.RoomsCode.GDtask_9595barObjects1= [];
gdjs.RoomsCode.GDtask_9595barObjects2= [];
gdjs.RoomsCode.GDtask_9595barObjects3= [];
gdjs.RoomsCode.GDtask_9595barObjects4= [];
gdjs.RoomsCode.GDtask_9595barObjects5= [];
gdjs.RoomsCode.GDcharectersObjects1= [];
gdjs.RoomsCode.GDcharectersObjects2= [];
gdjs.RoomsCode.GDcharectersObjects3= [];
gdjs.RoomsCode.GDcharectersObjects4= [];
gdjs.RoomsCode.GDcharectersObjects5= [];
gdjs.RoomsCode.GDcharecters22Objects1= [];
gdjs.RoomsCode.GDcharecters22Objects2= [];
gdjs.RoomsCode.GDcharecters22Objects3= [];
gdjs.RoomsCode.GDcharecters22Objects4= [];
gdjs.RoomsCode.GDcharecters22Objects5= [];
gdjs.RoomsCode.GDPauseObjects1= [];
gdjs.RoomsCode.GDPauseObjects2= [];
gdjs.RoomsCode.GDPauseObjects3= [];
gdjs.RoomsCode.GDPauseObjects4= [];
gdjs.RoomsCode.GDPauseObjects5= [];
gdjs.RoomsCode.GDresumeObjects1= [];
gdjs.RoomsCode.GDresumeObjects2= [];
gdjs.RoomsCode.GDresumeObjects3= [];
gdjs.RoomsCode.GDresumeObjects4= [];
gdjs.RoomsCode.GDresumeObjects5= [];
gdjs.RoomsCode.GDQuit_95952Objects1= [];
gdjs.RoomsCode.GDQuit_95952Objects2= [];
gdjs.RoomsCode.GDQuit_95952Objects3= [];
gdjs.RoomsCode.GDQuit_95952Objects4= [];
gdjs.RoomsCode.GDQuit_95952Objects5= [];
gdjs.RoomsCode.GDpause_9595menuObjects1= [];
gdjs.RoomsCode.GDpause_9595menuObjects2= [];
gdjs.RoomsCode.GDpause_9595menuObjects3= [];
gdjs.RoomsCode.GDpause_9595menuObjects4= [];
gdjs.RoomsCode.GDpause_9595menuObjects5= [];
gdjs.RoomsCode.GDHimaObjects1= [];
gdjs.RoomsCode.GDHimaObjects2= [];
gdjs.RoomsCode.GDHimaObjects3= [];
gdjs.RoomsCode.GDHimaObjects4= [];
gdjs.RoomsCode.GDHimaObjects5= [];
gdjs.RoomsCode.GDLayaObjects1= [];
gdjs.RoomsCode.GDLayaObjects2= [];
gdjs.RoomsCode.GDLayaObjects3= [];
gdjs.RoomsCode.GDLayaObjects4= [];
gdjs.RoomsCode.GDLayaObjects5= [];
gdjs.RoomsCode.GDJoystickObjects1= [];
gdjs.RoomsCode.GDJoystickObjects2= [];
gdjs.RoomsCode.GDJoystickObjects3= [];
gdjs.RoomsCode.GDJoystickObjects4= [];
gdjs.RoomsCode.GDJoystickObjects5= [];
gdjs.RoomsCode.GDE_9595buttonObjects1= [];
gdjs.RoomsCode.GDE_9595buttonObjects2= [];
gdjs.RoomsCode.GDE_9595buttonObjects3= [];
gdjs.RoomsCode.GDE_9595buttonObjects4= [];
gdjs.RoomsCode.GDE_9595buttonObjects5= [];


gdjs.RoomsCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.RoomsCode.GDplayerObjects2, gdjs.RoomsCode.GDplayerObjects3);

{for(var i = 0, len = gdjs.RoomsCode.GDplayerObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDplayerObjects3[i].getBehavior("Flippable").flipX(false);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if (isConditionTrue_0) {
/* Reuse gdjs.RoomsCode.GDplayerObjects2 */
{for(var i = 0, len = gdjs.RoomsCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDplayerObjects2[i].getBehavior("Flippable").flipX(true);
}
}}

}


};gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects2});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDWallObjects2Objects = Hashtable.newFrom({"Wall": gdjs.RoomsCode.GDWallObjects2});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDWallObjects2Objects = Hashtable.newFrom({"Wall": gdjs.RoomsCode.GDWallObjects2});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects2});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDhitboxObjects2Objects = Hashtable.newFrom({"hitbox": gdjs.RoomsCode.GDhitboxObjects2});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDhitboxObjects2Objects = Hashtable.newFrom({"hitbox": gdjs.RoomsCode.GDhitboxObjects2});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects2});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDexitObjects2Objects = Hashtable.newFrom({"exit": gdjs.RoomsCode.GDexitObjects2});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDexitObjects2Objects = Hashtable.newFrom({"exit": gdjs.RoomsCode.GDexitObjects2});
gdjs.RoomsCode.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDplayerObjects2.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDplayerObjects2[i].getBehavior("TopDownMovement").isMoving() ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDplayerObjects2[k] = gdjs.RoomsCode.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.RoomsCode.GDplayerObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.RoomsCode.GDplayerObjects2 */
{for(var i = 0, len = gdjs.RoomsCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDplayerObjects2[i].getBehavior("Animation").setAnimationName("player-walk");
}
}
{ //Subevents
gdjs.RoomsCode.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDplayerObjects2.length;i<l;++i) {
    if ( !(gdjs.RoomsCode.GDplayerObjects2[i].getBehavior("TopDownMovement").isMoving()) ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDplayerObjects2[k] = gdjs.RoomsCode.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.RoomsCode.GDplayerObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.RoomsCode.GDplayerObjects2 */
{for(var i = 0, len = gdjs.RoomsCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDplayerObjects2[i].getBehavior("Animation").setAnimationName("player");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Wall"), gdjs.RoomsCode.GDWallObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects2Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDWallObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.RoomsCode.GDWallObjects2 */
/* Reuse gdjs.RoomsCode.GDplayerObjects2 */
{for(var i = 0, len = gdjs.RoomsCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDplayerObjects2[i].separateFromObjectsList(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDWallObjects2Objects, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("hitbox"), gdjs.RoomsCode.GDhitboxObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects2Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDhitboxObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.RoomsCode.GDhitboxObjects2 */
/* Reuse gdjs.RoomsCode.GDplayerObjects2 */
{for(var i = 0, len = gdjs.RoomsCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDplayerObjects2[i].separateFromObjectsList(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDhitboxObjects2Objects, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("exit"), gdjs.RoomsCode.GDexitObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects2Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDexitObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.RoomsCode.GDexitObjects2 */
/* Reuse gdjs.RoomsCode.GDplayerObjects2 */
{for(var i = 0, len = gdjs.RoomsCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDplayerObjects2[i].separateFromObjectsList(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDexitObjects2Objects, false);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects2);
{for(var i = 0, len = gdjs.RoomsCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDplayerObjects2[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "s");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects2);
{for(var i = 0, len = gdjs.RoomsCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDplayerObjects2[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects2);
{for(var i = 0, len = gdjs.RoomsCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDplayerObjects2[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects1);
{for(var i = 0, len = gdjs.RoomsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDplayerObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


};gdjs.RoomsCode.eventsList2 = function(runtimeScene) {

};gdjs.RoomsCode.eventsList3 = function(runtimeScene) {

};gdjs.RoomsCode.eventsList4 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("wallobject"), gdjs.RoomsCode.GDwallobjectObjects2);

for (gdjs.RoomsCode.forEachIndex3 = 0;gdjs.RoomsCode.forEachIndex3 < gdjs.RoomsCode.GDwallobjectObjects2.length;++gdjs.RoomsCode.forEachIndex3) {
gdjs.RoomsCode.GDwallobjectObjects3.length = 0;


gdjs.RoomsCode.forEachTemporary3 = gdjs.RoomsCode.GDwallobjectObjects2[gdjs.RoomsCode.forEachIndex3];
gdjs.RoomsCode.GDwallobjectObjects3.push(gdjs.RoomsCode.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {
{for(var i = 0, len = gdjs.RoomsCode.GDwallobjectObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDwallobjectObjects3[i].getBehavior("Animation").setAnimationSpeedScale(gdjs.randomFloatInRange(0.5, 1.5));
}
}}
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("charecters"), gdjs.RoomsCode.GDcharectersObjects2);

for (gdjs.RoomsCode.forEachIndex3 = 0;gdjs.RoomsCode.forEachIndex3 < gdjs.RoomsCode.GDcharectersObjects2.length;++gdjs.RoomsCode.forEachIndex3) {
gdjs.RoomsCode.GDcharectersObjects3.length = 0;


gdjs.RoomsCode.forEachTemporary3 = gdjs.RoomsCode.GDcharectersObjects2[gdjs.RoomsCode.forEachIndex3];
gdjs.RoomsCode.GDcharectersObjects3.push(gdjs.RoomsCode.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {
{for(var i = 0, len = gdjs.RoomsCode.GDcharectersObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDcharectersObjects3[i].getBehavior("Animation").setAnimationSpeedScale(gdjs.randomFloatInRange(0.5, 1.5));
}
}}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("hitbox"), gdjs.RoomsCode.GDhitboxObjects1);
gdjs.copyArray(runtimeScene.getObjects("key_pad"), gdjs.RoomsCode.GDkey_9595padObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects1);
{for(var i = 0, len = gdjs.RoomsCode.GDhitboxObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDhitboxObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.RoomsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDplayerObjects1[i].getBehavior("SmoothCamera").SetFollowOnX(false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.RoomsCode.GDkey_9595padObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDkey_9595padObjects1[i].getBehavior("Animation").setAnimationIndex(runtimeScene.getGame().getVariables().getFromIndex(1).getAsNumber() - 1);
}
}}

}


};gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects1});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDexitObjects1Objects = Hashtable.newFrom({"exit": gdjs.RoomsCode.GDexitObjects1});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects1});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDexitObjects1Objects = Hashtable.newFrom({"exit": gdjs.RoomsCode.GDexitObjects1});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects1});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDdoorsObjects1Objects = Hashtable.newFrom({"doors": gdjs.RoomsCode.GDdoorsObjects1});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects1});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects1Objects = Hashtable.newFrom({"charecters": gdjs.RoomsCode.GDcharectersObjects1});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects1});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDexitObjects1Objects = Hashtable.newFrom({"exit": gdjs.RoomsCode.GDexitObjects1});
gdjs.RoomsCode.asyncCallback29699860 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.RoomsCode.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "School", false);
}gdjs.RoomsCode.localVariables.length = 0;
}
gdjs.RoomsCode.eventsList5 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.RoomsCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.RoomsCode.asyncCallback29699860(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcollisionObjects1Objects = Hashtable.newFrom({"collision": gdjs.RoomsCode.GDcollisionObjects1});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcollisionObjects1Objects = Hashtable.newFrom({"collision": gdjs.RoomsCode.GDcollisionObjects1});
gdjs.RoomsCode.asyncCallback29705548 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.RoomsCode.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "School", false);
}gdjs.RoomsCode.localVariables.length = 0;
}
gdjs.RoomsCode.eventsList6 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.RoomsCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.RoomsCode.asyncCallback29705548(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.RoomsCode.asyncCallback29704812 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.RoomsCode.localVariables);
gdjs.copyArray(runtimeScene.getObjects("transition"), gdjs.RoomsCode.GDtransitionObjects2);
{for(var i = 0, len = gdjs.RoomsCode.GDtransitionObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDtransitionObjects2[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 0.2, "Flash", "Forward", 100, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.RoomsCode.eventsList6(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.RoomsCode.localVariables.length = 0;
}
gdjs.RoomsCode.eventsList7 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.RoomsCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.RoomsCode.asyncCallback29704812(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcollisionObjects1Objects = Hashtable.newFrom({"collision": gdjs.RoomsCode.GDcollisionObjects1});
gdjs.RoomsCode.asyncCallback29709948 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.RoomsCode.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "School", false);
}gdjs.RoomsCode.localVariables.length = 0;
}
gdjs.RoomsCode.eventsList8 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.RoomsCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.RoomsCode.asyncCallback29709948(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.RoomsCode.asyncCallback29708532 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.RoomsCode.localVariables);
gdjs.copyArray(runtimeScene.getObjects("transition"), gdjs.RoomsCode.GDtransitionObjects2);
{for(var i = 0, len = gdjs.RoomsCode.GDtransitionObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDtransitionObjects2[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 0.2, "Flash", "Forward", 100, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.RoomsCode.eventsList8(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.RoomsCode.localVariables.length = 0;
}
gdjs.RoomsCode.eventsList9 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.RoomsCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.RoomsCode.asyncCallback29708532(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcollisionObjects1Objects = Hashtable.newFrom({"collision": gdjs.RoomsCode.GDcollisionObjects1});
gdjs.RoomsCode.asyncCallback29712772 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.RoomsCode.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "School", false);
}gdjs.RoomsCode.localVariables.length = 0;
}
gdjs.RoomsCode.eventsList10 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.RoomsCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.RoomsCode.asyncCallback29712772(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects1});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDdoorsObjects1Objects = Hashtable.newFrom({"doors": gdjs.RoomsCode.GDdoorsObjects1});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects1});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDdoorsObjects1Objects = Hashtable.newFrom({"doors": gdjs.RoomsCode.GDdoorsObjects1});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects1});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDdoorsObjects1Objects = Hashtable.newFrom({"doors": gdjs.RoomsCode.GDdoorsObjects1});
gdjs.RoomsCode.asyncCallback29719772 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.RoomsCode.localVariables);
{runtimeScene.getGame().getVariables().getFromIndex(0).setString("Bathroom-3");
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Rooms", false);
}{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(2);
}gdjs.RoomsCode.localVariables.length = 0;
}
gdjs.RoomsCode.eventsList11 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.RoomsCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.RoomsCode.asyncCallback29719772(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects1});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDdoorsObjects1Objects = Hashtable.newFrom({"doors": gdjs.RoomsCode.GDdoorsObjects1});
gdjs.RoomsCode.asyncCallback29723012 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.RoomsCode.localVariables);
{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(3);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Rooms", false);
}gdjs.RoomsCode.localVariables.length = 0;
}
gdjs.RoomsCode.eventsList12 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.RoomsCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.RoomsCode.asyncCallback29723012(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects1});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDexitObjects1Objects = Hashtable.newFrom({"exit": gdjs.RoomsCode.GDexitObjects1});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects1});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDdoorsObjects1Objects = Hashtable.newFrom({"doors": gdjs.RoomsCode.GDdoorsObjects1});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects1});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDexitObjects1Objects = Hashtable.newFrom({"exit": gdjs.RoomsCode.GDexitObjects1});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects1});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDdoorsObjects1Objects = Hashtable.newFrom({"doors": gdjs.RoomsCode.GDdoorsObjects1});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects1});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDobjectsObjects1Objects = Hashtable.newFrom({"objects": gdjs.RoomsCode.GDobjectsObjects1});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects1});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDobjectsObjects1Objects = Hashtable.newFrom({"objects": gdjs.RoomsCode.GDobjectsObjects1});
gdjs.RoomsCode.eventsList13 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("pause_menu"), gdjs.RoomsCode.GDpause_9595menuObjects2);
{for(var i = 0, len = gdjs.RoomsCode.GDpause_9595menuObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDpause_9595menuObjects2[i].getBehavior("Opacity").setOpacity(125);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Pause"), gdjs.RoomsCode.GDPauseObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDPauseObjects2.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDPauseObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDPauseObjects2[k] = gdjs.RoomsCode.GDPauseObjects2[i];
        ++k;
    }
}
gdjs.RoomsCode.GDPauseObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29731748);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.camera.showLayer(runtimeScene, "pause");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "ui");
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("resume"), gdjs.RoomsCode.GDresumeObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDresumeObjects2.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDresumeObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDresumeObjects2[k] = gdjs.RoomsCode.GDresumeObjects2[i];
        ++k;
    }
}
gdjs.RoomsCode.GDresumeObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29733012);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "pause");
}{gdjs.evtTools.camera.showLayer(runtimeScene, "ui");
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Quit_2"), gdjs.RoomsCode.GDQuit_95952Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDQuit_95952Objects1.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDQuit_95952Objects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDQuit_95952Objects1[k] = gdjs.RoomsCode.GDQuit_95952Objects1[i];
        ++k;
    }
}
gdjs.RoomsCode.GDQuit_95952Objects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29734292);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Main Menu", false);
}}

}


};gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects = Hashtable.newFrom({"charecters": gdjs.RoomsCode.GDcharectersObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects = Hashtable.newFrom({"charecters": gdjs.RoomsCode.GDcharectersObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects = Hashtable.newFrom({"charecters": gdjs.RoomsCode.GDcharectersObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects = Hashtable.newFrom({"charecters": gdjs.RoomsCode.GDcharectersObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects = Hashtable.newFrom({"charecters": gdjs.RoomsCode.GDcharectersObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects = Hashtable.newFrom({"charecters": gdjs.RoomsCode.GDcharectersObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharecters22Objects3Objects = Hashtable.newFrom({"charecters22": gdjs.RoomsCode.GDcharecters22Objects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharecters22Objects3Objects = Hashtable.newFrom({"charecters22": gdjs.RoomsCode.GDcharecters22Objects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharecters22Objects3Objects = Hashtable.newFrom({"charecters22": gdjs.RoomsCode.GDcharecters22Objects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharecters22Objects3Objects = Hashtable.newFrom({"charecters22": gdjs.RoomsCode.GDcharecters22Objects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharecters22Objects3Objects = Hashtable.newFrom({"charecters22": gdjs.RoomsCode.GDcharecters22Objects3});
gdjs.RoomsCode.eventsList14 = function(runtimeScene) {

};gdjs.RoomsCode.eventsList15 = function(runtimeScene) {

{


const repeatCount3 = 3;
for (let repeatIndex3 = 0;repeatIndex3 < repeatCount3;++repeatIndex3) {
gdjs.copyArray(runtimeScene.getObjects("charecters"), gdjs.RoomsCode.GDcharectersObjects3);
gdjs.RoomsCode.GDcharecters22Objects3.length = 0;


let isConditionTrue_0 = false;
if (true)
{
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharecters22Objects3Objects, (( gdjs.RoomsCode.GDcharectersObjects3.length === 0 ) ? 0 :gdjs.RoomsCode.GDcharectersObjects3[0].getPointX("")) + 8 * gdjs.RoomsCode.localVariables[0].getFromIndex(0).getAsNumber() + 16 * gdjs.RoomsCode.localVariables[0].getFromIndex(0).getAsNumber(), (( gdjs.RoomsCode.GDcharectersObjects3.length === 0 ) ? 0 :gdjs.RoomsCode.GDcharectersObjects3[0].getPointY("")), "");
}{gdjs.RoomsCode.localVariables[0].getFromIndex(0).add(1);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharecters22Objects3Objects, (( gdjs.RoomsCode.GDcharectersObjects3.length === 0 ) ? 0 :gdjs.RoomsCode.GDcharectersObjects3[0].getPointX("")) + 8 * gdjs.RoomsCode.localVariables[0].getFromIndex(0).getAsNumber() + 16 * gdjs.RoomsCode.localVariables[0].getFromIndex(0).getAsNumber(), (( gdjs.RoomsCode.GDcharectersObjects3.length === 0 ) ? 0 :gdjs.RoomsCode.GDcharectersObjects3[0].getPointY("")), "");
}{gdjs.RoomsCode.localVariables[0].getFromIndex(0).add(1);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharecters22Objects3Objects, (( gdjs.RoomsCode.GDcharectersObjects3.length === 0 ) ? 0 :gdjs.RoomsCode.GDcharectersObjects3[0].getPointX("")) + 8 * gdjs.RoomsCode.localVariables[0].getFromIndex(0).getAsNumber() + 16 * gdjs.RoomsCode.localVariables[0].getFromIndex(0).getAsNumber(), (( gdjs.RoomsCode.GDcharectersObjects3.length === 0 ) ? 0 :gdjs.RoomsCode.GDcharectersObjects3[0].getPointY("")), "");
}{gdjs.RoomsCode.localVariables[0].getFromIndex(0).add(1);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharecters22Objects3Objects, (( gdjs.RoomsCode.GDcharectersObjects3.length === 0 ) ? 0 :gdjs.RoomsCode.GDcharectersObjects3[0].getPointX("")) + 8 * gdjs.RoomsCode.localVariables[0].getFromIndex(0).getAsNumber() + 16 * gdjs.RoomsCode.localVariables[0].getFromIndex(0).getAsNumber(), (( gdjs.RoomsCode.GDcharectersObjects3.length === 0 ) ? 0 :gdjs.RoomsCode.GDcharectersObjects3[0].getPointY("")), "");
}{gdjs.RoomsCode.localVariables[0].getFromIndex(0).add(1);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharecters22Objects3Objects, (( gdjs.RoomsCode.GDcharectersObjects3.length === 0 ) ? 0 :gdjs.RoomsCode.GDcharectersObjects3[0].getPointX("")) + 8 * gdjs.RoomsCode.localVariables[0].getFromIndex(0).getAsNumber() + 16 * gdjs.RoomsCode.localVariables[0].getFromIndex(0).getAsNumber(), (( gdjs.RoomsCode.GDcharectersObjects3.length === 0 ) ? 0 :gdjs.RoomsCode.GDcharectersObjects3[0].getPointY("")), "");
}{gdjs.RoomsCode.localVariables[0].getFromIndex(0).add(1);
}{for(var i = 0, len = gdjs.RoomsCode.GDcharecters22Objects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDcharecters22Objects3[i].setZOrder(6);
}
}{for(var i = 0, len = gdjs.RoomsCode.GDcharecters22Objects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDcharecters22Objects3[i].getBehavior("Animation").setAnimationName("happy");
}
}}
}

}


};gdjs.RoomsCode.eventsList16 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("charecters"), gdjs.RoomsCode.GDcharectersObjects3);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects3);
gdjs.RoomsCode.GDE_9595buttonObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDE_9595buttonObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects4);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDE_9595buttonObjects4.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDE_9595buttonObjects4[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDE_9595buttonObjects4[k] = gdjs.RoomsCode.GDE_9595buttonObjects4[i];
        ++k;
    }
}
gdjs.RoomsCode.GDE_9595buttonObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDE_9595buttonObjects4.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDE_9595buttonObjects3_1final.indexOf(gdjs.RoomsCode.GDE_9595buttonObjects4[j]) === -1 )
            gdjs.RoomsCode.GDE_9595buttonObjects3_1final.push(gdjs.RoomsCode.GDE_9595buttonObjects4[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDE_9595buttonObjects3_1final, gdjs.RoomsCode.GDE_9595buttonObjects3);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("task"), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("misionstate"), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("state")) == 2;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects, 80, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDcharectersObjects3.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDcharectersObjects3[i].getBehavior("Animation").getAnimationName() == "oldman" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDcharectersObjects3[k] = gdjs.RoomsCode.GDcharectersObjects3[i];
        ++k;
    }
}
gdjs.RoomsCode.GDcharectersObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "conversation"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause"));
}
}
}
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Name"), gdjs.RoomsCode.GDNameObjects3);
gdjs.copyArray(runtimeScene.getObjects("charecters2"), gdjs.RoomsCode.GDcharecters2Objects3);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollspeed");
}{for(var i = 0, len = gdjs.RoomsCode.GDcharecters2Objects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDcharecters2Objects3[i].getBehavior("Animation").setAnimationName("oldman");
}
}{gdjs.dialogueTree.startFrom("grandpa-4");
}{for(var i = 0, len = gdjs.RoomsCode.GDNameObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDNameObjects3[i].getBehavior("Text").setText("Cayo");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("charecters"), gdjs.RoomsCode.GDcharectersObjects3);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects3);
gdjs.RoomsCode.GDE_9595buttonObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDE_9595buttonObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects4);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDE_9595buttonObjects4.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDE_9595buttonObjects4[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDE_9595buttonObjects4[k] = gdjs.RoomsCode.GDE_9595buttonObjects4[i];
        ++k;
    }
}
gdjs.RoomsCode.GDE_9595buttonObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDE_9595buttonObjects4.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDE_9595buttonObjects3_1final.indexOf(gdjs.RoomsCode.GDE_9595buttonObjects4[j]) === -1 )
            gdjs.RoomsCode.GDE_9595buttonObjects3_1final.push(gdjs.RoomsCode.GDE_9595buttonObjects4[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDE_9595buttonObjects3_1final, gdjs.RoomsCode.GDE_9595buttonObjects3);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("state")) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("task"), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(11).getChild("mision"), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects, 80, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDcharectersObjects3.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDcharectersObjects3[i].getBehavior("Animation").getAnimationName() == "oldman" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDcharectersObjects3[k] = gdjs.RoomsCode.GDcharectersObjects3[i];
        ++k;
    }
}
gdjs.RoomsCode.GDcharectersObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "conversation"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause"));
}
}
}
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Name"), gdjs.RoomsCode.GDNameObjects3);
gdjs.copyArray(runtimeScene.getObjects("charecters2"), gdjs.RoomsCode.GDcharecters2Objects3);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollspeed");
}{for(var i = 0, len = gdjs.RoomsCode.GDcharecters2Objects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDcharecters2Objects3[i].getBehavior("Animation").setAnimationName("oldman");
}
}{gdjs.dialogueTree.startFrom("grandpa-3");
}{runtimeScene.getGame().getVariables().getFromIndex(3).getChild("state").setNumber(2);
}{runtimeScene.getGame().getVariables().getFromIndex(3).getChild("task").setBoolean(true);
}{for(var i = 0, len = gdjs.RoomsCode.GDNameObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDNameObjects3[i].getBehavior("Text").setText("Cayo");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("charecters"), gdjs.RoomsCode.GDcharectersObjects3);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects3);
gdjs.RoomsCode.GDE_9595buttonObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDE_9595buttonObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects4);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDE_9595buttonObjects4.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDE_9595buttonObjects4[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDE_9595buttonObjects4[k] = gdjs.RoomsCode.GDE_9595buttonObjects4[i];
        ++k;
    }
}
gdjs.RoomsCode.GDE_9595buttonObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDE_9595buttonObjects4.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDE_9595buttonObjects3_1final.indexOf(gdjs.RoomsCode.GDE_9595buttonObjects4[j]) === -1 )
            gdjs.RoomsCode.GDE_9595buttonObjects3_1final.push(gdjs.RoomsCode.GDE_9595buttonObjects4[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDE_9595buttonObjects3_1final, gdjs.RoomsCode.GDE_9595buttonObjects3);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("state")) == 2;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("task"), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("misionstate"), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects, 80, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDcharectersObjects3.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDcharectersObjects3[i].getBehavior("Animation").getAnimationName() == "oldman" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDcharectersObjects3[k] = gdjs.RoomsCode.GDcharectersObjects3[i];
        ++k;
    }
}
gdjs.RoomsCode.GDcharectersObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "conversation"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause"));
}
}
}
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Name"), gdjs.RoomsCode.GDNameObjects3);
gdjs.copyArray(runtimeScene.getObjects("charecters2"), gdjs.RoomsCode.GDcharecters2Objects3);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollspeed");
}{for(var i = 0, len = gdjs.RoomsCode.GDcharecters2Objects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDcharecters2Objects3[i].getBehavior("Animation").setAnimationName("oldman");
}
}{runtimeScene.getGame().getVariables().getFromIndex(3).getChild("state").setNumber(1);
}{runtimeScene.getGame().getVariables().getFromIndex(11).getChild("collect").add(1);
}{gdjs.dialogueTree.startFrom("grandpa-5");
}{for(var i = 0, len = gdjs.RoomsCode.GDNameObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDNameObjects3[i].getBehavior("Text").setText("Cayo");
}
}}

}


{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("x", variable);
}
gdjs.RoomsCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("state")) == 2;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("task"), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("misionstate"), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Grandpa's";
}
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.RoomsCode.eventsList15(runtimeScene);} //End of subevents
}
gdjs.RoomsCode.localVariables.pop();

}


};gdjs.RoomsCode.eventsList17 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("charecters"), gdjs.RoomsCode.GDcharectersObjects3);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects3);
gdjs.RoomsCode.GDE_9595buttonObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDE_9595buttonObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects4);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDE_9595buttonObjects4.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDE_9595buttonObjects4[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDE_9595buttonObjects4[k] = gdjs.RoomsCode.GDE_9595buttonObjects4[i];
        ++k;
    }
}
gdjs.RoomsCode.GDE_9595buttonObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDE_9595buttonObjects4.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDE_9595buttonObjects3_1final.indexOf(gdjs.RoomsCode.GDE_9595buttonObjects4[j]) === -1 )
            gdjs.RoomsCode.GDE_9595buttonObjects3_1final.push(gdjs.RoomsCode.GDE_9595buttonObjects4[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDE_9595buttonObjects3_1final, gdjs.RoomsCode.GDE_9595buttonObjects3);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("state")) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects, 80, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDcharectersObjects3.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDcharectersObjects3[i].getBehavior("Animation").getAnimationName() == "oldman" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDcharectersObjects3[k] = gdjs.RoomsCode.GDcharectersObjects3[i];
        ++k;
    }
}
gdjs.RoomsCode.GDcharectersObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "conversation"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause"));
}
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Name"), gdjs.RoomsCode.GDNameObjects3);
gdjs.copyArray(runtimeScene.getObjects("arrow"), gdjs.RoomsCode.GDarrowObjects3);
gdjs.copyArray(runtimeScene.getObjects("charecters2"), gdjs.RoomsCode.GDcharecters2Objects3);
gdjs.copyArray(runtimeScene.getObjects("options"), gdjs.RoomsCode.GDoptionsObjects3);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollspeed");
}{gdjs.dialogueTree.startFrom("grandpa-1");
}{for(var i = 0, len = gdjs.RoomsCode.GDcharecters2Objects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDcharecters2Objects3[i].getBehavior("Animation").setAnimationName("oldman");
}
}{runtimeScene.getGame().getVariables().getFromIndex(3).getChild("state").setNumber(1);
}{for(var i = 0, len = gdjs.RoomsCode.GDNameObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDNameObjects3[i].getBehavior("Text").setText("Cayo");
}
}{for(var i = 0, len = gdjs.RoomsCode.GDoptionsObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDoptionsObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.RoomsCode.GDarrowObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDarrowObjects3[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("charecters"), gdjs.RoomsCode.GDcharectersObjects3);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects3);
gdjs.RoomsCode.GDE_9595buttonObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDE_9595buttonObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects4);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDE_9595buttonObjects4.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDE_9595buttonObjects4[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDE_9595buttonObjects4[k] = gdjs.RoomsCode.GDE_9595buttonObjects4[i];
        ++k;
    }
}
gdjs.RoomsCode.GDE_9595buttonObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDE_9595buttonObjects4.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDE_9595buttonObjects3_1final.indexOf(gdjs.RoomsCode.GDE_9595buttonObjects4[j]) === -1 )
            gdjs.RoomsCode.GDE_9595buttonObjects3_1final.push(gdjs.RoomsCode.GDE_9595buttonObjects4[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDE_9595buttonObjects3_1final, gdjs.RoomsCode.GDE_9595buttonObjects3);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("state")) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("task"), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(11).getChild("mision"), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects, 80, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDcharectersObjects3.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDcharectersObjects3[i].getBehavior("Animation").getAnimationName() == "oldman" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDcharectersObjects3[k] = gdjs.RoomsCode.GDcharectersObjects3[i];
        ++k;
    }
}
gdjs.RoomsCode.GDcharectersObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "conversation"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause"));
}
}
}
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Name"), gdjs.RoomsCode.GDNameObjects3);
gdjs.copyArray(runtimeScene.getObjects("charecters2"), gdjs.RoomsCode.GDcharecters2Objects3);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollspeed");
}{for(var i = 0, len = gdjs.RoomsCode.GDcharecters2Objects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDcharecters2Objects3[i].getBehavior("Animation").setAnimationName("oldman");
}
}{gdjs.dialogueTree.startFrom("grandpa-2");
}{for(var i = 0, len = gdjs.RoomsCode.GDNameObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDNameObjects3[i].getBehavior("Text").setText("Cayo");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("charecters"), gdjs.RoomsCode.GDcharectersObjects3);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects3);
gdjs.RoomsCode.GDE_9595buttonObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDE_9595buttonObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects4);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDE_9595buttonObjects4.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDE_9595buttonObjects4[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDE_9595buttonObjects4[k] = gdjs.RoomsCode.GDE_9595buttonObjects4[i];
        ++k;
    }
}
gdjs.RoomsCode.GDE_9595buttonObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDE_9595buttonObjects4.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDE_9595buttonObjects3_1final.indexOf(gdjs.RoomsCode.GDE_9595buttonObjects4[j]) === -1 )
            gdjs.RoomsCode.GDE_9595buttonObjects3_1final.push(gdjs.RoomsCode.GDE_9595buttonObjects4[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDE_9595buttonObjects3_1final, gdjs.RoomsCode.GDE_9595buttonObjects3);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("state")) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("task"), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(11).getChild("mision"), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects, 80, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDcharectersObjects3.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDcharectersObjects3[i].getBehavior("Animation").getAnimationName() == "oldman" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDcharectersObjects3[k] = gdjs.RoomsCode.GDcharectersObjects3[i];
        ++k;
    }
}
gdjs.RoomsCode.GDcharectersObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "conversation"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause"));
}
}
}
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Name"), gdjs.RoomsCode.GDNameObjects3);
gdjs.copyArray(runtimeScene.getObjects("charecters2"), gdjs.RoomsCode.GDcharecters2Objects3);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollspeed");
}{for(var i = 0, len = gdjs.RoomsCode.GDcharecters2Objects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDcharecters2Objects3[i].getBehavior("Animation").setAnimationName("oldman");
}
}{gdjs.dialogueTree.startFrom("grandpa-2");
}{for(var i = 0, len = gdjs.RoomsCode.GDNameObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDNameObjects3[i].getBehavior("Text").setText("Cayo");
}
}}

}


{


gdjs.RoomsCode.eventsList16(runtimeScene);
}


};gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects = Hashtable.newFrom({"charecters": gdjs.RoomsCode.GDcharectersObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects2});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects2Objects = Hashtable.newFrom({"charecters": gdjs.RoomsCode.GDcharectersObjects2});
gdjs.RoomsCode.eventsList18 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("charecters"), gdjs.RoomsCode.GDcharectersObjects3);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects3);
gdjs.RoomsCode.GDE_9595buttonObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDE_9595buttonObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects4);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDE_9595buttonObjects4.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDE_9595buttonObjects4[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDE_9595buttonObjects4[k] = gdjs.RoomsCode.GDE_9595buttonObjects4[i];
        ++k;
    }
}
gdjs.RoomsCode.GDE_9595buttonObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDE_9595buttonObjects4.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDE_9595buttonObjects3_1final.indexOf(gdjs.RoomsCode.GDE_9595buttonObjects4[j]) === -1 )
            gdjs.RoomsCode.GDE_9595buttonObjects3_1final.push(gdjs.RoomsCode.GDE_9595buttonObjects4[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDE_9595buttonObjects3_1final, gdjs.RoomsCode.GDE_9595buttonObjects3);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4).getChild("state")) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects, 80, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDcharectersObjects3.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDcharectersObjects3[i].getBehavior("Animation").getAnimationName() == "sleeper" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDcharectersObjects3[k] = gdjs.RoomsCode.GDcharectersObjects3[i];
        ++k;
    }
}
gdjs.RoomsCode.GDcharectersObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "conversation"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause"));
}
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Name"), gdjs.RoomsCode.GDNameObjects3);
gdjs.copyArray(runtimeScene.getObjects("arrow"), gdjs.RoomsCode.GDarrowObjects3);
gdjs.copyArray(runtimeScene.getObjects("charecters2"), gdjs.RoomsCode.GDcharecters2Objects3);
gdjs.copyArray(runtimeScene.getObjects("options"), gdjs.RoomsCode.GDoptionsObjects3);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollspeed");
}{gdjs.dialogueTree.startFrom("sleeper-start");
}{for(var i = 0, len = gdjs.RoomsCode.GDcharecters2Objects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDcharecters2Objects3[i].getBehavior("Animation").setAnimationName("sleeper");
}
}{runtimeScene.getGame().getVariables().getFromIndex(4).getChild("state").setNumber(1);
}{for(var i = 0, len = gdjs.RoomsCode.GDNameObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDNameObjects3[i].getBehavior("Text").setText("Mebo");
}
}{for(var i = 0, len = gdjs.RoomsCode.GDoptionsObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDoptionsObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.RoomsCode.GDarrowObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDarrowObjects3[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("charecters"), gdjs.RoomsCode.GDcharectersObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects2);
gdjs.RoomsCode.GDE_9595buttonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDE_9595buttonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects3);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDE_9595buttonObjects3.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDE_9595buttonObjects3[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDE_9595buttonObjects3[k] = gdjs.RoomsCode.GDE_9595buttonObjects3[i];
        ++k;
    }
}
gdjs.RoomsCode.GDE_9595buttonObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDE_9595buttonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDE_9595buttonObjects2_1final.indexOf(gdjs.RoomsCode.GDE_9595buttonObjects3[j]) === -1 )
            gdjs.RoomsCode.GDE_9595buttonObjects2_1final.push(gdjs.RoomsCode.GDE_9595buttonObjects3[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDE_9595buttonObjects2_1final, gdjs.RoomsCode.GDE_9595buttonObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4).getChild("state")) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects2Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects2Objects, 80, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDcharectersObjects2.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDcharectersObjects2[i].getBehavior("Animation").getAnimationName() == "sleeper" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDcharectersObjects2[k] = gdjs.RoomsCode.GDcharectersObjects2[i];
        ++k;
    }
}
gdjs.RoomsCode.GDcharectersObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "conversation"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause"));
}
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Name"), gdjs.RoomsCode.GDNameObjects2);
gdjs.copyArray(runtimeScene.getObjects("charecters2"), gdjs.RoomsCode.GDcharecters2Objects2);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollspeed");
}{for(var i = 0, len = gdjs.RoomsCode.GDcharecters2Objects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDcharecters2Objects2[i].getBehavior("Animation").setAnimationName("sleeper");
}
}{gdjs.dialogueTree.startFrom("sleeper-2");
}{for(var i = 0, len = gdjs.RoomsCode.GDNameObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDNameObjects2[i].getBehavior("Text").setText("Mebo");
}
}}

}


};gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects = Hashtable.newFrom({"charecters": gdjs.RoomsCode.GDcharectersObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects = Hashtable.newFrom({"charecters": gdjs.RoomsCode.GDcharectersObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects = Hashtable.newFrom({"charecters": gdjs.RoomsCode.GDcharectersObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects = Hashtable.newFrom({"charecters": gdjs.RoomsCode.GDcharectersObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects2});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects2Objects = Hashtable.newFrom({"charecters": gdjs.RoomsCode.GDcharectersObjects2});
gdjs.RoomsCode.eventsList19 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("charecters"), gdjs.RoomsCode.GDcharectersObjects3);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects3);
gdjs.RoomsCode.GDE_9595buttonObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDE_9595buttonObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects4);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDE_9595buttonObjects4.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDE_9595buttonObjects4[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDE_9595buttonObjects4[k] = gdjs.RoomsCode.GDE_9595buttonObjects4[i];
        ++k;
    }
}
gdjs.RoomsCode.GDE_9595buttonObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDE_9595buttonObjects4.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDE_9595buttonObjects3_1final.indexOf(gdjs.RoomsCode.GDE_9595buttonObjects4[j]) === -1 )
            gdjs.RoomsCode.GDE_9595buttonObjects3_1final.push(gdjs.RoomsCode.GDE_9595buttonObjects4[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDE_9595buttonObjects3_1final, gdjs.RoomsCode.GDE_9595buttonObjects3);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(5).getChild("task"), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(5).getChild("misionstate"), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5).getChild("state")) == 2;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects, 80, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDcharectersObjects3.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDcharectersObjects3[i].getBehavior("Animation").getAnimationName() == "librarian" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDcharectersObjects3[k] = gdjs.RoomsCode.GDcharectersObjects3[i];
        ++k;
    }
}
gdjs.RoomsCode.GDcharectersObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "conversation"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause"));
}
}
}
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Name"), gdjs.RoomsCode.GDNameObjects3);
gdjs.copyArray(runtimeScene.getObjects("charecters2"), gdjs.RoomsCode.GDcharecters2Objects3);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollspeed");
}{for(var i = 0, len = gdjs.RoomsCode.GDcharecters2Objects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDcharecters2Objects3[i].getBehavior("Animation").setAnimationName("librarian");
}
}{gdjs.dialogueTree.startFrom("librarian-4");
}{for(var i = 0, len = gdjs.RoomsCode.GDNameObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDNameObjects3[i].getBehavior("Text").setText("Meha");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("charecters"), gdjs.RoomsCode.GDcharectersObjects3);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects3);
gdjs.RoomsCode.GDE_9595buttonObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDE_9595buttonObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects4);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDE_9595buttonObjects4.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDE_9595buttonObjects4[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDE_9595buttonObjects4[k] = gdjs.RoomsCode.GDE_9595buttonObjects4[i];
        ++k;
    }
}
gdjs.RoomsCode.GDE_9595buttonObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDE_9595buttonObjects4.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDE_9595buttonObjects3_1final.indexOf(gdjs.RoomsCode.GDE_9595buttonObjects4[j]) === -1 )
            gdjs.RoomsCode.GDE_9595buttonObjects3_1final.push(gdjs.RoomsCode.GDE_9595buttonObjects4[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDE_9595buttonObjects3_1final, gdjs.RoomsCode.GDE_9595buttonObjects3);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5).getChild("state")) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(5).getChild("task"), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(11).getChild("mision"), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects, 80, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDcharectersObjects3.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDcharectersObjects3[i].getBehavior("Animation").getAnimationName() == "librarian" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDcharectersObjects3[k] = gdjs.RoomsCode.GDcharectersObjects3[i];
        ++k;
    }
}
gdjs.RoomsCode.GDcharectersObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "conversation"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause"));
}
}
}
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Name"), gdjs.RoomsCode.GDNameObjects3);
gdjs.copyArray(runtimeScene.getObjects("charecters2"), gdjs.RoomsCode.GDcharecters2Objects3);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollspeed");
}{for(var i = 0, len = gdjs.RoomsCode.GDcharecters2Objects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDcharecters2Objects3[i].getBehavior("Animation").setAnimationName("librarian");
}
}{gdjs.dialogueTree.startFrom("librarian-3");
}{runtimeScene.getGame().getVariables().getFromIndex(5).getChild("state").setNumber(2);
}{runtimeScene.getGame().getVariables().getFromIndex(5).getChild("task").setBoolean(true);
}{for(var i = 0, len = gdjs.RoomsCode.GDNameObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDNameObjects3[i].getBehavior("Text").setText("Meha");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("charecters"), gdjs.RoomsCode.GDcharectersObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects2);
gdjs.RoomsCode.GDE_9595buttonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDE_9595buttonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects3);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDE_9595buttonObjects3.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDE_9595buttonObjects3[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDE_9595buttonObjects3[k] = gdjs.RoomsCode.GDE_9595buttonObjects3[i];
        ++k;
    }
}
gdjs.RoomsCode.GDE_9595buttonObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDE_9595buttonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDE_9595buttonObjects2_1final.indexOf(gdjs.RoomsCode.GDE_9595buttonObjects3[j]) === -1 )
            gdjs.RoomsCode.GDE_9595buttonObjects2_1final.push(gdjs.RoomsCode.GDE_9595buttonObjects3[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDE_9595buttonObjects2_1final, gdjs.RoomsCode.GDE_9595buttonObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5).getChild("state")) == 2;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(5).getChild("task"), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(5).getChild("misionstate"), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects2Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects2Objects, 80, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDcharectersObjects2.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDcharectersObjects2[i].getBehavior("Animation").getAnimationName() == "librarian" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDcharectersObjects2[k] = gdjs.RoomsCode.GDcharectersObjects2[i];
        ++k;
    }
}
gdjs.RoomsCode.GDcharectersObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "conversation"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause"));
}
}
}
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Name"), gdjs.RoomsCode.GDNameObjects2);
gdjs.copyArray(runtimeScene.getObjects("charecters2"), gdjs.RoomsCode.GDcharecters2Objects2);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollspeed");
}{for(var i = 0, len = gdjs.RoomsCode.GDcharecters2Objects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDcharecters2Objects2[i].getBehavior("Animation").setAnimationName("librarian");
}
}{gdjs.dialogueTree.startFrom("librarian-5");
}{runtimeScene.getGame().getVariables().getFromIndex(5).getChild("state").setNumber(1);
}{for(var i = 0, len = gdjs.RoomsCode.GDNameObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDNameObjects2[i].getBehavior("Text").setText("Meha");
}
}}

}


};gdjs.RoomsCode.eventsList20 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("charecters"), gdjs.RoomsCode.GDcharectersObjects3);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects3);
gdjs.RoomsCode.GDE_9595buttonObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDE_9595buttonObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects4);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDE_9595buttonObjects4.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDE_9595buttonObjects4[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDE_9595buttonObjects4[k] = gdjs.RoomsCode.GDE_9595buttonObjects4[i];
        ++k;
    }
}
gdjs.RoomsCode.GDE_9595buttonObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDE_9595buttonObjects4.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDE_9595buttonObjects3_1final.indexOf(gdjs.RoomsCode.GDE_9595buttonObjects4[j]) === -1 )
            gdjs.RoomsCode.GDE_9595buttonObjects3_1final.push(gdjs.RoomsCode.GDE_9595buttonObjects4[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDE_9595buttonObjects3_1final, gdjs.RoomsCode.GDE_9595buttonObjects3);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5).getChild("state")) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects, 80, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDcharectersObjects3.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDcharectersObjects3[i].getBehavior("Animation").getAnimationName() == "librarian" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDcharectersObjects3[k] = gdjs.RoomsCode.GDcharectersObjects3[i];
        ++k;
    }
}
gdjs.RoomsCode.GDcharectersObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "conversation"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause"));
}
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Name"), gdjs.RoomsCode.GDNameObjects3);
gdjs.copyArray(runtimeScene.getObjects("arrow"), gdjs.RoomsCode.GDarrowObjects3);
gdjs.copyArray(runtimeScene.getObjects("charecters2"), gdjs.RoomsCode.GDcharecters2Objects3);
gdjs.copyArray(runtimeScene.getObjects("options"), gdjs.RoomsCode.GDoptionsObjects3);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollspeed");
}{gdjs.dialogueTree.startFrom("librarian-1");
}{for(var i = 0, len = gdjs.RoomsCode.GDcharecters2Objects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDcharecters2Objects3[i].getBehavior("Animation").setAnimationName("librarian");
}
}{runtimeScene.getGame().getVariables().getFromIndex(5).getChild("state").setNumber(1);
}{for(var i = 0, len = gdjs.RoomsCode.GDNameObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDNameObjects3[i].getBehavior("Text").setText("Meha");
}
}{for(var i = 0, len = gdjs.RoomsCode.GDoptionsObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDoptionsObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.RoomsCode.GDarrowObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDarrowObjects3[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("charecters"), gdjs.RoomsCode.GDcharectersObjects3);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects3);
gdjs.RoomsCode.GDE_9595buttonObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDE_9595buttonObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects4);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDE_9595buttonObjects4.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDE_9595buttonObjects4[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDE_9595buttonObjects4[k] = gdjs.RoomsCode.GDE_9595buttonObjects4[i];
        ++k;
    }
}
gdjs.RoomsCode.GDE_9595buttonObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDE_9595buttonObjects4.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDE_9595buttonObjects3_1final.indexOf(gdjs.RoomsCode.GDE_9595buttonObjects4[j]) === -1 )
            gdjs.RoomsCode.GDE_9595buttonObjects3_1final.push(gdjs.RoomsCode.GDE_9595buttonObjects4[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDE_9595buttonObjects3_1final, gdjs.RoomsCode.GDE_9595buttonObjects3);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5).getChild("state")) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(5).getChild("task"), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(11).getChild("mision"), true, false));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects, 80, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDcharectersObjects3.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDcharectersObjects3[i].getBehavior("Animation").getAnimationName() == "librarian" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDcharectersObjects3[k] = gdjs.RoomsCode.GDcharectersObjects3[i];
        ++k;
    }
}
gdjs.RoomsCode.GDcharectersObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "conversation"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause"));
}
}
}
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Name"), gdjs.RoomsCode.GDNameObjects3);
gdjs.copyArray(runtimeScene.getObjects("charecters2"), gdjs.RoomsCode.GDcharecters2Objects3);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollspeed");
}{for(var i = 0, len = gdjs.RoomsCode.GDcharecters2Objects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDcharecters2Objects3[i].getBehavior("Animation").setAnimationName("librarian");
}
}{gdjs.dialogueTree.startFrom("librarian-2");
}{for(var i = 0, len = gdjs.RoomsCode.GDNameObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDNameObjects3[i].getBehavior("Text").setText("Meha");
}
}}

}


{


gdjs.RoomsCode.eventsList19(runtimeScene);
}


};gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects2});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects2Objects = Hashtable.newFrom({"charecters": gdjs.RoomsCode.GDcharectersObjects2});
gdjs.RoomsCode.eventsList21 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("charecters"), gdjs.RoomsCode.GDcharectersObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects2);
gdjs.RoomsCode.GDE_9595buttonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDE_9595buttonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects3);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDE_9595buttonObjects3.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDE_9595buttonObjects3[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDE_9595buttonObjects3[k] = gdjs.RoomsCode.GDE_9595buttonObjects3[i];
        ++k;
    }
}
gdjs.RoomsCode.GDE_9595buttonObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDE_9595buttonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDE_9595buttonObjects2_1final.indexOf(gdjs.RoomsCode.GDE_9595buttonObjects3[j]) === -1 )
            gdjs.RoomsCode.GDE_9595buttonObjects2_1final.push(gdjs.RoomsCode.GDE_9595buttonObjects3[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDE_9595buttonObjects2_1final, gdjs.RoomsCode.GDE_9595buttonObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7).getChild("state")) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects2Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects2Objects, 80, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDcharectersObjects2.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDcharectersObjects2[i].getBehavior("Animation").getAnimationName() == "computer-bot" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDcharectersObjects2[k] = gdjs.RoomsCode.GDcharectersObjects2[i];
        ++k;
    }
}
gdjs.RoomsCode.GDcharectersObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "conversation"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause"));
}
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Name"), gdjs.RoomsCode.GDNameObjects2);
gdjs.copyArray(runtimeScene.getObjects("arrow"), gdjs.RoomsCode.GDarrowObjects2);
gdjs.copyArray(runtimeScene.getObjects("charecters2"), gdjs.RoomsCode.GDcharecters2Objects2);
gdjs.copyArray(runtimeScene.getObjects("options"), gdjs.RoomsCode.GDoptionsObjects2);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollspeed");
}{gdjs.dialogueTree.startFrom("computer-bot");
}{for(var i = 0, len = gdjs.RoomsCode.GDcharecters2Objects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDcharecters2Objects2[i].getBehavior("Animation").setAnimationName("computer-bot");
}
}{for(var i = 0, len = gdjs.RoomsCode.GDNameObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDNameObjects2[i].getBehavior("Text").setText("Addicts");
}
}{for(var i = 0, len = gdjs.RoomsCode.GDoptionsObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDoptionsObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.RoomsCode.GDarrowObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDarrowObjects2[i].hide();
}
}}

}


};gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects = Hashtable.newFrom({"charecters": gdjs.RoomsCode.GDcharectersObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects = Hashtable.newFrom({"charecters": gdjs.RoomsCode.GDcharectersObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects = Hashtable.newFrom({"charecters": gdjs.RoomsCode.GDcharectersObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects = Hashtable.newFrom({"charecters": gdjs.RoomsCode.GDcharectersObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects = Hashtable.newFrom({"charecters": gdjs.RoomsCode.GDcharectersObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects2});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects2Objects = Hashtable.newFrom({"charecters": gdjs.RoomsCode.GDcharectersObjects2});
gdjs.RoomsCode.eventsList22 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("charecters"), gdjs.RoomsCode.GDcharectersObjects3);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects3);
gdjs.RoomsCode.GDE_9595buttonObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDE_9595buttonObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects4);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDE_9595buttonObjects4.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDE_9595buttonObjects4[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDE_9595buttonObjects4[k] = gdjs.RoomsCode.GDE_9595buttonObjects4[i];
        ++k;
    }
}
gdjs.RoomsCode.GDE_9595buttonObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDE_9595buttonObjects4.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDE_9595buttonObjects3_1final.indexOf(gdjs.RoomsCode.GDE_9595buttonObjects4[j]) === -1 )
            gdjs.RoomsCode.GDE_9595buttonObjects3_1final.push(gdjs.RoomsCode.GDE_9595buttonObjects4[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDE_9595buttonObjects3_1final, gdjs.RoomsCode.GDE_9595buttonObjects3);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(6).getChild("task"), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(6).getChild("misionstate"), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6).getChild("state")) == 2;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects, 80, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDcharectersObjects3.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDcharectersObjects3[i].getBehavior("Animation").getAnimationName() == "computer-guy" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDcharectersObjects3[k] = gdjs.RoomsCode.GDcharectersObjects3[i];
        ++k;
    }
}
gdjs.RoomsCode.GDcharectersObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "conversation"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause"));
}
}
}
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Name"), gdjs.RoomsCode.GDNameObjects3);
gdjs.copyArray(runtimeScene.getObjects("charecters2"), gdjs.RoomsCode.GDcharecters2Objects3);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollspeed");
}{for(var i = 0, len = gdjs.RoomsCode.GDcharecters2Objects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDcharecters2Objects3[i].getBehavior("Animation").setAnimationName("computer-guy");
}
}{gdjs.dialogueTree.startFrom("computer-guy-4");
}{for(var i = 0, len = gdjs.RoomsCode.GDNameObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDNameObjects3[i].getBehavior("Text").setText("Toqo");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("charecters"), gdjs.RoomsCode.GDcharectersObjects3);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects3);
gdjs.RoomsCode.GDE_9595buttonObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDE_9595buttonObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects4);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDE_9595buttonObjects4.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDE_9595buttonObjects4[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDE_9595buttonObjects4[k] = gdjs.RoomsCode.GDE_9595buttonObjects4[i];
        ++k;
    }
}
gdjs.RoomsCode.GDE_9595buttonObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDE_9595buttonObjects4.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDE_9595buttonObjects3_1final.indexOf(gdjs.RoomsCode.GDE_9595buttonObjects4[j]) === -1 )
            gdjs.RoomsCode.GDE_9595buttonObjects3_1final.push(gdjs.RoomsCode.GDE_9595buttonObjects4[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDE_9595buttonObjects3_1final, gdjs.RoomsCode.GDE_9595buttonObjects3);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6).getChild("state")) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(6).getChild("task"), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(11).getChild("mision"), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects, 80, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDcharectersObjects3.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDcharectersObjects3[i].getBehavior("Animation").getAnimationName() == "computer-guy" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDcharectersObjects3[k] = gdjs.RoomsCode.GDcharectersObjects3[i];
        ++k;
    }
}
gdjs.RoomsCode.GDcharectersObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "conversation"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause"));
}
}
}
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Name"), gdjs.RoomsCode.GDNameObjects3);
gdjs.copyArray(runtimeScene.getObjects("charecters2"), gdjs.RoomsCode.GDcharecters2Objects3);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollspeed");
}{for(var i = 0, len = gdjs.RoomsCode.GDcharecters2Objects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDcharecters2Objects3[i].getBehavior("Animation").setAnimationName("computer-guy");
}
}{gdjs.dialogueTree.startFrom("computer-guy-3");
}{runtimeScene.getGame().getVariables().getFromIndex(6).getChild("state").setNumber(2);
}{runtimeScene.getGame().getVariables().getFromIndex(6).getChild("task").setBoolean(true);
}{for(var i = 0, len = gdjs.RoomsCode.GDNameObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDNameObjects3[i].getBehavior("Text").setText("Toqo");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("charecters"), gdjs.RoomsCode.GDcharectersObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects2);
gdjs.RoomsCode.GDE_9595buttonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDE_9595buttonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects3);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDE_9595buttonObjects3.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDE_9595buttonObjects3[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDE_9595buttonObjects3[k] = gdjs.RoomsCode.GDE_9595buttonObjects3[i];
        ++k;
    }
}
gdjs.RoomsCode.GDE_9595buttonObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDE_9595buttonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDE_9595buttonObjects2_1final.indexOf(gdjs.RoomsCode.GDE_9595buttonObjects3[j]) === -1 )
            gdjs.RoomsCode.GDE_9595buttonObjects2_1final.push(gdjs.RoomsCode.GDE_9595buttonObjects3[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDE_9595buttonObjects2_1final, gdjs.RoomsCode.GDE_9595buttonObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6).getChild("state")) == 2;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(6).getChild("task"), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(6).getChild("misionstate"), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects2Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects2Objects, 80, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDcharectersObjects2.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDcharectersObjects2[i].getBehavior("Animation").getAnimationName() == "computer-guy" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDcharectersObjects2[k] = gdjs.RoomsCode.GDcharectersObjects2[i];
        ++k;
    }
}
gdjs.RoomsCode.GDcharectersObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "conversation"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause"));
}
}
}
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Name"), gdjs.RoomsCode.GDNameObjects2);
gdjs.copyArray(runtimeScene.getObjects("charecters2"), gdjs.RoomsCode.GDcharecters2Objects2);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollspeed");
}{for(var i = 0, len = gdjs.RoomsCode.GDcharecters2Objects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDcharecters2Objects2[i].getBehavior("Animation").setAnimationName("computer-guy");
}
}{gdjs.dialogueTree.startFrom("computer-guy-5");
}{runtimeScene.getGame().getVariables().getFromIndex(6).getChild("state").setNumber(1);
}{for(var i = 0, len = gdjs.RoomsCode.GDNameObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDNameObjects2[i].getBehavior("Text").setText("Toqo");
}
}{runtimeScene.getGame().getVariables().getFromIndex(11).getChild("collect").add(1);
}}

}


};gdjs.RoomsCode.eventsList23 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("charecters"), gdjs.RoomsCode.GDcharectersObjects3);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects3);
gdjs.RoomsCode.GDE_9595buttonObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDE_9595buttonObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects4);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDE_9595buttonObjects4.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDE_9595buttonObjects4[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDE_9595buttonObjects4[k] = gdjs.RoomsCode.GDE_9595buttonObjects4[i];
        ++k;
    }
}
gdjs.RoomsCode.GDE_9595buttonObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDE_9595buttonObjects4.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDE_9595buttonObjects3_1final.indexOf(gdjs.RoomsCode.GDE_9595buttonObjects4[j]) === -1 )
            gdjs.RoomsCode.GDE_9595buttonObjects3_1final.push(gdjs.RoomsCode.GDE_9595buttonObjects4[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDE_9595buttonObjects3_1final, gdjs.RoomsCode.GDE_9595buttonObjects3);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6).getChild("state")) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects, 80, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDcharectersObjects3.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDcharectersObjects3[i].getBehavior("Animation").getAnimationName() == "computer-guy" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDcharectersObjects3[k] = gdjs.RoomsCode.GDcharectersObjects3[i];
        ++k;
    }
}
gdjs.RoomsCode.GDcharectersObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "conversation"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause"));
}
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Name"), gdjs.RoomsCode.GDNameObjects3);
gdjs.copyArray(runtimeScene.getObjects("arrow"), gdjs.RoomsCode.GDarrowObjects3);
gdjs.copyArray(runtimeScene.getObjects("charecters2"), gdjs.RoomsCode.GDcharecters2Objects3);
gdjs.copyArray(runtimeScene.getObjects("options"), gdjs.RoomsCode.GDoptionsObjects3);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollspeed");
}{gdjs.dialogueTree.startFrom("computer-guy-1");
}{for(var i = 0, len = gdjs.RoomsCode.GDcharecters2Objects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDcharecters2Objects3[i].getBehavior("Animation").setAnimationName("computer-guy");
}
}{runtimeScene.getGame().getVariables().getFromIndex(6).getChild("state").setNumber(1);
}{for(var i = 0, len = gdjs.RoomsCode.GDNameObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDNameObjects3[i].getBehavior("Text").setText("Toqo");
}
}{for(var i = 0, len = gdjs.RoomsCode.GDoptionsObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDoptionsObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.RoomsCode.GDarrowObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDarrowObjects3[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("charecters"), gdjs.RoomsCode.GDcharectersObjects3);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects3);
gdjs.RoomsCode.GDE_9595buttonObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDE_9595buttonObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects4);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDE_9595buttonObjects4.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDE_9595buttonObjects4[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDE_9595buttonObjects4[k] = gdjs.RoomsCode.GDE_9595buttonObjects4[i];
        ++k;
    }
}
gdjs.RoomsCode.GDE_9595buttonObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDE_9595buttonObjects4.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDE_9595buttonObjects3_1final.indexOf(gdjs.RoomsCode.GDE_9595buttonObjects4[j]) === -1 )
            gdjs.RoomsCode.GDE_9595buttonObjects3_1final.push(gdjs.RoomsCode.GDE_9595buttonObjects4[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDE_9595buttonObjects3_1final, gdjs.RoomsCode.GDE_9595buttonObjects3);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6).getChild("state")) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(6).getChild("task"), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(11).getChild("mision"), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects, 80, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDcharectersObjects3.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDcharectersObjects3[i].getBehavior("Animation").getAnimationName() == "computer-guy" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDcharectersObjects3[k] = gdjs.RoomsCode.GDcharectersObjects3[i];
        ++k;
    }
}
gdjs.RoomsCode.GDcharectersObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "conversation"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause"));
}
}
}
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Name"), gdjs.RoomsCode.GDNameObjects3);
gdjs.copyArray(runtimeScene.getObjects("charecters2"), gdjs.RoomsCode.GDcharecters2Objects3);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollspeed");
}{for(var i = 0, len = gdjs.RoomsCode.GDcharecters2Objects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDcharecters2Objects3[i].getBehavior("Animation").setAnimationName("computer-guy");
}
}{gdjs.dialogueTree.startFrom("computer-guy-2");
}{for(var i = 0, len = gdjs.RoomsCode.GDNameObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDNameObjects3[i].getBehavior("Text").setText("Toqo");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("charecters"), gdjs.RoomsCode.GDcharectersObjects3);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects3);
gdjs.RoomsCode.GDE_9595buttonObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDE_9595buttonObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects4);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDE_9595buttonObjects4.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDE_9595buttonObjects4[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDE_9595buttonObjects4[k] = gdjs.RoomsCode.GDE_9595buttonObjects4[i];
        ++k;
    }
}
gdjs.RoomsCode.GDE_9595buttonObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDE_9595buttonObjects4.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDE_9595buttonObjects3_1final.indexOf(gdjs.RoomsCode.GDE_9595buttonObjects4[j]) === -1 )
            gdjs.RoomsCode.GDE_9595buttonObjects3_1final.push(gdjs.RoomsCode.GDE_9595buttonObjects4[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDE_9595buttonObjects3_1final, gdjs.RoomsCode.GDE_9595buttonObjects3);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6).getChild("state")) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(6).getChild("task"), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(11).getChild("mision"), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects, 80, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDcharectersObjects3.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDcharectersObjects3[i].getBehavior("Animation").getAnimationName() == "computer-guy" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDcharectersObjects3[k] = gdjs.RoomsCode.GDcharectersObjects3[i];
        ++k;
    }
}
gdjs.RoomsCode.GDcharectersObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "conversation"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause"));
}
}
}
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Name"), gdjs.RoomsCode.GDNameObjects3);
gdjs.copyArray(runtimeScene.getObjects("charecters2"), gdjs.RoomsCode.GDcharecters2Objects3);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollspeed");
}{for(var i = 0, len = gdjs.RoomsCode.GDcharecters2Objects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDcharecters2Objects3[i].getBehavior("Animation").setAnimationName("computer-guy");
}
}{gdjs.dialogueTree.startFrom("computer-guy-2");
}{for(var i = 0, len = gdjs.RoomsCode.GDNameObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDNameObjects3[i].getBehavior("Text").setText("Toqo");
}
}}

}


{


gdjs.RoomsCode.eventsList22(runtimeScene);
}


};gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects = Hashtable.newFrom({"charecters": gdjs.RoomsCode.GDcharectersObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects2});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects2Objects = Hashtable.newFrom({"charecters": gdjs.RoomsCode.GDcharectersObjects2});
gdjs.RoomsCode.eventsList24 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("charecters"), gdjs.RoomsCode.GDcharectersObjects3);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects3);
gdjs.RoomsCode.GDE_9595buttonObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDE_9595buttonObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects4);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDE_9595buttonObjects4.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDE_9595buttonObjects4[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDE_9595buttonObjects4[k] = gdjs.RoomsCode.GDE_9595buttonObjects4[i];
        ++k;
    }
}
gdjs.RoomsCode.GDE_9595buttonObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDE_9595buttonObjects4.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDE_9595buttonObjects3_1final.indexOf(gdjs.RoomsCode.GDE_9595buttonObjects4[j]) === -1 )
            gdjs.RoomsCode.GDE_9595buttonObjects3_1final.push(gdjs.RoomsCode.GDE_9595buttonObjects4[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDE_9595buttonObjects3_1final, gdjs.RoomsCode.GDE_9595buttonObjects3);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(8).getChild("state")) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects, 80, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDcharectersObjects3.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDcharectersObjects3[i].getBehavior("Animation").getAnimationName() == "trainer" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDcharectersObjects3[k] = gdjs.RoomsCode.GDcharectersObjects3[i];
        ++k;
    }
}
gdjs.RoomsCode.GDcharectersObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "conversation"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause"));
}
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Name"), gdjs.RoomsCode.GDNameObjects3);
gdjs.copyArray(runtimeScene.getObjects("arrow"), gdjs.RoomsCode.GDarrowObjects3);
gdjs.copyArray(runtimeScene.getObjects("charecters2"), gdjs.RoomsCode.GDcharecters2Objects3);
gdjs.copyArray(runtimeScene.getObjects("options"), gdjs.RoomsCode.GDoptionsObjects3);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollspeed");
}{gdjs.dialogueTree.startFrom("trainer-1");
}{for(var i = 0, len = gdjs.RoomsCode.GDcharecters2Objects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDcharecters2Objects3[i].getBehavior("Animation").setAnimationName("trainer");
}
}{runtimeScene.getGame().getVariables().getFromIndex(8).getChild("state").setNumber(1);
}{for(var i = 0, len = gdjs.RoomsCode.GDNameObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDNameObjects3[i].getBehavior("Text").setText("Yami");
}
}{for(var i = 0, len = gdjs.RoomsCode.GDoptionsObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDoptionsObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.RoomsCode.GDarrowObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDarrowObjects3[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("charecters"), gdjs.RoomsCode.GDcharectersObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects2);
gdjs.RoomsCode.GDE_9595buttonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDE_9595buttonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects3);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDE_9595buttonObjects3.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDE_9595buttonObjects3[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDE_9595buttonObjects3[k] = gdjs.RoomsCode.GDE_9595buttonObjects3[i];
        ++k;
    }
}
gdjs.RoomsCode.GDE_9595buttonObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDE_9595buttonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDE_9595buttonObjects2_1final.indexOf(gdjs.RoomsCode.GDE_9595buttonObjects3[j]) === -1 )
            gdjs.RoomsCode.GDE_9595buttonObjects2_1final.push(gdjs.RoomsCode.GDE_9595buttonObjects3[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDE_9595buttonObjects2_1final, gdjs.RoomsCode.GDE_9595buttonObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(8).getChild("state")) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(12).getChild("task"), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects2Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects2Objects, 80, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDcharectersObjects2.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDcharectersObjects2[i].getBehavior("Animation").getAnimationName() == "trainer" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDcharectersObjects2[k] = gdjs.RoomsCode.GDcharectersObjects2[i];
        ++k;
    }
}
gdjs.RoomsCode.GDcharectersObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "conversation"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause"));
}
}
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Name"), gdjs.RoomsCode.GDNameObjects2);
gdjs.copyArray(runtimeScene.getObjects("charecters2"), gdjs.RoomsCode.GDcharecters2Objects2);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollspeed");
}{for(var i = 0, len = gdjs.RoomsCode.GDcharecters2Objects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDcharecters2Objects2[i].getBehavior("Animation").setAnimationName("trainer");
}
}{gdjs.dialogueTree.startFrom("trainer-2");
}{for(var i = 0, len = gdjs.RoomsCode.GDNameObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDNameObjects2[i].getBehavior("Text").setText("Yami");
}
}}

}


};gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects = Hashtable.newFrom({"charecters": gdjs.RoomsCode.GDcharectersObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects = Hashtable.newFrom({"charecters": gdjs.RoomsCode.GDcharectersObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects = Hashtable.newFrom({"charecters": gdjs.RoomsCode.GDcharectersObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects2});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects2Objects = Hashtable.newFrom({"charecters": gdjs.RoomsCode.GDcharectersObjects2});
gdjs.RoomsCode.eventsList25 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("charecters"), gdjs.RoomsCode.GDcharectersObjects3);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects3);
gdjs.RoomsCode.GDE_9595buttonObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDE_9595buttonObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects4);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDE_9595buttonObjects4.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDE_9595buttonObjects4[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDE_9595buttonObjects4[k] = gdjs.RoomsCode.GDE_9595buttonObjects4[i];
        ++k;
    }
}
gdjs.RoomsCode.GDE_9595buttonObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDE_9595buttonObjects4.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDE_9595buttonObjects3_1final.indexOf(gdjs.RoomsCode.GDE_9595buttonObjects4[j]) === -1 )
            gdjs.RoomsCode.GDE_9595buttonObjects3_1final.push(gdjs.RoomsCode.GDE_9595buttonObjects4[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDE_9595buttonObjects3_1final, gdjs.RoomsCode.GDE_9595buttonObjects3);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(9).getChild("state")) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(9).getChild("task"), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(11).getChild("mision"), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(4), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects, 80, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDcharectersObjects3.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDcharectersObjects3[i].getBehavior("Animation").getAnimationName() == "scrap-collecter" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDcharectersObjects3[k] = gdjs.RoomsCode.GDcharectersObjects3[i];
        ++k;
    }
}
gdjs.RoomsCode.GDcharectersObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "conversation"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause"));
}
}
}
}
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Name"), gdjs.RoomsCode.GDNameObjects3);
gdjs.copyArray(runtimeScene.getObjects("charecters2"), gdjs.RoomsCode.GDcharecters2Objects3);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollspeed");
}{for(var i = 0, len = gdjs.RoomsCode.GDcharecters2Objects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDcharecters2Objects3[i].getBehavior("Animation").setAnimationName("scrap-collecter");
}
}{gdjs.dialogueTree.startFrom("scrap_collector-3");
}{runtimeScene.getGame().getVariables().getFromIndex(9).getChild("task").setBoolean(true);
}{for(var i = 0, len = gdjs.RoomsCode.GDNameObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDNameObjects3[i].getBehavior("Text").setText("wuhe");
}
}{runtimeScene.getScene().getVariables().getFromIndex(4).setBoolean(true);
}{runtimeScene.getGame().getVariables().getFromIndex(9).getChild("state").setNumber(2);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("charecters"), gdjs.RoomsCode.GDcharectersObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects2);
gdjs.RoomsCode.GDE_9595buttonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDE_9595buttonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects3);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDE_9595buttonObjects3.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDE_9595buttonObjects3[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDE_9595buttonObjects3[k] = gdjs.RoomsCode.GDE_9595buttonObjects3[i];
        ++k;
    }
}
gdjs.RoomsCode.GDE_9595buttonObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDE_9595buttonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDE_9595buttonObjects2_1final.indexOf(gdjs.RoomsCode.GDE_9595buttonObjects3[j]) === -1 )
            gdjs.RoomsCode.GDE_9595buttonObjects2_1final.push(gdjs.RoomsCode.GDE_9595buttonObjects3[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDE_9595buttonObjects2_1final, gdjs.RoomsCode.GDE_9595buttonObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(9).getChild("state")) == 2;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(9).getChild("task"), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(9).getChild("misionstate"), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(4), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects2Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects2Objects, 80, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDcharectersObjects2.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDcharectersObjects2[i].getBehavior("Animation").getAnimationName() == "scrap-collecter" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDcharectersObjects2[k] = gdjs.RoomsCode.GDcharectersObjects2[i];
        ++k;
    }
}
gdjs.RoomsCode.GDcharectersObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "conversation"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause"));
}
}
}
}
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Name"), gdjs.RoomsCode.GDNameObjects2);
gdjs.copyArray(runtimeScene.getObjects("charecters2"), gdjs.RoomsCode.GDcharecters2Objects2);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollspeed");
}{for(var i = 0, len = gdjs.RoomsCode.GDcharecters2Objects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDcharecters2Objects2[i].getBehavior("Animation").setAnimationName("scrap-collecter");
}
}{gdjs.dialogueTree.startFrom("scrap_collector-5");
}{runtimeScene.getGame().getVariables().getFromIndex(9).getChild("state").setNumber(1);
}{for(var i = 0, len = gdjs.RoomsCode.GDNameObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDNameObjects2[i].getBehavior("Text").setText("Wuhe");
}
}{runtimeScene.getGame().getVariables().getFromIndex(11).getChild("collect").add(1);
}}

}


};gdjs.RoomsCode.eventsList26 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("charecters"), gdjs.RoomsCode.GDcharectersObjects3);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects3);
gdjs.RoomsCode.GDE_9595buttonObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDE_9595buttonObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects4);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDE_9595buttonObjects4.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDE_9595buttonObjects4[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDE_9595buttonObjects4[k] = gdjs.RoomsCode.GDE_9595buttonObjects4[i];
        ++k;
    }
}
gdjs.RoomsCode.GDE_9595buttonObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDE_9595buttonObjects4.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDE_9595buttonObjects3_1final.indexOf(gdjs.RoomsCode.GDE_9595buttonObjects4[j]) === -1 )
            gdjs.RoomsCode.GDE_9595buttonObjects3_1final.push(gdjs.RoomsCode.GDE_9595buttonObjects4[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDE_9595buttonObjects3_1final, gdjs.RoomsCode.GDE_9595buttonObjects3);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(9).getChild("state")) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects, 80, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDcharectersObjects3.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDcharectersObjects3[i].getBehavior("Animation").getAnimationName() == "scrap-collecter" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDcharectersObjects3[k] = gdjs.RoomsCode.GDcharectersObjects3[i];
        ++k;
    }
}
gdjs.RoomsCode.GDcharectersObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "conversation"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause"));
}
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Name"), gdjs.RoomsCode.GDNameObjects3);
gdjs.copyArray(runtimeScene.getObjects("arrow"), gdjs.RoomsCode.GDarrowObjects3);
gdjs.copyArray(runtimeScene.getObjects("charecters2"), gdjs.RoomsCode.GDcharecters2Objects3);
gdjs.copyArray(runtimeScene.getObjects("options"), gdjs.RoomsCode.GDoptionsObjects3);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollspeed");
}{gdjs.dialogueTree.startFrom("scrap_collector-1");
}{for(var i = 0, len = gdjs.RoomsCode.GDcharecters2Objects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDcharecters2Objects3[i].getBehavior("Animation").setAnimationName("scrap-collecter");
}
}{runtimeScene.getGame().getVariables().getFromIndex(9).getChild("state").setNumber(1);
}{for(var i = 0, len = gdjs.RoomsCode.GDNameObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDNameObjects3[i].getBehavior("Text").setText("Wuhe");
}
}{for(var i = 0, len = gdjs.RoomsCode.GDoptionsObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDoptionsObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.RoomsCode.GDarrowObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDarrowObjects3[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("charecters"), gdjs.RoomsCode.GDcharectersObjects3);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects3);
gdjs.RoomsCode.GDE_9595buttonObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDE_9595buttonObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects4);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDE_9595buttonObjects4.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDE_9595buttonObjects4[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDE_9595buttonObjects4[k] = gdjs.RoomsCode.GDE_9595buttonObjects4[i];
        ++k;
    }
}
gdjs.RoomsCode.GDE_9595buttonObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDE_9595buttonObjects4.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDE_9595buttonObjects3_1final.indexOf(gdjs.RoomsCode.GDE_9595buttonObjects4[j]) === -1 )
            gdjs.RoomsCode.GDE_9595buttonObjects3_1final.push(gdjs.RoomsCode.GDE_9595buttonObjects4[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDE_9595buttonObjects3_1final, gdjs.RoomsCode.GDE_9595buttonObjects3);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(11).getChild("mision"), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(9).getChild("state")) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects, 80, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDcharectersObjects3.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDcharectersObjects3[i].getBehavior("Animation").getAnimationName() == "scrap-collecter" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDcharectersObjects3[k] = gdjs.RoomsCode.GDcharectersObjects3[i];
        ++k;
    }
}
gdjs.RoomsCode.GDcharectersObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "conversation"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause"));
}
}
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Name"), gdjs.RoomsCode.GDNameObjects3);
gdjs.copyArray(runtimeScene.getObjects("charecters2"), gdjs.RoomsCode.GDcharecters2Objects3);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollspeed");
}{for(var i = 0, len = gdjs.RoomsCode.GDcharecters2Objects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDcharecters2Objects3[i].getBehavior("Animation").setAnimationName("scrap-collecter");
}
}{gdjs.dialogueTree.startFrom("scrap_collector-2");
}{for(var i = 0, len = gdjs.RoomsCode.GDNameObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDNameObjects3[i].getBehavior("Text").setText("Wuhe");
}
}}

}


{


gdjs.RoomsCode.eventsList25(runtimeScene);
}


};gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects = Hashtable.newFrom({"charecters": gdjs.RoomsCode.GDcharectersObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects = Hashtable.newFrom({"charecters": gdjs.RoomsCode.GDcharectersObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects2});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects2Objects = Hashtable.newFrom({"charecters": gdjs.RoomsCode.GDcharectersObjects2});
gdjs.RoomsCode.eventsList27 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("charecters"), gdjs.RoomsCode.GDcharectersObjects3);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects3);
gdjs.RoomsCode.GDE_9595buttonObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDE_9595buttonObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects4);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDE_9595buttonObjects4.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDE_9595buttonObjects4[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDE_9595buttonObjects4[k] = gdjs.RoomsCode.GDE_9595buttonObjects4[i];
        ++k;
    }
}
gdjs.RoomsCode.GDE_9595buttonObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDE_9595buttonObjects4.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDE_9595buttonObjects3_1final.indexOf(gdjs.RoomsCode.GDE_9595buttonObjects4[j]) === -1 )
            gdjs.RoomsCode.GDE_9595buttonObjects3_1final.push(gdjs.RoomsCode.GDE_9595buttonObjects4[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDE_9595buttonObjects3_1final, gdjs.RoomsCode.GDE_9595buttonObjects3);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(11).getChild("state")) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects, 80, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDcharectersObjects3.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDcharectersObjects3[i].getBehavior("Animation").getAnimationName() == "scientist" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDcharectersObjects3[k] = gdjs.RoomsCode.GDcharectersObjects3[i];
        ++k;
    }
}
gdjs.RoomsCode.GDcharectersObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "conversation"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause"));
}
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Name"), gdjs.RoomsCode.GDNameObjects3);
gdjs.copyArray(runtimeScene.getObjects("arrow"), gdjs.RoomsCode.GDarrowObjects3);
gdjs.copyArray(runtimeScene.getObjects("charecters2"), gdjs.RoomsCode.GDcharecters2Objects3);
gdjs.copyArray(runtimeScene.getObjects("options"), gdjs.RoomsCode.GDoptionsObjects3);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollspeed");
}{gdjs.dialogueTree.startFrom("scientist-1");
}{for(var i = 0, len = gdjs.RoomsCode.GDcharecters2Objects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDcharecters2Objects3[i].getBehavior("Animation").setAnimationName("scientist");
}
}{runtimeScene.getGame().getVariables().getFromIndex(11).getChild("state").setNumber(1);
}{runtimeScene.getGame().getVariables().getFromIndex(11).getChild("mision").setBoolean(true);
}{for(var i = 0, len = gdjs.RoomsCode.GDNameObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDNameObjects3[i].getBehavior("Text").setText("Lito");
}
}{for(var i = 0, len = gdjs.RoomsCode.GDoptionsObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDoptionsObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.RoomsCode.GDarrowObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDarrowObjects3[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("charecters"), gdjs.RoomsCode.GDcharectersObjects3);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects3);
gdjs.RoomsCode.GDE_9595buttonObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDE_9595buttonObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects4);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDE_9595buttonObjects4.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDE_9595buttonObjects4[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDE_9595buttonObjects4[k] = gdjs.RoomsCode.GDE_9595buttonObjects4[i];
        ++k;
    }
}
gdjs.RoomsCode.GDE_9595buttonObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDE_9595buttonObjects4.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDE_9595buttonObjects3_1final.indexOf(gdjs.RoomsCode.GDE_9595buttonObjects4[j]) === -1 )
            gdjs.RoomsCode.GDE_9595buttonObjects3_1final.push(gdjs.RoomsCode.GDE_9595buttonObjects4[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDE_9595buttonObjects3_1final, gdjs.RoomsCode.GDE_9595buttonObjects3);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(11).getChild("state")) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(11).getChild("collect")) >= 5);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects, 80, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDcharectersObjects3.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDcharectersObjects3[i].getBehavior("Animation").getAnimationName() == "scientist" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDcharectersObjects3[k] = gdjs.RoomsCode.GDcharectersObjects3[i];
        ++k;
    }
}
gdjs.RoomsCode.GDcharectersObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "conversation"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause"));
}
}
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Name"), gdjs.RoomsCode.GDNameObjects3);
gdjs.copyArray(runtimeScene.getObjects("charecters2"), gdjs.RoomsCode.GDcharecters2Objects3);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollspeed");
}{for(var i = 0, len = gdjs.RoomsCode.GDcharecters2Objects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDcharecters2Objects3[i].getBehavior("Animation").setAnimationName("scientist");
}
}{gdjs.dialogueTree.startFrom("scientist-2");
}{for(var i = 0, len = gdjs.RoomsCode.GDNameObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDNameObjects3[i].getBehavior("Text").setText("Lito");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("charecters"), gdjs.RoomsCode.GDcharectersObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects2);
gdjs.RoomsCode.GDE_9595buttonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDE_9595buttonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects3);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDE_9595buttonObjects3.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDE_9595buttonObjects3[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDE_9595buttonObjects3[k] = gdjs.RoomsCode.GDE_9595buttonObjects3[i];
        ++k;
    }
}
gdjs.RoomsCode.GDE_9595buttonObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDE_9595buttonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDE_9595buttonObjects2_1final.indexOf(gdjs.RoomsCode.GDE_9595buttonObjects3[j]) === -1 )
            gdjs.RoomsCode.GDE_9595buttonObjects2_1final.push(gdjs.RoomsCode.GDE_9595buttonObjects3[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDE_9595buttonObjects2_1final, gdjs.RoomsCode.GDE_9595buttonObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(11).getChild("state")) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(11).getChild("collect")) >= 5;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects2Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects2Objects, 80, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDcharectersObjects2.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDcharectersObjects2[i].getBehavior("Animation").getAnimationName() == "scientist" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDcharectersObjects2[k] = gdjs.RoomsCode.GDcharectersObjects2[i];
        ++k;
    }
}
gdjs.RoomsCode.GDcharectersObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "conversation"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause"));
}
}
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Name"), gdjs.RoomsCode.GDNameObjects2);
gdjs.copyArray(runtimeScene.getObjects("charecters2"), gdjs.RoomsCode.GDcharecters2Objects2);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollspeed");
}{for(var i = 0, len = gdjs.RoomsCode.GDcharecters2Objects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDcharecters2Objects2[i].getBehavior("Animation").setAnimationName("scientist");
}
}{gdjs.dialogueTree.startFrom("scientist-3");
}{for(var i = 0, len = gdjs.RoomsCode.GDNameObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDNameObjects2[i].getBehavior("Text").setText("Lito");
}
}{runtimeScene.getGame().getVariables().getFromIndex(18).setNumber(1);
}}

}


};gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects = Hashtable.newFrom({"charecters": gdjs.RoomsCode.GDcharectersObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects = Hashtable.newFrom({"charecters": gdjs.RoomsCode.GDcharectersObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects = Hashtable.newFrom({"charecters": gdjs.RoomsCode.GDcharectersObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects = Hashtable.newFrom({"charecters": gdjs.RoomsCode.GDcharectersObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects = Hashtable.newFrom({"charecters": gdjs.RoomsCode.GDcharectersObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects2});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects2Objects = Hashtable.newFrom({"charecters": gdjs.RoomsCode.GDcharectersObjects2});
gdjs.RoomsCode.eventsList28 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("charecters"), gdjs.RoomsCode.GDcharectersObjects3);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects3);
gdjs.RoomsCode.GDE_9595buttonObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDE_9595buttonObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects4);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDE_9595buttonObjects4.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDE_9595buttonObjects4[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDE_9595buttonObjects4[k] = gdjs.RoomsCode.GDE_9595buttonObjects4[i];
        ++k;
    }
}
gdjs.RoomsCode.GDE_9595buttonObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDE_9595buttonObjects4.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDE_9595buttonObjects3_1final.indexOf(gdjs.RoomsCode.GDE_9595buttonObjects4[j]) === -1 )
            gdjs.RoomsCode.GDE_9595buttonObjects3_1final.push(gdjs.RoomsCode.GDE_9595buttonObjects4[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDE_9595buttonObjects3_1final, gdjs.RoomsCode.GDE_9595buttonObjects3);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(12).getChild("task"), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(12).getChild("misionstate"), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(12).getChild("state")) == 2;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects, 80, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDcharectersObjects3.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDcharectersObjects3[i].getBehavior("Animation").getAnimationName() == "cooker" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDcharectersObjects3[k] = gdjs.RoomsCode.GDcharectersObjects3[i];
        ++k;
    }
}
gdjs.RoomsCode.GDcharectersObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "conversation"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause"));
}
}
}
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Name"), gdjs.RoomsCode.GDNameObjects3);
gdjs.copyArray(runtimeScene.getObjects("charecters2"), gdjs.RoomsCode.GDcharecters2Objects3);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollspeed");
}{for(var i = 0, len = gdjs.RoomsCode.GDcharecters2Objects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDcharecters2Objects3[i].getBehavior("Animation").setAnimationName("cooker");
}
}{gdjs.dialogueTree.startFrom("cooker-4");
}{for(var i = 0, len = gdjs.RoomsCode.GDNameObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDNameObjects3[i].getBehavior("Text").setText("Kasi");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("charecters"), gdjs.RoomsCode.GDcharectersObjects3);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects3);
gdjs.RoomsCode.GDE_9595buttonObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDE_9595buttonObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects4);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDE_9595buttonObjects4.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDE_9595buttonObjects4[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDE_9595buttonObjects4[k] = gdjs.RoomsCode.GDE_9595buttonObjects4[i];
        ++k;
    }
}
gdjs.RoomsCode.GDE_9595buttonObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDE_9595buttonObjects4.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDE_9595buttonObjects3_1final.indexOf(gdjs.RoomsCode.GDE_9595buttonObjects4[j]) === -1 )
            gdjs.RoomsCode.GDE_9595buttonObjects3_1final.push(gdjs.RoomsCode.GDE_9595buttonObjects4[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDE_9595buttonObjects3_1final, gdjs.RoomsCode.GDE_9595buttonObjects3);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(12).getChild("state")) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(12).getChild("task"), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(11).getChild("mision"), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects, 80, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDcharectersObjects3.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDcharectersObjects3[i].getBehavior("Animation").getAnimationName() == "cooker" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDcharectersObjects3[k] = gdjs.RoomsCode.GDcharectersObjects3[i];
        ++k;
    }
}
gdjs.RoomsCode.GDcharectersObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "conversation"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause"));
}
}
}
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Name"), gdjs.RoomsCode.GDNameObjects3);
gdjs.copyArray(runtimeScene.getObjects("charecters2"), gdjs.RoomsCode.GDcharecters2Objects3);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollspeed");
}{for(var i = 0, len = gdjs.RoomsCode.GDcharecters2Objects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDcharecters2Objects3[i].getBehavior("Animation").setAnimationName("cooker");
}
}{gdjs.dialogueTree.startFrom("cooker-3");
}{runtimeScene.getGame().getVariables().getFromIndex(12).getChild("state").setNumber(2);
}{runtimeScene.getGame().getVariables().getFromIndex(12).getChild("task").setBoolean(true);
}{for(var i = 0, len = gdjs.RoomsCode.GDNameObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDNameObjects3[i].getBehavior("Text").setText("Kasi");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("charecters"), gdjs.RoomsCode.GDcharectersObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects2);
gdjs.RoomsCode.GDE_9595buttonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDE_9595buttonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects3);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDE_9595buttonObjects3.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDE_9595buttonObjects3[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDE_9595buttonObjects3[k] = gdjs.RoomsCode.GDE_9595buttonObjects3[i];
        ++k;
    }
}
gdjs.RoomsCode.GDE_9595buttonObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDE_9595buttonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDE_9595buttonObjects2_1final.indexOf(gdjs.RoomsCode.GDE_9595buttonObjects3[j]) === -1 )
            gdjs.RoomsCode.GDE_9595buttonObjects2_1final.push(gdjs.RoomsCode.GDE_9595buttonObjects3[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDE_9595buttonObjects2_1final, gdjs.RoomsCode.GDE_9595buttonObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(12).getChild("state")) == 2;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(12).getChild("task"), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(12).getChild("misionstate"), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects2Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects2Objects, 80, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDcharectersObjects2.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDcharectersObjects2[i].getBehavior("Animation").getAnimationName() == "cooker" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDcharectersObjects2[k] = gdjs.RoomsCode.GDcharectersObjects2[i];
        ++k;
    }
}
gdjs.RoomsCode.GDcharectersObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "conversation"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause"));
}
}
}
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Name"), gdjs.RoomsCode.GDNameObjects2);
gdjs.copyArray(runtimeScene.getObjects("charecters2"), gdjs.RoomsCode.GDcharecters2Objects2);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollspeed");
}{for(var i = 0, len = gdjs.RoomsCode.GDcharecters2Objects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDcharecters2Objects2[i].getBehavior("Animation").setAnimationName("cooker");
}
}{gdjs.dialogueTree.startFrom("cooker-5");
}{runtimeScene.getGame().getVariables().getFromIndex(12).getChild("state").setNumber(1);
}{for(var i = 0, len = gdjs.RoomsCode.GDNameObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDNameObjects2[i].getBehavior("Text").setText("Kasi");
}
}{runtimeScene.getGame().getVariables().getFromIndex(11).getChild("collect").add(1);
}}

}


};gdjs.RoomsCode.eventsList29 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("charecters"), gdjs.RoomsCode.GDcharectersObjects3);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects3);
gdjs.RoomsCode.GDE_9595buttonObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDE_9595buttonObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects4);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDE_9595buttonObjects4.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDE_9595buttonObjects4[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDE_9595buttonObjects4[k] = gdjs.RoomsCode.GDE_9595buttonObjects4[i];
        ++k;
    }
}
gdjs.RoomsCode.GDE_9595buttonObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDE_9595buttonObjects4.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDE_9595buttonObjects3_1final.indexOf(gdjs.RoomsCode.GDE_9595buttonObjects4[j]) === -1 )
            gdjs.RoomsCode.GDE_9595buttonObjects3_1final.push(gdjs.RoomsCode.GDE_9595buttonObjects4[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDE_9595buttonObjects3_1final, gdjs.RoomsCode.GDE_9595buttonObjects3);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(12).getChild("state")) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects, 80, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDcharectersObjects3.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDcharectersObjects3[i].getBehavior("Animation").getAnimationName() == "cooker" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDcharectersObjects3[k] = gdjs.RoomsCode.GDcharectersObjects3[i];
        ++k;
    }
}
gdjs.RoomsCode.GDcharectersObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "conversation"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause"));
}
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Name"), gdjs.RoomsCode.GDNameObjects3);
gdjs.copyArray(runtimeScene.getObjects("arrow"), gdjs.RoomsCode.GDarrowObjects3);
gdjs.copyArray(runtimeScene.getObjects("charecters2"), gdjs.RoomsCode.GDcharecters2Objects3);
gdjs.copyArray(runtimeScene.getObjects("options"), gdjs.RoomsCode.GDoptionsObjects3);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollspeed");
}{gdjs.dialogueTree.startFrom("cooker-1");
}{for(var i = 0, len = gdjs.RoomsCode.GDcharecters2Objects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDcharecters2Objects3[i].getBehavior("Animation").setAnimationName("cooker");
}
}{runtimeScene.getGame().getVariables().getFromIndex(12).getChild("state").setNumber(1);
}{for(var i = 0, len = gdjs.RoomsCode.GDNameObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDNameObjects3[i].getBehavior("Text").setText("Kasi");
}
}{for(var i = 0, len = gdjs.RoomsCode.GDoptionsObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDoptionsObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.RoomsCode.GDarrowObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDarrowObjects3[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("charecters"), gdjs.RoomsCode.GDcharectersObjects3);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects3);
gdjs.RoomsCode.GDE_9595buttonObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDE_9595buttonObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects4);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDE_9595buttonObjects4.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDE_9595buttonObjects4[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDE_9595buttonObjects4[k] = gdjs.RoomsCode.GDE_9595buttonObjects4[i];
        ++k;
    }
}
gdjs.RoomsCode.GDE_9595buttonObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDE_9595buttonObjects4.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDE_9595buttonObjects3_1final.indexOf(gdjs.RoomsCode.GDE_9595buttonObjects4[j]) === -1 )
            gdjs.RoomsCode.GDE_9595buttonObjects3_1final.push(gdjs.RoomsCode.GDE_9595buttonObjects4[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDE_9595buttonObjects3_1final, gdjs.RoomsCode.GDE_9595buttonObjects3);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(12).getChild("state")) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(11).getChild("mision"), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects, 80, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDcharectersObjects3.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDcharectersObjects3[i].getBehavior("Animation").getAnimationName() == "cooker" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDcharectersObjects3[k] = gdjs.RoomsCode.GDcharectersObjects3[i];
        ++k;
    }
}
gdjs.RoomsCode.GDcharectersObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "conversation"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause"));
}
}
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Name"), gdjs.RoomsCode.GDNameObjects3);
gdjs.copyArray(runtimeScene.getObjects("charecters2"), gdjs.RoomsCode.GDcharecters2Objects3);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollspeed");
}{for(var i = 0, len = gdjs.RoomsCode.GDcharecters2Objects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDcharecters2Objects3[i].getBehavior("Animation").setAnimationName("cooker");
}
}{gdjs.dialogueTree.startFrom("cooker-2");
}{for(var i = 0, len = gdjs.RoomsCode.GDNameObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDNameObjects3[i].getBehavior("Text").setText("Kasi");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("charecters"), gdjs.RoomsCode.GDcharectersObjects3);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects3);
gdjs.RoomsCode.GDE_9595buttonObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDE_9595buttonObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects4);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDE_9595buttonObjects4.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDE_9595buttonObjects4[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDE_9595buttonObjects4[k] = gdjs.RoomsCode.GDE_9595buttonObjects4[i];
        ++k;
    }
}
gdjs.RoomsCode.GDE_9595buttonObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDE_9595buttonObjects4.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDE_9595buttonObjects3_1final.indexOf(gdjs.RoomsCode.GDE_9595buttonObjects4[j]) === -1 )
            gdjs.RoomsCode.GDE_9595buttonObjects3_1final.push(gdjs.RoomsCode.GDE_9595buttonObjects4[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDE_9595buttonObjects3_1final, gdjs.RoomsCode.GDE_9595buttonObjects3);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(12).getChild("task"), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(12).getChild("misionstate"), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(12).getChild("state")) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects, 80, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDcharectersObjects3.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDcharectersObjects3[i].getBehavior("Animation").getAnimationName() == "cooker" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDcharectersObjects3[k] = gdjs.RoomsCode.GDcharectersObjects3[i];
        ++k;
    }
}
gdjs.RoomsCode.GDcharectersObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "conversation"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause"));
}
}
}
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Name"), gdjs.RoomsCode.GDNameObjects3);
gdjs.copyArray(runtimeScene.getObjects("charecters2"), gdjs.RoomsCode.GDcharecters2Objects3);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollspeed");
}{for(var i = 0, len = gdjs.RoomsCode.GDcharecters2Objects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDcharecters2Objects3[i].getBehavior("Animation").setAnimationName("cooker");
}
}{gdjs.dialogueTree.startFrom("cooker-2");
}{for(var i = 0, len = gdjs.RoomsCode.GDNameObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDNameObjects3[i].getBehavior("Text").setText("Kasi");
}
}}

}


{


gdjs.RoomsCode.eventsList28(runtimeScene);
}


};gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects = Hashtable.newFrom({"charecters": gdjs.RoomsCode.GDcharectersObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects2});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects2Objects = Hashtable.newFrom({"charecters": gdjs.RoomsCode.GDcharectersObjects2});
gdjs.RoomsCode.eventsList30 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("charecters"), gdjs.RoomsCode.GDcharectersObjects3);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects3);
gdjs.RoomsCode.GDE_9595buttonObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDE_9595buttonObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects4);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDE_9595buttonObjects4.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDE_9595buttonObjects4[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDE_9595buttonObjects4[k] = gdjs.RoomsCode.GDE_9595buttonObjects4[i];
        ++k;
    }
}
gdjs.RoomsCode.GDE_9595buttonObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDE_9595buttonObjects4.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDE_9595buttonObjects3_1final.indexOf(gdjs.RoomsCode.GDE_9595buttonObjects4[j]) === -1 )
            gdjs.RoomsCode.GDE_9595buttonObjects3_1final.push(gdjs.RoomsCode.GDE_9595buttonObjects4[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDE_9595buttonObjects3_1final, gdjs.RoomsCode.GDE_9595buttonObjects3);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(13).getChild("state")) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects, 80, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDcharectersObjects3.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDcharectersObjects3[i].getVariableBoolean(gdjs.RoomsCode.GDcharectersObjects3[i].getVariables().getFromIndex(0), false, false) ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDcharectersObjects3[k] = gdjs.RoomsCode.GDcharectersObjects3[i];
        ++k;
    }
}
gdjs.RoomsCode.GDcharectersObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDcharectersObjects3.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDcharectersObjects3[i].getBehavior("Animation").getAnimationName() == "drunked" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDcharectersObjects3[k] = gdjs.RoomsCode.GDcharectersObjects3[i];
        ++k;
    }
}
gdjs.RoomsCode.GDcharectersObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "conversation"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause"));
}
}
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Name"), gdjs.RoomsCode.GDNameObjects3);
gdjs.copyArray(runtimeScene.getObjects("arrow"), gdjs.RoomsCode.GDarrowObjects3);
gdjs.copyArray(runtimeScene.getObjects("charecters2"), gdjs.RoomsCode.GDcharecters2Objects3);
gdjs.copyArray(runtimeScene.getObjects("options"), gdjs.RoomsCode.GDoptionsObjects3);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollspeed");
}{gdjs.dialogueTree.startFrom("drunked-1");
}{for(var i = 0, len = gdjs.RoomsCode.GDcharecters2Objects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDcharecters2Objects3[i].getBehavior("Animation").setAnimationName("drunked");
}
}{for(var i = 0, len = gdjs.RoomsCode.GDNameObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDNameObjects3[i].getBehavior("Text").setText("drunked");
}
}{for(var i = 0, len = gdjs.RoomsCode.GDoptionsObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDoptionsObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.RoomsCode.GDarrowObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDarrowObjects3[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("charecters"), gdjs.RoomsCode.GDcharectersObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects2);
gdjs.RoomsCode.GDE_9595buttonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDE_9595buttonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects3);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDE_9595buttonObjects3.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDE_9595buttonObjects3[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDE_9595buttonObjects3[k] = gdjs.RoomsCode.GDE_9595buttonObjects3[i];
        ++k;
    }
}
gdjs.RoomsCode.GDE_9595buttonObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDE_9595buttonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDE_9595buttonObjects2_1final.indexOf(gdjs.RoomsCode.GDE_9595buttonObjects3[j]) === -1 )
            gdjs.RoomsCode.GDE_9595buttonObjects2_1final.push(gdjs.RoomsCode.GDE_9595buttonObjects3[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDE_9595buttonObjects2_1final, gdjs.RoomsCode.GDE_9595buttonObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(13).getChild("state")) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects2Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects2Objects, 80, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDcharectersObjects2.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDcharectersObjects2[i].getVariableBoolean(gdjs.RoomsCode.GDcharectersObjects2[i].getVariables().getFromIndex(0), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDcharectersObjects2[k] = gdjs.RoomsCode.GDcharectersObjects2[i];
        ++k;
    }
}
gdjs.RoomsCode.GDcharectersObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDcharectersObjects2.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDcharectersObjects2[i].getBehavior("Animation").getAnimationName() == "drunked" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDcharectersObjects2[k] = gdjs.RoomsCode.GDcharectersObjects2[i];
        ++k;
    }
}
gdjs.RoomsCode.GDcharectersObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "conversation"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause"));
}
}
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Name"), gdjs.RoomsCode.GDNameObjects2);
gdjs.copyArray(runtimeScene.getObjects("charecters2"), gdjs.RoomsCode.GDcharecters2Objects2);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollspeed");
}{for(var i = 0, len = gdjs.RoomsCode.GDcharecters2Objects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDcharecters2Objects2[i].getBehavior("Animation").setAnimationName("drunked");
}
}{gdjs.dialogueTree.startFrom("drunked-2");
}{for(var i = 0, len = gdjs.RoomsCode.GDNameObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDNameObjects2[i].getBehavior("Text").setText("drunked");
}
}}

}


};gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects = Hashtable.newFrom({"charecters": gdjs.RoomsCode.GDcharectersObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects = Hashtable.newFrom({"charecters": gdjs.RoomsCode.GDcharectersObjects3});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects2});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects2Objects = Hashtable.newFrom({"charecters": gdjs.RoomsCode.GDcharectersObjects2});
gdjs.RoomsCode.eventsList31 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("charecters"), gdjs.RoomsCode.GDcharectersObjects3);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects3);
gdjs.RoomsCode.GDE_9595buttonObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDE_9595buttonObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects4);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDE_9595buttonObjects4.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDE_9595buttonObjects4[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDE_9595buttonObjects4[k] = gdjs.RoomsCode.GDE_9595buttonObjects4[i];
        ++k;
    }
}
gdjs.RoomsCode.GDE_9595buttonObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDE_9595buttonObjects4.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDE_9595buttonObjects3_1final.indexOf(gdjs.RoomsCode.GDE_9595buttonObjects4[j]) === -1 )
            gdjs.RoomsCode.GDE_9595buttonObjects3_1final.push(gdjs.RoomsCode.GDE_9595buttonObjects4[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDE_9595buttonObjects3_1final, gdjs.RoomsCode.GDE_9595buttonObjects3);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(14).getChild("state")) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects, 80, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDcharectersObjects3.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDcharectersObjects3[i].getBehavior("Animation").getAnimationName() == "regugee" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDcharectersObjects3[k] = gdjs.RoomsCode.GDcharectersObjects3[i];
        ++k;
    }
}
gdjs.RoomsCode.GDcharectersObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "conversation"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause"));
}
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Name"), gdjs.RoomsCode.GDNameObjects3);
gdjs.copyArray(runtimeScene.getObjects("arrow"), gdjs.RoomsCode.GDarrowObjects3);
gdjs.copyArray(runtimeScene.getObjects("charecters2"), gdjs.RoomsCode.GDcharecters2Objects3);
gdjs.copyArray(runtimeScene.getObjects("options"), gdjs.RoomsCode.GDoptionsObjects3);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollspeed");
}{gdjs.dialogueTree.startFrom("refugee-1");
}{for(var i = 0, len = gdjs.RoomsCode.GDcharecters2Objects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDcharecters2Objects3[i].getBehavior("Animation").setAnimationName("refugee");
}
}{runtimeScene.getGame().getVariables().getFromIndex(14).getChild("state").setNumber(1);
}{for(var i = 0, len = gdjs.RoomsCode.GDNameObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDNameObjects3[i].getBehavior("Text").setText("children");
}
}{for(var i = 0, len = gdjs.RoomsCode.GDoptionsObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDoptionsObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.RoomsCode.GDarrowObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDarrowObjects3[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("charecters"), gdjs.RoomsCode.GDcharectersObjects3);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects3);
gdjs.RoomsCode.GDE_9595buttonObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDE_9595buttonObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects4);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDE_9595buttonObjects4.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDE_9595buttonObjects4[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDE_9595buttonObjects4[k] = gdjs.RoomsCode.GDE_9595buttonObjects4[i];
        ++k;
    }
}
gdjs.RoomsCode.GDE_9595buttonObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDE_9595buttonObjects4.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDE_9595buttonObjects3_1final.indexOf(gdjs.RoomsCode.GDE_9595buttonObjects4[j]) === -1 )
            gdjs.RoomsCode.GDE_9595buttonObjects3_1final.push(gdjs.RoomsCode.GDE_9595buttonObjects4[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDE_9595buttonObjects3_1final, gdjs.RoomsCode.GDE_9595buttonObjects3);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(14).getChild("state")) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("task"), true, false));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects3Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects3Objects, 80, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDcharectersObjects3.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDcharectersObjects3[i].getBehavior("Animation").getAnimationName() == "regugee" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDcharectersObjects3[k] = gdjs.RoomsCode.GDcharectersObjects3[i];
        ++k;
    }
}
gdjs.RoomsCode.GDcharectersObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "conversation"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause"));
}
}
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Name"), gdjs.RoomsCode.GDNameObjects3);
gdjs.copyArray(runtimeScene.getObjects("charecters2"), gdjs.RoomsCode.GDcharecters2Objects3);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollspeed");
}{for(var i = 0, len = gdjs.RoomsCode.GDcharecters2Objects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDcharecters2Objects3[i].getBehavior("Animation").setAnimationName("refugee");
}
}{gdjs.dialogueTree.startFrom("refugee-2");
}{for(var i = 0, len = gdjs.RoomsCode.GDNameObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDNameObjects3[i].getBehavior("Text").setText("children");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("charecters"), gdjs.RoomsCode.GDcharectersObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects2);
gdjs.RoomsCode.GDE_9595buttonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDE_9595buttonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects3);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDE_9595buttonObjects3.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDE_9595buttonObjects3[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDE_9595buttonObjects3[k] = gdjs.RoomsCode.GDE_9595buttonObjects3[i];
        ++k;
    }
}
gdjs.RoomsCode.GDE_9595buttonObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDE_9595buttonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDE_9595buttonObjects2_1final.indexOf(gdjs.RoomsCode.GDE_9595buttonObjects3[j]) === -1 )
            gdjs.RoomsCode.GDE_9595buttonObjects2_1final.push(gdjs.RoomsCode.GDE_9595buttonObjects3[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDE_9595buttonObjects2_1final, gdjs.RoomsCode.GDE_9595buttonObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("misionstate"), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(14).getChild("state")) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("task"), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects2Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects2Objects, 80, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDcharectersObjects2.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDcharectersObjects2[i].getBehavior("Animation").getAnimationName() == "regugee" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDcharectersObjects2[k] = gdjs.RoomsCode.GDcharectersObjects2[i];
        ++k;
    }
}
gdjs.RoomsCode.GDcharectersObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "conversation"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause"));
}
}
}
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Name"), gdjs.RoomsCode.GDNameObjects2);
gdjs.copyArray(runtimeScene.getObjects("charecters2"), gdjs.RoomsCode.GDcharecters2Objects2);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollspeed");
}{for(var i = 0, len = gdjs.RoomsCode.GDcharecters2Objects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDcharecters2Objects2[i].getBehavior("Animation").setAnimationName("refugee");
}
}{gdjs.dialogueTree.startFrom("refugee-3");
}{for(var i = 0, len = gdjs.RoomsCode.GDNameObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDNameObjects2[i].getBehavior("Text").setText("children");
}
}{runtimeScene.getGame().getVariables().getFromIndex(16).setNumber(1);
}}

}


};gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects2});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects2Objects = Hashtable.newFrom({"charecters": gdjs.RoomsCode.GDcharectersObjects2});
gdjs.RoomsCode.eventsList32 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "scrollspeed") >= runtimeScene.getGame().getVariables().getFromIndex(2).getAsNumber();
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.hasClippedScrollingCompleted());
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "New sound effect", false, 50, gdjs.random(2));
}{gdjs.dialogueTree.scrollClippedText();
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollspeed");
}}

}


{

gdjs.RoomsCode.GDE_9595buttonObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDE_9595buttonObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects4);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDE_9595buttonObjects4.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDE_9595buttonObjects4[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDE_9595buttonObjects4[k] = gdjs.RoomsCode.GDE_9595buttonObjects4[i];
        ++k;
    }
}
gdjs.RoomsCode.GDE_9595buttonObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDE_9595buttonObjects4.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDE_9595buttonObjects3_1final.indexOf(gdjs.RoomsCode.GDE_9595buttonObjects4[j]) === -1 )
            gdjs.RoomsCode.GDE_9595buttonObjects3_1final.push(gdjs.RoomsCode.GDE_9595buttonObjects4[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDE_9595buttonObjects3_1final, gdjs.RoomsCode.GDE_9595buttonObjects3);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.dialogueTree.hasClippedScrollingCompleted();
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29892244);
}
}
}
if (isConditionTrue_0) {
{gdjs.dialogueTree.goToNextDialogueLine();
}}

}


{

gdjs.RoomsCode.GDE_9595buttonObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDE_9595buttonObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects4);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDE_9595buttonObjects4.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDE_9595buttonObjects4[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDE_9595buttonObjects4[k] = gdjs.RoomsCode.GDE_9595buttonObjects4[i];
        ++k;
    }
}
gdjs.RoomsCode.GDE_9595buttonObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDE_9595buttonObjects4.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDE_9595buttonObjects3_1final.indexOf(gdjs.RoomsCode.GDE_9595buttonObjects4[j]) === -1 )
            gdjs.RoomsCode.GDE_9595buttonObjects3_1final.push(gdjs.RoomsCode.GDE_9595buttonObjects4[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDE_9595buttonObjects3_1final, gdjs.RoomsCode.GDE_9595buttonObjects3);
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(2).setNumber(0.01);
}}

}


{

gdjs.RoomsCode.GDE_9595buttonObjects3.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDE_9595buttonObjects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects4);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDE_9595buttonObjects4.length;i<l;++i) {
    if ( !(gdjs.RoomsCode.GDE_9595buttonObjects4[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDE_9595buttonObjects4[k] = gdjs.RoomsCode.GDE_9595buttonObjects4[i];
        ++k;
    }
}
gdjs.RoomsCode.GDE_9595buttonObjects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDE_9595buttonObjects4.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDE_9595buttonObjects3_1final.indexOf(gdjs.RoomsCode.GDE_9595buttonObjects4[j]) === -1 )
            gdjs.RoomsCode.GDE_9595buttonObjects3_1final.push(gdjs.RoomsCode.GDE_9595buttonObjects4[j]);
    }
}
}
{
isConditionTrue_1 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "e"));
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDE_9595buttonObjects3_1final, gdjs.RoomsCode.GDE_9595buttonObjects3);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29894492);
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(2).setNumber(0.05);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Space");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29895476);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.RoomsCode.GDDialogeObjects2 */
{for(var i = 0, len = gdjs.RoomsCode.GDDialogeObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDDialogeObjects2[i].getBehavior("Text").setText(gdjs.dialogueTree.getLineText());
}
}{gdjs.dialogueTree.goToNextDialogueLine();
}}

}


};gdjs.RoomsCode.eventsList33 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29897220);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.RoomsCode.GDarrowObjects1, gdjs.RoomsCode.GDarrowObjects2);

{gdjs.dialogueTree.selectOption(0);
}{for(var i = 0, len = gdjs.RoomsCode.GDarrowObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDarrowObjects2[i].setY(960);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29896932);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.RoomsCode.GDarrowObjects1, gdjs.RoomsCode.GDarrowObjects2);

{gdjs.dialogueTree.selectOption(1);
}{for(var i = 0, len = gdjs.RoomsCode.GDarrowObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDarrowObjects2[i].setY(992);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.dialogueTree.hasSelectedOptionChanged();
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.RoomsCode.GDoptionsObjects1, gdjs.RoomsCode.GDoptionsObjects2);

{for(var i = 0, len = gdjs.RoomsCode.GDoptionsObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDoptionsObjects2[i].getBehavior("Text").setText(gdjs.dialogueTree.getLineOptionsTextVertical(" "));
}
}}

}


{

gdjs.RoomsCode.GDE_9595buttonObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDE_9595buttonObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects2);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDE_9595buttonObjects2.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDE_9595buttonObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDE_9595buttonObjects2[k] = gdjs.RoomsCode.GDE_9595buttonObjects2[i];
        ++k;
    }
}
gdjs.RoomsCode.GDE_9595buttonObjects2.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDE_9595buttonObjects2.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDE_9595buttonObjects1_1final.indexOf(gdjs.RoomsCode.GDE_9595buttonObjects2[j]) === -1 )
            gdjs.RoomsCode.GDE_9595buttonObjects1_1final.push(gdjs.RoomsCode.GDE_9595buttonObjects2[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDE_9595buttonObjects1_1final, gdjs.RoomsCode.GDE_9595buttonObjects1);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29900156);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.RoomsCode.GDarrowObjects1 */
/* Reuse gdjs.RoomsCode.GDoptionsObjects1 */
{gdjs.dialogueTree.confirmSelectOption();
}{for(var i = 0, len = gdjs.RoomsCode.GDoptionsObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDoptionsObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.RoomsCode.GDarrowObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDarrowObjects1[i].hide();
}
}}

}


};gdjs.RoomsCode.eventsList34 = function(runtimeScene) {

{


gdjs.RoomsCode.eventsList17(runtimeScene);
}


{


gdjs.RoomsCode.eventsList18(runtimeScene);
}


{


gdjs.RoomsCode.eventsList20(runtimeScene);
}


{


gdjs.RoomsCode.eventsList21(runtimeScene);
}


{


gdjs.RoomsCode.eventsList23(runtimeScene);
}


{


gdjs.RoomsCode.eventsList24(runtimeScene);
}


{


gdjs.RoomsCode.eventsList26(runtimeScene);
}


{


gdjs.RoomsCode.eventsList27(runtimeScene);
}


{


gdjs.RoomsCode.eventsList29(runtimeScene);
}


{


gdjs.RoomsCode.eventsList30(runtimeScene);
}


{


gdjs.RoomsCode.eventsList31(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("charecters"), gdjs.RoomsCode.GDcharectersObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects2Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects2Objects, 80, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29884324);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause"));
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewBitmapText"), gdjs.RoomsCode.GDNewBitmapTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("task_bar"), gdjs.RoomsCode.GDtask_9595barObjects2);
{for(var i = 0, len = gdjs.RoomsCode.GDtask_9595barObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDtask_9595barObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.RoomsCode.GDNewBitmapTextObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDNewBitmapTextObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.RoomsCode.GDNewBitmapTextObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDNewBitmapTextObjects2[i].getBehavior("Text").setText("talk?");
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.dialogueTree.isRunning();
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Joystick"), gdjs.RoomsCode.GDJoystickObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects2);
{gdjs.evtTools.camera.showLayer(runtimeScene, "conversation");
}{for(var i = 0, len = gdjs.RoomsCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDplayerObjects2[i].activateBehavior("TopDownMovement", false);
}
}{for(var i = 0, len = gdjs.RoomsCode.GDJoystickObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDJoystickObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.RoomsCode.GDJoystickObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDJoystickObjects2[i].ActivateControl(false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "scrollspeed") >= 2;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29887756);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Joystick"), gdjs.RoomsCode.GDJoystickObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects2);
{gdjs.evtTools.camera.hideLayer(runtimeScene, "conversation");
}{for(var i = 0, len = gdjs.RoomsCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDplayerObjects2[i].activateBehavior("TopDownMovement", true);
}
}{gdjs.evtTools.runtimeScene.removeTimer(runtimeScene, "scrollspeed");
}{for(var i = 0, len = gdjs.RoomsCode.GDJoystickObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDJoystickObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.RoomsCode.GDJoystickObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDJoystickObjects2[i].ActivateControl(true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.dialogueTree.isDialogueLineType("text");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Dialoge"), gdjs.RoomsCode.GDDialogeObjects2);
gdjs.copyArray(runtimeScene.getObjects("arrow"), gdjs.RoomsCode.GDarrowObjects2);
gdjs.copyArray(runtimeScene.getObjects("options"), gdjs.RoomsCode.GDoptionsObjects2);
{for(var i = 0, len = gdjs.RoomsCode.GDDialogeObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDDialogeObjects2[i].getBehavior("Text").setText(gdjs.dialogueTree.getClippedLineText());
}
}{for(var i = 0, len = gdjs.RoomsCode.GDoptionsObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDoptionsObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.RoomsCode.GDarrowObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDarrowObjects2[i].hide();
}
}
{ //Subevents
gdjs.RoomsCode.eventsList32(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.dialogueTree.isDialogueLineType("options");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("arrow"), gdjs.RoomsCode.GDarrowObjects1);
gdjs.copyArray(runtimeScene.getObjects("options"), gdjs.RoomsCode.GDoptionsObjects1);
{for(var i = 0, len = gdjs.RoomsCode.GDoptionsObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDoptionsObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.RoomsCode.GDarrowObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDarrowObjects1[i].hide(false);
}
}
{ //Subevents
gdjs.RoomsCode.eventsList33(runtimeScene);} //End of subevents
}

}


};gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects2});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDobjectsObjects2Objects = Hashtable.newFrom({"objects": gdjs.RoomsCode.GDobjectsObjects2});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects2});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDobjectsObjects2Objects = Hashtable.newFrom({"objects": gdjs.RoomsCode.GDobjectsObjects2});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects2});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDobjectsObjects2Objects = Hashtable.newFrom({"objects": gdjs.RoomsCode.GDobjectsObjects2});
gdjs.RoomsCode.eventsList35 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("objects"), gdjs.RoomsCode.GDobjectsObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDobjectsObjects2.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDobjectsObjects2[i].getBehavior("Animation").getAnimationName() == "safe" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDobjectsObjects2[k] = gdjs.RoomsCode.GDobjectsObjects2[i];
        ++k;
    }
}
gdjs.RoomsCode.GDobjectsObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects2Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDobjectsObjects2Objects, 64, true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(5).getChild("misionstate"), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29901876);
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewBitmapText"), gdjs.RoomsCode.GDNewBitmapTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("task_bar"), gdjs.RoomsCode.GDtask_9595barObjects2);
{for(var i = 0, len = gdjs.RoomsCode.GDtask_9595barObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDtask_9595barObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.RoomsCode.GDNewBitmapTextObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDNewBitmapTextObjects2[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("objects"), gdjs.RoomsCode.GDobjectsObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDobjectsObjects2.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDobjectsObjects2[i].getBehavior("Animation").getAnimationName() == "safe" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDobjectsObjects2[k] = gdjs.RoomsCode.GDobjectsObjects2[i];
        ++k;
    }
}
gdjs.RoomsCode.GDobjectsObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects2Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDobjectsObjects2Objects, 64, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(5).getChild("misionstate"), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29902820);
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewBitmapText"), gdjs.RoomsCode.GDNewBitmapTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("task_bar"), gdjs.RoomsCode.GDtask_9595barObjects2);
{for(var i = 0, len = gdjs.RoomsCode.GDtask_9595barObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDtask_9595barObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.RoomsCode.GDNewBitmapTextObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDNewBitmapTextObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.RoomsCode.GDNewBitmapTextObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDNewBitmapTextObjects2[i].getBehavior("Text").setText("Open?");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("objects"), gdjs.RoomsCode.GDobjectsObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects2);
gdjs.RoomsCode.GDE_9595buttonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDobjectsObjects2.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDobjectsObjects2[i].getBehavior("Animation").getAnimationName() == "safe" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDobjectsObjects2[k] = gdjs.RoomsCode.GDobjectsObjects2[i];
        ++k;
    }
}
gdjs.RoomsCode.GDobjectsObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects2Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDobjectsObjects2Objects, 64, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(5).getChild("misionstate"), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDE_9595buttonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects3);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDE_9595buttonObjects3.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDE_9595buttonObjects3[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDE_9595buttonObjects3[k] = gdjs.RoomsCode.GDE_9595buttonObjects3[i];
        ++k;
    }
}
gdjs.RoomsCode.GDE_9595buttonObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDE_9595buttonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDE_9595buttonObjects2_1final.indexOf(gdjs.RoomsCode.GDE_9595buttonObjects3[j]) === -1 )
            gdjs.RoomsCode.GDE_9595buttonObjects2_1final.push(gdjs.RoomsCode.GDE_9595buttonObjects3[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDE_9595buttonObjects2_1final, gdjs.RoomsCode.GDE_9595buttonObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29905444);
}
}
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.camera.showLayer(runtimeScene, "safe");
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("close"), gdjs.RoomsCode.GDcloseObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "safe");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDcloseObjects2.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDcloseObjects2[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDcloseObjects2[k] = gdjs.RoomsCode.GDcloseObjects2[i];
        ++k;
    }
}
gdjs.RoomsCode.GDcloseObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(5).getChild("misionstate"), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29906852);
}
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "safe");
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("open"), gdjs.RoomsCode.GDopenObjects1);
gdjs.copyArray(runtimeScene.getObjects("password"), gdjs.RoomsCode.GDpasswordObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "safe");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDopenObjects1.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDopenObjects1[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDopenObjects1[k] = gdjs.RoomsCode.GDopenObjects1[i];
        ++k;
    }
}
gdjs.RoomsCode.GDopenObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDpasswordObjects1.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDpasswordObjects1[i].getBehavior("Text").getText() == runtimeScene.getGame().getVariables().getFromIndex(15).getAsString() ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDpasswordObjects1[k] = gdjs.RoomsCode.GDpasswordObjects1[i];
        ++k;
    }
}
gdjs.RoomsCode.GDpasswordObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(5).getChild("misionstate"), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29908460);
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewBitmapText"), gdjs.RoomsCode.GDNewBitmapTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("task_bar"), gdjs.RoomsCode.GDtask_9595barObjects1);
{runtimeScene.getGame().getVariables().getFromIndex(5).getChild("misionstate").setBoolean(true);
}{runtimeScene.getGame().getVariables().getFromIndex(11).getChild("collect").add(1);
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "safe");
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 1);
}{for(var i = 0, len = gdjs.RoomsCode.GDtask_9595barObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDtask_9595barObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.RoomsCode.GDNewBitmapTextObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDNewBitmapTextObjects1[i].hide();
}
}}

}


};gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects2});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects2Objects = Hashtable.newFrom({"charecters": gdjs.RoomsCode.GDcharectersObjects2});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects1});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects1Objects = Hashtable.newFrom({"charecters": gdjs.RoomsCode.GDcharectersObjects1});
gdjs.RoomsCode.asyncCallback29916636 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.RoomsCode.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "School", false);
}gdjs.RoomsCode.localVariables.length = 0;
}
gdjs.RoomsCode.eventsList36 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.RoomsCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.RoomsCode.asyncCallback29916636(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.RoomsCode.eventsList37 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("charecters"), gdjs.RoomsCode.GDcharectersObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects2);
gdjs.RoomsCode.GDE_9595buttonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDE_9595buttonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects3);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDE_9595buttonObjects3.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDE_9595buttonObjects3[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDE_9595buttonObjects3[k] = gdjs.RoomsCode.GDE_9595buttonObjects3[i];
        ++k;
    }
}
gdjs.RoomsCode.GDE_9595buttonObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDE_9595buttonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDE_9595buttonObjects2_1final.indexOf(gdjs.RoomsCode.GDE_9595buttonObjects3[j]) === -1 )
            gdjs.RoomsCode.GDE_9595buttonObjects2_1final.push(gdjs.RoomsCode.GDE_9595buttonObjects3[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDE_9595buttonObjects2_1final, gdjs.RoomsCode.GDE_9595buttonObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(14).getChild("state")) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects2Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects2Objects, 80, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDcharectersObjects2.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDcharectersObjects2[i].getBehavior("Animation").getAnimationName() == "regugee" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDcharectersObjects2[k] = gdjs.RoomsCode.GDcharectersObjects2[i];
        ++k;
    }
}
gdjs.RoomsCode.GDcharectersObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "conversation"));
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Name"), gdjs.RoomsCode.GDNameObjects2);
gdjs.copyArray(runtimeScene.getObjects("charecters2"), gdjs.RoomsCode.GDcharecters2Objects2);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollspeed");
}{for(var i = 0, len = gdjs.RoomsCode.GDcharecters2Objects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDcharecters2Objects2[i].getBehavior("Animation").setAnimationName("refugee");
}
}{gdjs.dialogueTree.startFrom("refugee-2");
}{for(var i = 0, len = gdjs.RoomsCode.GDNameObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDNameObjects2[i].getBehavior("Text").setText("children");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("charecters"), gdjs.RoomsCode.GDcharectersObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects1);
gdjs.RoomsCode.GDE_9595buttonObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDE_9595buttonObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects2);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDE_9595buttonObjects2.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDE_9595buttonObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDE_9595buttonObjects2[k] = gdjs.RoomsCode.GDE_9595buttonObjects2[i];
        ++k;
    }
}
gdjs.RoomsCode.GDE_9595buttonObjects2.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDE_9595buttonObjects2.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDE_9595buttonObjects1_1final.indexOf(gdjs.RoomsCode.GDE_9595buttonObjects2[j]) === -1 )
            gdjs.RoomsCode.GDE_9595buttonObjects1_1final.push(gdjs.RoomsCode.GDE_9595buttonObjects2[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDE_9595buttonObjects1_1final, gdjs.RoomsCode.GDE_9595buttonObjects1);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("task"), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(14).getChild("state")) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(3).getChild("misionstate"), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects1Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects1Objects, 80, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDcharectersObjects1.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDcharectersObjects1[i].getBehavior("Animation").getAnimationName() == "regugee" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDcharectersObjects1[k] = gdjs.RoomsCode.GDcharectersObjects1[i];
        ++k;
    }
}
gdjs.RoomsCode.GDcharectersObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "conversation"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29915236);
}
}
}
}
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Name"), gdjs.RoomsCode.GDNameObjects1);
gdjs.copyArray(runtimeScene.getObjects("charecters2"), gdjs.RoomsCode.GDcharecters2Objects1);
gdjs.copyArray(runtimeScene.getObjects("transition"), gdjs.RoomsCode.GDtransitionObjects1);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollspeed");
}{for(var i = 0, len = gdjs.RoomsCode.GDcharecters2Objects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDcharecters2Objects1[i].getBehavior("Animation").setAnimationName("refugee");
}
}{gdjs.dialogueTree.startFrom("refugee-3");
}{for(var i = 0, len = gdjs.RoomsCode.GDNameObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDNameObjects1[i].getBehavior("Text").setText("children");
}
}{runtimeScene.getGame().getVariables().getFromIndex(16).setNumber(1);
}{for(var i = 0, len = gdjs.RoomsCode.GDtransitionObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDtransitionObjects1[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 0.2, "Flash", "Forward", 100, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.RoomsCode.eventsList36(runtimeScene);} //End of subevents
}

}


};gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects2});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDobjectsObjects2Objects = Hashtable.newFrom({"objects": gdjs.RoomsCode.GDobjectsObjects2});
gdjs.RoomsCode.asyncCallback29921748 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.RoomsCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("objects"), gdjs.RoomsCode.GDobjectsObjects3);

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects3);
gdjs.copyArray(runtimeScene.getObjects("smalllight"), gdjs.RoomsCode.GDsmalllightObjects3);
{runtimeScene.getScene().getVariables().getFromIndex(0).setBoolean(false);
}{for(var i = 0, len = gdjs.RoomsCode.GDsmalllightObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDsmalllightObjects3[i].setRadius(60);
}
}{for(var i = 0, len = gdjs.RoomsCode.GDplayerObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDplayerObjects3[i].activateBehavior("TopDownMovement", true);
}
}{for(var i = 0, len = gdjs.RoomsCode.GDobjectsObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDobjectsObjects3[i].getBehavior("Animation").setAnimationName("brokenmoniter");
}
}{runtimeScene.getScene().getVariables().getFromIndex(1).setBoolean(true);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "light");
}gdjs.RoomsCode.localVariables.length = 0;
}
gdjs.RoomsCode.eventsList38 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.RoomsCode.localVariables);
for (const obj of gdjs.RoomsCode.GDobjectsObjects2) asyncObjectsList.addObject("objects", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.RoomsCode.asyncCallback29921748(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.RoomsCode.asyncCallback29925820 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.RoomsCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("objects"), gdjs.RoomsCode.GDobjectsObjects3);

{for(var i = 0, len = gdjs.RoomsCode.GDobjectsObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDobjectsObjects3[i].getBehavior("Animation").setAnimationName("brokenmoniter");
}
}{runtimeScene.getScene().getVariables().getFromIndex(1).setBoolean(false);
}{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(0);
}gdjs.RoomsCode.localVariables.length = 0;
}
gdjs.RoomsCode.eventsList39 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.RoomsCode.localVariables);
for (const obj of gdjs.RoomsCode.GDobjectsObjects2) asyncObjectsList.addObject("objects", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.RoomsCode.asyncCallback29925820(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.RoomsCode.eventsList40 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(asyncObjectsList.getObjects("countdown"), gdjs.RoomsCode.GDcountdownObjects4);

gdjs.copyArray(asyncObjectsList.getObjects("tip2"), gdjs.RoomsCode.GDtip2Objects4);

{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber(Math.floor(gdjs.randomInRange(0, 3)));
}{for(var i = 0, len = gdjs.RoomsCode.GDcountdownObjects4.length ;i < len;++i) {
    gdjs.RoomsCode.GDcountdownObjects4[i].hide(false);
}
}{for(var i = 0, len = gdjs.RoomsCode.GDtip2Objects4.length ;i < len;++i) {
    gdjs.RoomsCode.GDtip2Objects4[i].hide(false);
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "light");
}}

}


{

gdjs.copyArray(asyncObjectsList.getObjects("smalllight"), gdjs.RoomsCode.GDsmalllightObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(1), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDsmalllightObjects3.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDsmalllightObjects3[i].getVariableNumber(gdjs.RoomsCode.GDsmalllightObjects3[i].getVariables().getFromIndex(0)) == runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber() ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDsmalllightObjects3[k] = gdjs.RoomsCode.GDsmalllightObjects3[i];
        ++k;
    }
}
gdjs.RoomsCode.GDsmalllightObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29932044);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.RoomsCode.GDsmalllightObjects3 */
{for(var i = 0, len = gdjs.RoomsCode.GDsmalllightObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDsmalllightObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.RoomsCode.GDsmalllightObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDsmalllightObjects3[i].returnVariable(gdjs.RoomsCode.GDsmalllightObjects3[i].getVariables().getFromIndex(1)).setBoolean(true);
}
}}

}


};gdjs.RoomsCode.asyncCallback29929836 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.RoomsCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("objects"), gdjs.RoomsCode.GDobjectsObjects3);

{for(var i = 0, len = gdjs.RoomsCode.GDobjectsObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDobjectsObjects3[i].getBehavior("Animation").setAnimationName("brokenmoniter");
}
}{runtimeScene.getScene().getVariables().getFromIndex(2).add(1);
}
{ //Subevents
gdjs.RoomsCode.eventsList40(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.RoomsCode.localVariables.length = 0;
}
gdjs.RoomsCode.eventsList41 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.RoomsCode.localVariables);
for (const obj of gdjs.RoomsCode.GDcountdownObjects2) asyncObjectsList.addObject("countdown", obj);
for (const obj of gdjs.RoomsCode.GDobjectsObjects2) asyncObjectsList.addObject("objects", obj);
for (const obj of gdjs.RoomsCode.GDsmalllightObjects2) asyncObjectsList.addObject("smalllight", obj);
for (const obj of gdjs.RoomsCode.GDtip2Objects2) asyncObjectsList.addObject("tip2", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.RoomsCode.asyncCallback29929836(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.RoomsCode.asyncCallback29934428 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.RoomsCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("objects"), gdjs.RoomsCode.GDobjectsObjects3);

{for(var i = 0, len = gdjs.RoomsCode.GDobjectsObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDobjectsObjects3[i].getBehavior("Animation").setAnimationName("brokenmoniter");
}
}{runtimeScene.getScene().getVariables().getFromIndex(1).setBoolean(false);
}{runtimeScene.getGame().getVariables().getFromIndex(6).getChild("misionstate").setBoolean(true);
}gdjs.RoomsCode.localVariables.length = 0;
}
gdjs.RoomsCode.eventsList42 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.RoomsCode.localVariables);
for (const obj of gdjs.RoomsCode.GDobjectsObjects2) asyncObjectsList.addObject("objects", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.RoomsCode.asyncCallback29934428(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects2});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDsmalllightObjects2Objects = Hashtable.newFrom({"smalllight": gdjs.RoomsCode.GDsmalllightObjects2});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects2});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDsmalllightObjects2Objects = Hashtable.newFrom({"smalllight": gdjs.RoomsCode.GDsmalllightObjects2});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects1});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDsmalllightObjects1Objects = Hashtable.newFrom({"smalllight": gdjs.RoomsCode.GDsmalllightObjects1});
gdjs.RoomsCode.eventsList43 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("objects"), gdjs.RoomsCode.GDobjectsObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects2);
gdjs.RoomsCode.GDE_9595buttonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDE_9595buttonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects3);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDE_9595buttonObjects3.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDE_9595buttonObjects3[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDE_9595buttonObjects3[k] = gdjs.RoomsCode.GDE_9595buttonObjects3[i];
        ++k;
    }
}
gdjs.RoomsCode.GDE_9595buttonObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDE_9595buttonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDE_9595buttonObjects2_1final.indexOf(gdjs.RoomsCode.GDE_9595buttonObjects3[j]) === -1 )
            gdjs.RoomsCode.GDE_9595buttonObjects2_1final.push(gdjs.RoomsCode.GDE_9595buttonObjects3[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDE_9595buttonObjects2_1final, gdjs.RoomsCode.GDE_9595buttonObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Generator";
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(6).getChild("task"), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(6).getChild("misionstate"), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(0), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(1), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects2Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDobjectsObjects2Objects, 64, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDobjectsObjects2.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDobjectsObjects2[i].getBehavior("Animation").getAnimationName() == "brokenmoniter" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDobjectsObjects2[k] = gdjs.RoomsCode.GDobjectsObjects2[i];
        ++k;
    }
}
gdjs.RoomsCode.GDobjectsObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29919956);
}
}
}
}
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewBitmapText"), gdjs.RoomsCode.GDNewBitmapTextObjects2);
/* Reuse gdjs.RoomsCode.GDobjectsObjects2 */
/* Reuse gdjs.RoomsCode.GDplayerObjects2 */
gdjs.copyArray(runtimeScene.getObjects("task_bar"), gdjs.RoomsCode.GDtask_9595barObjects2);
{for(var i = 0, len = gdjs.RoomsCode.GDobjectsObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDobjectsObjects2[i].getBehavior("Animation").setAnimationName("load");
}
}{for(var i = 0, len = gdjs.RoomsCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDplayerObjects2[i].activateBehavior("TopDownMovement", false);
}
}{for(var i = 0, len = gdjs.RoomsCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDplayerObjects2[i].getBehavior("Animation").setAnimationName("player");
}
}{for(var i = 0, len = gdjs.RoomsCode.GDtask_9595barObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDtask_9595barObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.RoomsCode.GDNewBitmapTextObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDNewBitmapTextObjects2[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("objects"), gdjs.RoomsCode.GDobjectsObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDobjectsObjects2.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDobjectsObjects2[i].getBehavior("Animation").getAnimationName() == "load" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDobjectsObjects2[k] = gdjs.RoomsCode.GDobjectsObjects2[i];
        ++k;
    }
}
gdjs.RoomsCode.GDobjectsObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDobjectsObjects2.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDobjectsObjects2[i].getBehavior("Animation").hasAnimationEnded() ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDobjectsObjects2[k] = gdjs.RoomsCode.GDobjectsObjects2[i];
        ++k;
    }
}
gdjs.RoomsCode.GDobjectsObjects2.length = k;
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).setBoolean(true);
}
{ //Subevents
gdjs.RoomsCode.eventsList38(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(0), true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("smalllight"), gdjs.RoomsCode.GDsmalllightObjects2);
{for(var i = 0, len = gdjs.RoomsCode.GDsmalllightObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDsmalllightObjects2[i].setRadius(gdjs.randomFloatInRange(5, 50));
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("countdown"), gdjs.RoomsCode.GDcountdownObjects2);
{for(var i = 0, len = gdjs.RoomsCode.GDcountdownObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDcountdownObjects2[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(Math.round(gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSeconds(runtimeScene, "light"))));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(1), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29925140);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("countdown"), gdjs.RoomsCode.GDcountdownObjects2);
gdjs.copyArray(runtimeScene.getObjects("tip2"), gdjs.RoomsCode.GDtip2Objects2);
{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber(Math.floor(gdjs.randomInRange(0, 3)));
}{for(var i = 0, len = gdjs.RoomsCode.GDcountdownObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDcountdownObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.RoomsCode.GDtip2Objects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDtip2Objects2[i].hide(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("objects"), gdjs.RoomsCode.GDobjectsObjects2);
gdjs.copyArray(runtimeScene.getObjects("smalllight"), gdjs.RoomsCode.GDsmalllightObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(1), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "light") >= 15;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDobjectsObjects2.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDobjectsObjects2[i].getBehavior("Animation").getAnimationName() == "brokenmoniter" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDobjectsObjects2[k] = gdjs.RoomsCode.GDobjectsObjects2[i];
        ++k;
    }
}
gdjs.RoomsCode.GDobjectsObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDsmalllightObjects2.length;i<l;++i) {
    if ( !(gdjs.RoomsCode.GDsmalllightObjects2[i].isVisible()) ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDsmalllightObjects2[k] = gdjs.RoomsCode.GDsmalllightObjects2[i];
        ++k;
    }
}
gdjs.RoomsCode.GDsmalllightObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29926508);
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("countdown"), gdjs.RoomsCode.GDcountdownObjects2);
/* Reuse gdjs.RoomsCode.GDobjectsObjects2 */
gdjs.copyArray(runtimeScene.getObjects("tip2"), gdjs.RoomsCode.GDtip2Objects2);
{for(var i = 0, len = gdjs.RoomsCode.GDtip2Objects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDtip2Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.RoomsCode.GDcountdownObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDcountdownObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.RoomsCode.GDobjectsObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDobjectsObjects2[i].getBehavior("Animation").setAnimationName("red-moniter");
}
}
{ //Subevents
gdjs.RoomsCode.eventsList39(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("objects"), gdjs.RoomsCode.GDobjectsObjects2);
gdjs.copyArray(runtimeScene.getObjects("smalllight"), gdjs.RoomsCode.GDsmalllightObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(1), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "light") >= 15;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDobjectsObjects2.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDobjectsObjects2[i].getBehavior("Animation").getAnimationName() == "brokenmoniter" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDobjectsObjects2[k] = gdjs.RoomsCode.GDobjectsObjects2[i];
        ++k;
    }
}
gdjs.RoomsCode.GDobjectsObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDsmalllightObjects2.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDsmalllightObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDsmalllightObjects2[k] = gdjs.RoomsCode.GDsmalllightObjects2[i];
        ++k;
    }
}
gdjs.RoomsCode.GDsmalllightObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) != 2;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29929364);
}
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("countdown"), gdjs.RoomsCode.GDcountdownObjects2);
/* Reuse gdjs.RoomsCode.GDobjectsObjects2 */
gdjs.copyArray(runtimeScene.getObjects("tip2"), gdjs.RoomsCode.GDtip2Objects2);
{for(var i = 0, len = gdjs.RoomsCode.GDcountdownObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDcountdownObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.RoomsCode.GDtip2Objects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDtip2Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.RoomsCode.GDobjectsObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDobjectsObjects2[i].getBehavior("Animation").setAnimationName("green-moniter");
}
}
{ //Subevents
gdjs.RoomsCode.eventsList41(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("objects"), gdjs.RoomsCode.GDobjectsObjects2);
gdjs.copyArray(runtimeScene.getObjects("smalllight"), gdjs.RoomsCode.GDsmalllightObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(1), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "light") >= 15;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDobjectsObjects2.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDobjectsObjects2[i].getBehavior("Animation").getAnimationName() == "brokenmoniter" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDobjectsObjects2[k] = gdjs.RoomsCode.GDobjectsObjects2[i];
        ++k;
    }
}
gdjs.RoomsCode.GDobjectsObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDsmalllightObjects2.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDsmalllightObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDsmalllightObjects2[k] = gdjs.RoomsCode.GDsmalllightObjects2[i];
        ++k;
    }
}
gdjs.RoomsCode.GDsmalllightObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) == 2;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29934164);
}
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("countdown"), gdjs.RoomsCode.GDcountdownObjects2);
/* Reuse gdjs.RoomsCode.GDobjectsObjects2 */
gdjs.copyArray(runtimeScene.getObjects("tip2"), gdjs.RoomsCode.GDtip2Objects2);
{for(var i = 0, len = gdjs.RoomsCode.GDcountdownObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDcountdownObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.RoomsCode.GDtip2Objects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDtip2Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.RoomsCode.GDobjectsObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDobjectsObjects2[i].getBehavior("Animation").setAnimationName("green-moniter");
}
}
{ //Subevents
gdjs.RoomsCode.eventsList42(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("smalllight"), gdjs.RoomsCode.GDsmalllightObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(1), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDsmalllightObjects2.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDsmalllightObjects2[i].getVariableNumber(gdjs.RoomsCode.GDsmalllightObjects2[i].getVariables().getFromIndex(0)) == runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber() ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDsmalllightObjects2[k] = gdjs.RoomsCode.GDsmalllightObjects2[i];
        ++k;
    }
}
gdjs.RoomsCode.GDsmalllightObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29936132);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.RoomsCode.GDsmalllightObjects2 */
{for(var i = 0, len = gdjs.RoomsCode.GDsmalllightObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDsmalllightObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.RoomsCode.GDsmalllightObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDsmalllightObjects2[i].returnVariable(gdjs.RoomsCode.GDsmalllightObjects2[i].getVariables().getFromIndex(1)).setBoolean(true);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("smalllight"), gdjs.RoomsCode.GDsmalllightObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(1), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDsmalllightObjects2.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDsmalllightObjects2[i].getVariableNumber(gdjs.RoomsCode.GDsmalllightObjects2[i].getVariables().getFromIndex(0)) == runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber() ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDsmalllightObjects2[k] = gdjs.RoomsCode.GDsmalllightObjects2[i];
        ++k;
    }
}
gdjs.RoomsCode.GDsmalllightObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects2Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDsmalllightObjects2Objects, 80, true);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewBitmapText"), gdjs.RoomsCode.GDNewBitmapTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("task_bar"), gdjs.RoomsCode.GDtask_9595barObjects2);
{for(var i = 0, len = gdjs.RoomsCode.GDtask_9595barObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDtask_9595barObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.RoomsCode.GDNewBitmapTextObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDNewBitmapTextObjects2[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("smalllight"), gdjs.RoomsCode.GDsmalllightObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(1), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects2Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDsmalllightObjects2Objects, 80, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDsmalllightObjects2.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDsmalllightObjects2[i].getVariableBoolean(gdjs.RoomsCode.GDsmalllightObjects2[i].getVariables().getFromIndex(1), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDsmalllightObjects2[k] = gdjs.RoomsCode.GDsmalllightObjects2[i];
        ++k;
    }
}
gdjs.RoomsCode.GDsmalllightObjects2.length = k;
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewBitmapText"), gdjs.RoomsCode.GDNewBitmapTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("task_bar"), gdjs.RoomsCode.GDtask_9595barObjects2);
{for(var i = 0, len = gdjs.RoomsCode.GDtask_9595barObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDtask_9595barObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.RoomsCode.GDNewBitmapTextObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDNewBitmapTextObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.RoomsCode.GDNewBitmapTextObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDNewBitmapTextObjects2[i].getBehavior("Text").setText("Turn on?");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("smalllight"), gdjs.RoomsCode.GDsmalllightObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(1), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDsmalllightObjects2.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDsmalllightObjects2[i].getVariableBoolean(gdjs.RoomsCode.GDsmalllightObjects2[i].getVariables().getFromIndex(1), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDsmalllightObjects2[k] = gdjs.RoomsCode.GDsmalllightObjects2[i];
        ++k;
    }
}
gdjs.RoomsCode.GDsmalllightObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.RoomsCode.GDsmalllightObjects2 */
{for(var i = 0, len = gdjs.RoomsCode.GDsmalllightObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDsmalllightObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.RoomsCode.GDsmalllightObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDsmalllightObjects2[i].returnVariable(gdjs.RoomsCode.GDsmalllightObjects2[i].getVariables().getFromIndex(1)).setBoolean(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("smalllight"), gdjs.RoomsCode.GDsmalllightObjects1);
gdjs.RoomsCode.GDE_9595buttonObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(1), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects1Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDsmalllightObjects1Objects, 80, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDsmalllightObjects1.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDsmalllightObjects1[i].getVariableBoolean(gdjs.RoomsCode.GDsmalllightObjects1[i].getVariables().getFromIndex(1), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDsmalllightObjects1[k] = gdjs.RoomsCode.GDsmalllightObjects1[i];
        ++k;
    }
}
gdjs.RoomsCode.GDsmalllightObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDE_9595buttonObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects2);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDE_9595buttonObjects2.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDE_9595buttonObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDE_9595buttonObjects2[k] = gdjs.RoomsCode.GDE_9595buttonObjects2[i];
        ++k;
    }
}
gdjs.RoomsCode.GDE_9595buttonObjects2.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDE_9595buttonObjects2.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDE_9595buttonObjects1_1final.indexOf(gdjs.RoomsCode.GDE_9595buttonObjects2[j]) === -1 )
            gdjs.RoomsCode.GDE_9595buttonObjects1_1final.push(gdjs.RoomsCode.GDE_9595buttonObjects2[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDE_9595buttonObjects1_1final, gdjs.RoomsCode.GDE_9595buttonObjects1);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29943660);
}
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.RoomsCode.GDsmalllightObjects1 */
{for(var i = 0, len = gdjs.RoomsCode.GDsmalllightObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDsmalllightObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.RoomsCode.GDsmalllightObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDsmalllightObjects1[i].returnVariable(gdjs.RoomsCode.GDsmalllightObjects1[i].getVariables().getFromIndex(1)).setBoolean(false);
}
}}

}


};gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects1});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects1Objects = Hashtable.newFrom({"charecters": gdjs.RoomsCode.GDcharectersObjects1});
gdjs.RoomsCode.eventsList44 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("charecters"), gdjs.RoomsCode.GDcharectersObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects1);
gdjs.RoomsCode.GDE_9595buttonObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDE_9595buttonObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects2);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDE_9595buttonObjects2.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDE_9595buttonObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDE_9595buttonObjects2[k] = gdjs.RoomsCode.GDE_9595buttonObjects2[i];
        ++k;
    }
}
gdjs.RoomsCode.GDE_9595buttonObjects2.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDE_9595buttonObjects2.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDE_9595buttonObjects1_1final.indexOf(gdjs.RoomsCode.GDE_9595buttonObjects2[j]) === -1 )
            gdjs.RoomsCode.GDE_9595buttonObjects1_1final.push(gdjs.RoomsCode.GDE_9595buttonObjects2[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDE_9595buttonObjects1_1final, gdjs.RoomsCode.GDE_9595buttonObjects1);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(8).getChild("state")) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(12).getChild("task"), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(12).getChild("misionstate"), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(8).getChild("race"), true, false));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects1Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects1Objects, 80, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDcharectersObjects1.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDcharectersObjects1[i].getBehavior("Animation").getAnimationName() == "trainer" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDcharectersObjects1[k] = gdjs.RoomsCode.GDcharectersObjects1[i];
        ++k;
    }
}
gdjs.RoomsCode.GDcharectersObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "conversation"));
}
}
}
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Name"), gdjs.RoomsCode.GDNameObjects1);
gdjs.copyArray(runtimeScene.getObjects("charecters2"), gdjs.RoomsCode.GDcharecters2Objects1);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollspeed");
}{for(var i = 0, len = gdjs.RoomsCode.GDcharecters2Objects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDcharecters2Objects1[i].getBehavior("Animation").setAnimationName("trainer");
}
}{gdjs.dialogueTree.startFrom("trainer-3");
}{for(var i = 0, len = gdjs.RoomsCode.GDNameObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDNameObjects1[i].getBehavior("Text").setText("Yami");
}
}{runtimeScene.getGame().getVariables().getFromIndex(12).getChild("misionstate").setBoolean(true);
}}

}


};gdjs.RoomsCode.asyncCallback29949564 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.RoomsCode.localVariables);
gdjs.copyArray(runtimeScene.getObjects("countdown"), gdjs.RoomsCode.GDcountdownObjects3);
gdjs.copyArray(runtimeScene.getObjects("objects2"), gdjs.RoomsCode.GDobjects2Objects3);
gdjs.copyArray(runtimeScene.getObjects("tip3"), gdjs.RoomsCode.GDtip3Objects3);
{for(var i = 0, len = gdjs.RoomsCode.GDobjects2Objects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDobjects2Objects3[i].getBehavior("Animation").setAnimationIndex(Math.floor(gdjs.random(7)));
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "find");
}{for(var i = 0, len = gdjs.RoomsCode.GDcountdownObjects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDcountdownObjects3[i].hide(false);
}
}{for(var i = 0, len = gdjs.RoomsCode.GDtip3Objects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDtip3Objects3[i].hide(false);
}
}{for(var i = 0, len = gdjs.RoomsCode.GDobjects2Objects3.length ;i < len;++i) {
    gdjs.RoomsCode.GDobjects2Objects3[i].hide(false);
}
}gdjs.RoomsCode.localVariables.length = 0;
}
gdjs.RoomsCode.eventsList45 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.RoomsCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.RoomsCode.asyncCallback29949564(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDobjectsObjects2Objects = Hashtable.newFrom({"objects": gdjs.RoomsCode.GDobjectsObjects2});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDobjectsObjects2Objects = Hashtable.newFrom({"objects": gdjs.RoomsCode.GDobjectsObjects2});
gdjs.RoomsCode.eventsList46 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(4), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(9).getChild("misionstate"), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29949324);
}
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.RoomsCode.eventsList45(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("objects"), gdjs.RoomsCode.GDobjectsObjects2);
gdjs.copyArray(runtimeScene.getObjects("objects2"), gdjs.RoomsCode.GDobjects2Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDobjectsObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(4), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(5)) >= 5);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDobjectsObjects2.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDobjectsObjects2[i].getBehavior("Animation").getAnimationName() == (( gdjs.RoomsCode.GDobjects2Objects2.length === 0 ) ? "" :gdjs.RoomsCode.GDobjects2Objects2[0].getBehavior("Animation").getAnimationName()) ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDobjectsObjects2[k] = gdjs.RoomsCode.GDobjectsObjects2[i];
        ++k;
    }
}
gdjs.RoomsCode.GDobjectsObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29951588);
}
}
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.RoomsCode.GDobjects2Objects2 */
{for(var i = 0, len = gdjs.RoomsCode.GDobjects2Objects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDobjects2Objects2[i].getBehavior("Animation").setAnimationIndex(Math.floor(gdjs.random(7)));
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "find");
}{runtimeScene.getScene().getVariables().getFromIndex(5).add(1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("objects"), gdjs.RoomsCode.GDobjectsObjects2);
gdjs.copyArray(runtimeScene.getObjects("objects2"), gdjs.RoomsCode.GDobjects2Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDobjectsObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(5)) >= 5;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(4), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDobjectsObjects2.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDobjectsObjects2[i].getBehavior("Animation").getAnimationName() == (( gdjs.RoomsCode.GDobjects2Objects2.length === 0 ) ? "" :gdjs.RoomsCode.GDobjects2Objects2[0].getBehavior("Animation").getAnimationName()) ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDobjectsObjects2[k] = gdjs.RoomsCode.GDobjectsObjects2[i];
        ++k;
    }
}
gdjs.RoomsCode.GDobjectsObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29953660);
}
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("countdown"), gdjs.RoomsCode.GDcountdownObjects2);
/* Reuse gdjs.RoomsCode.GDobjects2Objects2 */
gdjs.copyArray(runtimeScene.getObjects("tip3"), gdjs.RoomsCode.GDtip3Objects2);
{for(var i = 0, len = gdjs.RoomsCode.GDobjects2Objects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDobjects2Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.RoomsCode.GDtip3Objects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDtip3Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.RoomsCode.GDcountdownObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDcountdownObjects2[i].hide();
}
}{gdjs.evtTools.runtimeScene.removeTimer(runtimeScene, "find");
}{runtimeScene.getGame().getVariables().getFromIndex(9).getChild("misionstate").setBoolean(true);
}{runtimeScene.getScene().getVariables().getFromIndex(4).setBoolean(false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "find") >= 5;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(9).getChild("state")) == 2;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29955300);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Name"), gdjs.RoomsCode.GDNameObjects2);
gdjs.copyArray(runtimeScene.getObjects("charecters2"), gdjs.RoomsCode.GDcharecters2Objects2);
gdjs.copyArray(runtimeScene.getObjects("countdown"), gdjs.RoomsCode.GDcountdownObjects2);
gdjs.copyArray(runtimeScene.getObjects("objects2"), gdjs.RoomsCode.GDobjects2Objects2);
gdjs.copyArray(runtimeScene.getObjects("tip3"), gdjs.RoomsCode.GDtip3Objects2);
{for(var i = 0, len = gdjs.RoomsCode.GDobjects2Objects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDobjects2Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.RoomsCode.GDtip3Objects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDtip3Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.RoomsCode.GDcountdownObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDcountdownObjects2[i].hide();
}
}{gdjs.evtTools.runtimeScene.removeTimer(runtimeScene, "find");
}{runtimeScene.getScene().getVariables().getFromIndex(5).setNumber(0);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "scrollspeed");
}{for(var i = 0, len = gdjs.RoomsCode.GDcharecters2Objects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDcharecters2Objects2[i].getBehavior("Animation").setAnimationName("scrap-collecter");
}
}{gdjs.dialogueTree.startFrom("scrap_collector-4");
}{for(var i = 0, len = gdjs.RoomsCode.GDNameObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDNameObjects2[i].getBehavior("Text").setText("Wuhe");
}
}{runtimeScene.getGame().getVariables().getFromIndex(9).getChild("state").setNumber(1);
}{runtimeScene.getGame().getVariables().getFromIndex(9).getChild("task").setBoolean(false);
}{runtimeScene.getScene().getVariables().getFromIndex(4).setBoolean(false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(4), true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("countdown"), gdjs.RoomsCode.GDcountdownObjects1);
{for(var i = 0, len = gdjs.RoomsCode.GDcountdownObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDcountdownObjects1[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(Math.round(gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSeconds(runtimeScene, "find"))));
}
}}

}


};gdjs.RoomsCode.eventsList47 = function(runtimeScene) {

{

gdjs.RoomsCode.GDJoystickObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDJoystickObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Joystick"), gdjs.RoomsCode.GDJoystickObjects3);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDJoystickObjects3.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDJoystickObjects3[i].IsDirectionPushed8Way("Right", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDJoystickObjects3[k] = gdjs.RoomsCode.GDJoystickObjects3[i];
        ++k;
    }
}
gdjs.RoomsCode.GDJoystickObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDJoystickObjects3.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDJoystickObjects2_1final.indexOf(gdjs.RoomsCode.GDJoystickObjects3[j]) === -1 )
            gdjs.RoomsCode.GDJoystickObjects2_1final.push(gdjs.RoomsCode.GDJoystickObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Joystick"), gdjs.RoomsCode.GDJoystickObjects3);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDJoystickObjects3.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDJoystickObjects3[i].IsDirectionPushed8Way("UpRight", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDJoystickObjects3[k] = gdjs.RoomsCode.GDJoystickObjects3[i];
        ++k;
    }
}
gdjs.RoomsCode.GDJoystickObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDJoystickObjects3.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDJoystickObjects2_1final.indexOf(gdjs.RoomsCode.GDJoystickObjects3[j]) === -1 )
            gdjs.RoomsCode.GDJoystickObjects2_1final.push(gdjs.RoomsCode.GDJoystickObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Joystick"), gdjs.RoomsCode.GDJoystickObjects3);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDJoystickObjects3.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDJoystickObjects3[i].IsDirectionPushed8Way("DownRight", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDJoystickObjects3[k] = gdjs.RoomsCode.GDJoystickObjects3[i];
        ++k;
    }
}
gdjs.RoomsCode.GDJoystickObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDJoystickObjects3.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDJoystickObjects2_1final.indexOf(gdjs.RoomsCode.GDJoystickObjects3[j]) === -1 )
            gdjs.RoomsCode.GDJoystickObjects2_1final.push(gdjs.RoomsCode.GDJoystickObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDJoystickObjects2_1final, gdjs.RoomsCode.GDJoystickObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29958868);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects2);
{for(var i = 0, len = gdjs.RoomsCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDplayerObjects2[i].getBehavior("Animation").setAnimationName("player-walk");
}
}{for(var i = 0, len = gdjs.RoomsCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDplayerObjects2[i].getBehavior("Flippable").flipX(false);
}
}}

}


{

gdjs.RoomsCode.GDJoystickObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDJoystickObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Joystick"), gdjs.RoomsCode.GDJoystickObjects3);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDJoystickObjects3.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDJoystickObjects3[i].IsDirectionPushed8Way("Left", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDJoystickObjects3[k] = gdjs.RoomsCode.GDJoystickObjects3[i];
        ++k;
    }
}
gdjs.RoomsCode.GDJoystickObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDJoystickObjects3.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDJoystickObjects2_1final.indexOf(gdjs.RoomsCode.GDJoystickObjects3[j]) === -1 )
            gdjs.RoomsCode.GDJoystickObjects2_1final.push(gdjs.RoomsCode.GDJoystickObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Joystick"), gdjs.RoomsCode.GDJoystickObjects3);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDJoystickObjects3.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDJoystickObjects3[i].IsDirectionPushed8Way("DownLeft", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDJoystickObjects3[k] = gdjs.RoomsCode.GDJoystickObjects3[i];
        ++k;
    }
}
gdjs.RoomsCode.GDJoystickObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDJoystickObjects3.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDJoystickObjects2_1final.indexOf(gdjs.RoomsCode.GDJoystickObjects3[j]) === -1 )
            gdjs.RoomsCode.GDJoystickObjects2_1final.push(gdjs.RoomsCode.GDJoystickObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Joystick"), gdjs.RoomsCode.GDJoystickObjects3);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDJoystickObjects3.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDJoystickObjects3[i].IsDirectionPushed8Way("UpLeft", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDJoystickObjects3[k] = gdjs.RoomsCode.GDJoystickObjects3[i];
        ++k;
    }
}
gdjs.RoomsCode.GDJoystickObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDJoystickObjects3.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDJoystickObjects2_1final.indexOf(gdjs.RoomsCode.GDJoystickObjects3[j]) === -1 )
            gdjs.RoomsCode.GDJoystickObjects2_1final.push(gdjs.RoomsCode.GDJoystickObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDJoystickObjects2_1final, gdjs.RoomsCode.GDJoystickObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29962076);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects2);
{for(var i = 0, len = gdjs.RoomsCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDplayerObjects2[i].getBehavior("Animation").setAnimationName("player-walk");
}
}{for(var i = 0, len = gdjs.RoomsCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDplayerObjects2[i].getBehavior("Flippable").flipX(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Joystick"), gdjs.RoomsCode.GDJoystickObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDJoystickObjects2.length;i<l;++i) {
    if ( !(gdjs.RoomsCode.GDJoystickObjects2[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDJoystickObjects2[k] = gdjs.RoomsCode.GDJoystickObjects2[i];
        ++k;
    }
}
gdjs.RoomsCode.GDJoystickObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29962220);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects2);
{for(var i = 0, len = gdjs.RoomsCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDplayerObjects2[i].getBehavior("Animation").setAnimationName("player");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Joystick"), gdjs.RoomsCode.GDJoystickObjects2);
{gdjs.evtTools.camera.showLayer(runtimeScene, "Mobile");
}{for(var i = 0, len = gdjs.RoomsCode.GDJoystickObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDJoystickObjects2[i].ActivateControl(true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.RoomsCode.GDE_9595buttonObjects2.length ;i < len;++i) {
    gdjs.RoomsCode.GDE_9595buttonObjects2[i].Activate(true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene));
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects1);
gdjs.copyArray(runtimeScene.getObjects("Joystick"), gdjs.RoomsCode.GDJoystickObjects1);
{gdjs.evtTools.camera.hideLayer(runtimeScene, "Mobile");
}{for(var i = 0, len = gdjs.RoomsCode.GDJoystickObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDJoystickObjects1[i].ActivateControl(false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.RoomsCode.GDE_9595buttonObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDE_9595buttonObjects1[i].Activate(false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDsmalllightObjects2Objects = Hashtable.newFrom({"smalllight": gdjs.RoomsCode.GDsmalllightObjects2});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDwallobjectObjects2Objects = Hashtable.newFrom({"wallobject": gdjs.RoomsCode.GDwallobjectObjects2});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDwallobjectObjects2Objects = Hashtable.newFrom({"wallobject": gdjs.RoomsCode.GDwallobjectObjects2});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects2});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDobjectsObjects2Objects = Hashtable.newFrom({"objects": gdjs.RoomsCode.GDobjectsObjects2});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects2});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDobjectsObjects2Objects = Hashtable.newFrom({"objects": gdjs.RoomsCode.GDobjectsObjects2});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.RoomsCode.GDplayerObjects1});
gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDexitObjects1Objects = Hashtable.newFrom({"exit": gdjs.RoomsCode.GDexitObjects1});
gdjs.RoomsCode.asyncCallback29976668 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.RoomsCode.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Past", false);
}gdjs.RoomsCode.localVariables.length = 0;
}
gdjs.RoomsCode.eventsList48 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.RoomsCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.RoomsCode.asyncCallback29976668(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.RoomsCode.eventsList49 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("smalllight"), gdjs.RoomsCode.GDsmalllightObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "The Night";
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDsmalllightObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(4).getChild("Secret"), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29967820);
}
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.RoomsCode.GDsmalllightObjects2 */
{runtimeScene.getScene().getVariables().getFromIndex(6).setNumber(runtimeScene.getScene().getVariables().getFromIndex(6).getAsNumber() * 10 + ((gdjs.RoomsCode.GDsmalllightObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.RoomsCode.GDsmalllightObjects2[0].getVariables()).getFromIndex(2).getAsNumber());
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("wallobject"), gdjs.RoomsCode.GDwallobjectObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "The Night";
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDwallobjectObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDwallobjectObjects2.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDwallobjectObjects2[i].getBehavior("Animation").getAnimationName() == "Moon" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDwallobjectObjects2[k] = gdjs.RoomsCode.GDwallobjectObjects2[i];
        ++k;
    }
}
gdjs.RoomsCode.GDwallobjectObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(6)) != 4712;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(4).getChild("Secret"), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29969620);
}
}
}
}
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(6).setNumber(0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("wallobject"), gdjs.RoomsCode.GDwallobjectObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "The Night";
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDwallobjectObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDwallobjectObjects2.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDwallobjectObjects2[i].getBehavior("Animation").getAnimationName() == "Moon" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDwallobjectObjects2[k] = gdjs.RoomsCode.GDwallobjectObjects2[i];
        ++k;
    }
}
gdjs.RoomsCode.GDwallobjectObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(6)) == 4712;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(4).getChild("Secret"), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29971444);
}
}
}
}
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(4).getChild("Secret").setBoolean(true);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("objects"), gdjs.RoomsCode.GDobjectsObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects2);
gdjs.RoomsCode.GDE_9595buttonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Lost in time";
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(18)) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects2Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDobjectsObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDobjectsObjects2.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDobjectsObjects2[i].getBehavior("Animation").getAnimationName() == "fount" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDobjectsObjects2[k] = gdjs.RoomsCode.GDobjectsObjects2[i];
        ++k;
    }
}
gdjs.RoomsCode.GDobjectsObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(4).getChild("Secret"), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDE_9595buttonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects3);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDE_9595buttonObjects3.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDE_9595buttonObjects3[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDE_9595buttonObjects3[k] = gdjs.RoomsCode.GDE_9595buttonObjects3[i];
        ++k;
    }
}
gdjs.RoomsCode.GDE_9595buttonObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDE_9595buttonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDE_9595buttonObjects2_1final.indexOf(gdjs.RoomsCode.GDE_9595buttonObjects3[j]) === -1 )
            gdjs.RoomsCode.GDE_9595buttonObjects2_1final.push(gdjs.RoomsCode.GDE_9595buttonObjects3[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDE_9595buttonObjects2_1final, gdjs.RoomsCode.GDE_9595buttonObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29973708);
}
}
}
}
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setString("Forgotten Garden");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("objects"), gdjs.RoomsCode.GDobjectsObjects2);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects2);
gdjs.RoomsCode.GDE_9595buttonObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Forgotten Garden";
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(18)) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects2Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDobjectsObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDobjectsObjects2.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDobjectsObjects2[i].getBehavior("Animation").getAnimationName() == "fount" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDobjectsObjects2[k] = gdjs.RoomsCode.GDobjectsObjects2[i];
        ++k;
    }
}
gdjs.RoomsCode.GDobjectsObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(4).getChild("Secret"), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDE_9595buttonObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects3);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDE_9595buttonObjects3.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDE_9595buttonObjects3[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDE_9595buttonObjects3[k] = gdjs.RoomsCode.GDE_9595buttonObjects3[i];
        ++k;
    }
}
gdjs.RoomsCode.GDE_9595buttonObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDE_9595buttonObjects3.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDE_9595buttonObjects2_1final.indexOf(gdjs.RoomsCode.GDE_9595buttonObjects3[j]) === -1 )
            gdjs.RoomsCode.GDE_9595buttonObjects2_1final.push(gdjs.RoomsCode.GDE_9595buttonObjects3[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDE_9595buttonObjects2_1final, gdjs.RoomsCode.GDE_9595buttonObjects2);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29976044);
}
}
}
}
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setString("Lost in time");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("exit"), gdjs.RoomsCode.GDexitObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects1);
gdjs.RoomsCode.GDE_9595buttonObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Forgotten Garden";
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects1Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDexitObjects1Objects, 64, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDE_9595buttonObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects2);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDE_9595buttonObjects2.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDE_9595buttonObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDE_9595buttonObjects2[k] = gdjs.RoomsCode.GDE_9595buttonObjects2[i];
        ++k;
    }
}
gdjs.RoomsCode.GDE_9595buttonObjects2.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDE_9595buttonObjects2.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDE_9595buttonObjects1_1final.indexOf(gdjs.RoomsCode.GDE_9595buttonObjects2[j]) === -1 )
            gdjs.RoomsCode.GDE_9595buttonObjects1_1final.push(gdjs.RoomsCode.GDE_9595buttonObjects2[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDE_9595buttonObjects1_1final, gdjs.RoomsCode.GDE_9595buttonObjects1);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29978332);
}
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("transition"), gdjs.RoomsCode.GDtransitionObjects1);
{for(var i = 0, len = gdjs.RoomsCode.GDtransitionObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDtransitionObjects1[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 0.2, "Flash", "Forward", 100, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.RoomsCode.eventsList48(runtimeScene);} //End of subevents
}

}


};gdjs.RoomsCode.eventsList50 = function(runtimeScene) {

{


gdjs.RoomsCode.eventsList1(runtimeScene);
}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusic(runtimeScene, "rain-drops-on-window-green-noise-mix-231100.mp3", true, 40, 1);
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 2.5, "", 0);
}{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(0).getAsString(), 578, 329, 0);
}
{ //Subevents
gdjs.RoomsCode.eventsList4(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("countdown"), gdjs.RoomsCode.GDcountdownObjects1);
gdjs.copyArray(runtimeScene.getObjects("objects2"), gdjs.RoomsCode.GDobjects2Objects1);
gdjs.copyArray(runtimeScene.getObjects("tip2"), gdjs.RoomsCode.GDtip2Objects1);
gdjs.copyArray(runtimeScene.getObjects("tip3"), gdjs.RoomsCode.GDtip3Objects1);
gdjs.copyArray(runtimeScene.getObjects("transition"), gdjs.RoomsCode.GDtransitionObjects1);
{gdjs.dialogueTree.stopRunningDialogue();
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "conversation");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "safe");
}{gdjs.dialogueTree.loadFromJsonFile(runtimeScene, "Dialogue");
}{for(var i = 0, len = gdjs.RoomsCode.GDtransitionObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDtransitionObjects1[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 0.9, "Flash", "Backward", 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.RoomsCode.GDtip2Objects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDtip2Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.RoomsCode.GDcountdownObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDcountdownObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.RoomsCode.GDobjects2Objects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDobjects2Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.RoomsCode.GDtip3Objects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDtip3Objects1[i].hide();
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Grandpa's";
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusic(runtimeScene, "fireplace-loop-original-noise-178209.mp3", true, 100, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("objects"), gdjs.RoomsCode.GDobjectsObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDobjectsObjects1.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDobjectsObjects1[i].isCollidingWithPoint((( gdjs.RoomsCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.RoomsCode.GDplayerObjects1[0].getPointX("col")), (( gdjs.RoomsCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.RoomsCode.GDplayerObjects1[0].getPointY("col"))) ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDobjectsObjects1[k] = gdjs.RoomsCode.GDobjectsObjects1[i];
        ++k;
    }
}
gdjs.RoomsCode.GDobjectsObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDobjectsObjects1.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDobjectsObjects1[i].getBehavior("Animation").getAnimationName() == "tradmill" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDobjectsObjects1[k] = gdjs.RoomsCode.GDobjectsObjects1[i];
        ++k;
    }
}
gdjs.RoomsCode.GDobjectsObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDobjectsObjects1.length;i<l;++i) {
    if ( !(gdjs.RoomsCode.GDobjectsObjects1[i].getBehavior("Flippable").isFlippedX()) ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDobjectsObjects1[k] = gdjs.RoomsCode.GDobjectsObjects1[i];
        ++k;
    }
}
gdjs.RoomsCode.GDobjectsObjects1.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.RoomsCode.GDobjectsObjects1 */
/* Reuse gdjs.RoomsCode.GDplayerObjects1 */
{for(var i = 0, len = gdjs.RoomsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDplayerObjects1[i].addForceTowardPosition((( gdjs.RoomsCode.GDobjectsObjects1.length === 0 ) ? 0 :gdjs.RoomsCode.GDobjectsObjects1[0].getPointX("")) - 50, (gdjs.RoomsCode.GDplayerObjects1[i].getPointY("")), 190, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("objects"), gdjs.RoomsCode.GDobjectsObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDobjectsObjects1.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDobjectsObjects1[i].isCollidingWithPoint((( gdjs.RoomsCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.RoomsCode.GDplayerObjects1[0].getPointX("col")), (( gdjs.RoomsCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.RoomsCode.GDplayerObjects1[0].getPointY("col"))) ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDobjectsObjects1[k] = gdjs.RoomsCode.GDobjectsObjects1[i];
        ++k;
    }
}
gdjs.RoomsCode.GDobjectsObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDobjectsObjects1.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDobjectsObjects1[i].getBehavior("Animation").getAnimationName() == "tradmill" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDobjectsObjects1[k] = gdjs.RoomsCode.GDobjectsObjects1[i];
        ++k;
    }
}
gdjs.RoomsCode.GDobjectsObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDobjectsObjects1.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDobjectsObjects1[i].getBehavior("Flippable").isFlippedX() ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDobjectsObjects1[k] = gdjs.RoomsCode.GDobjectsObjects1[i];
        ++k;
    }
}
gdjs.RoomsCode.GDobjectsObjects1.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.RoomsCode.GDobjectsObjects1 */
/* Reuse gdjs.RoomsCode.GDplayerObjects1 */
{for(var i = 0, len = gdjs.RoomsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDplayerObjects1[i].addForceTowardPosition((( gdjs.RoomsCode.GDobjectsObjects1.length === 0 ) ? 0 :gdjs.RoomsCode.GDobjectsObjects1[0].getPointX("")) + 500, (gdjs.RoomsCode.GDplayerObjects1[i].getPointY("")), 190, 0);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("exit"), gdjs.RoomsCode.GDexitObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects1Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDexitObjects1Objects, 64, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(1), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(4), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29694764);
}
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewBitmapText"), gdjs.RoomsCode.GDNewBitmapTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("task_bar"), gdjs.RoomsCode.GDtask_9595barObjects1);
{for(var i = 0, len = gdjs.RoomsCode.GDtask_9595barObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDtask_9595barObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.RoomsCode.GDNewBitmapTextObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDNewBitmapTextObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.RoomsCode.GDNewBitmapTextObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDNewBitmapTextObjects1[i].getBehavior("Text").setText("Exit?");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("charecters"), gdjs.RoomsCode.GDcharectersObjects1);
gdjs.copyArray(runtimeScene.getObjects("doors"), gdjs.RoomsCode.GDdoorsObjects1);
gdjs.copyArray(runtimeScene.getObjects("exit"), gdjs.RoomsCode.GDexitObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects1Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDexitObjects1Objects, 64, true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects1Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDdoorsObjects1Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects1Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcharectersObjects1Objects, 80, true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29696364);
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewBitmapText"), gdjs.RoomsCode.GDNewBitmapTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("task_bar"), gdjs.RoomsCode.GDtask_9595barObjects1);
{for(var i = 0, len = gdjs.RoomsCode.GDtask_9595barObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDtask_9595barObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.RoomsCode.GDNewBitmapTextObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDNewBitmapTextObjects1[i].hide();
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("exit"), gdjs.RoomsCode.GDexitObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects1);
gdjs.RoomsCode.GDE_9595buttonObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(4), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects1Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDexitObjects1Objects, 64, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDE_9595buttonObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects2);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDE_9595buttonObjects2.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDE_9595buttonObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDE_9595buttonObjects2[k] = gdjs.RoomsCode.GDE_9595buttonObjects2[i];
        ++k;
    }
}
gdjs.RoomsCode.GDE_9595buttonObjects2.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDE_9595buttonObjects2.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDE_9595buttonObjects1_1final.indexOf(gdjs.RoomsCode.GDE_9595buttonObjects2[j]) === -1 )
            gdjs.RoomsCode.GDE_9595buttonObjects1_1final.push(gdjs.RoomsCode.GDE_9595buttonObjects2[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDE_9595buttonObjects1_1final, gdjs.RoomsCode.GDE_9595buttonObjects1);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(1), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.dialogueTree.isRunning());
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Forgotten Garden");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29699364);
}
}
}
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("transition"), gdjs.RoomsCode.GDtransitionObjects1);
{for(var i = 0, len = gdjs.RoomsCode.GDtransitionObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDtransitionObjects1[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 0.2, "Flash", "Forward", 100, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.RoomsCode.eventsList5(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("collision"), gdjs.RoomsCode.GDcollisionObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcollisionObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDcollisionObjects1.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDcollisionObjects1[i].getVariableNumber(gdjs.RoomsCode.GDcollisionObjects1[i].getVariables().getFromIndex(0)) != 5 ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDcollisionObjects1[k] = gdjs.RoomsCode.GDcollisionObjects1[i];
        ++k;
    }
}
gdjs.RoomsCode.GDcollisionObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29700860);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.RoomsCode.GDcollisionObjects1 */
gdjs.copyArray(runtimeScene.getObjects("key_pad"), gdjs.RoomsCode.GDkey_9595padObjects1);
{for(var i = 0, len = gdjs.RoomsCode.GDkey_9595padObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDkey_9595padObjects1[i].getBehavior("Animation").setAnimationIndex(((gdjs.RoomsCode.GDcollisionObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.RoomsCode.GDcollisionObjects1[0].getVariables()).getFromIndex(0).getAsNumber() - 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("collision"), gdjs.RoomsCode.GDcollisionObjects1);
gdjs.copyArray(runtimeScene.getObjects("key_pad"), gdjs.RoomsCode.GDkey_9595padObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcollisionObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDcollisionObjects1.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDcollisionObjects1[i].getVariableNumber(gdjs.RoomsCode.GDcollisionObjects1[i].getVariables().getFromIndex(0)) == 5 ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDcollisionObjects1[k] = gdjs.RoomsCode.GDcollisionObjects1[i];
        ++k;
    }
}
gdjs.RoomsCode.GDcollisionObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) > (( gdjs.RoomsCode.GDkey_9595padObjects1.length === 0 ) ? 0 :gdjs.RoomsCode.GDkey_9595padObjects1[0].getBehavior("Animation").getAnimationIndex()) + 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29702516);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause"));
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Rooms"), gdjs.RoomsCode.GDRoomsObjects1);
/* Reuse gdjs.RoomsCode.GDcollisionObjects1 */
gdjs.copyArray(runtimeScene.getObjects("hitbox"), gdjs.RoomsCode.GDhitboxObjects1);
/* Reuse gdjs.RoomsCode.GDkey_9595padObjects1 */
gdjs.copyArray(runtimeScene.getObjects("key_pad2"), gdjs.RoomsCode.GDkey_9595pad2Objects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects1);
{for(var i = 0, len = gdjs.RoomsCode.GDcollisionObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDcollisionObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.RoomsCode.GDcollisionObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDcollisionObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.RoomsCode.GDcollisionObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDcollisionObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.RoomsCode.GDcollisionObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDcollisionObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.RoomsCode.GDcollisionObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDcollisionObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.RoomsCode.GDcollisionObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDcollisionObjects1[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber((( gdjs.RoomsCode.GDkey_9595padObjects1.length === 0 ) ? 0 :gdjs.RoomsCode.GDkey_9595padObjects1[0].getBehavior("Animation").getAnimationIndex()) + 1);
}{for(var i = 0, len = gdjs.RoomsCode.GDRoomsObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDRoomsObjects1[i].addForceTowardPosition((gdjs.RoomsCode.GDRoomsObjects1[i].getCenterXInScene()), 1000, 1200, 1);
}
}{for(var i = 0, len = gdjs.RoomsCode.GDhitboxObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDhitboxObjects1[i].addForceTowardPosition((gdjs.RoomsCode.GDhitboxObjects1[i].getCenterXInScene()), 1000, 1200, 1);
}
}{for(var i = 0, len = gdjs.RoomsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDplayerObjects1[i].addForceTowardPosition((gdjs.RoomsCode.GDplayerObjects1[i].getCenterXInScene()), 1000, 1200, 1);
}
}{for(var i = 0, len = gdjs.RoomsCode.GDkey_9595padObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDkey_9595padObjects1[i].addForceTowardPosition((gdjs.RoomsCode.GDkey_9595padObjects1[i].getCenterXInScene()), 1000, 1200, 1);
}
}{for(var i = 0, len = gdjs.RoomsCode.GDkey_9595pad2Objects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDkey_9595pad2Objects1[i].addForceTowardPosition((gdjs.RoomsCode.GDkey_9595pad2Objects1[i].getCenterXInScene()), 1000, 1200, 1);
}
}
{ //Subevents
gdjs.RoomsCode.eventsList7(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("collision"), gdjs.RoomsCode.GDcollisionObjects1);
gdjs.copyArray(runtimeScene.getObjects("key_pad"), gdjs.RoomsCode.GDkey_9595padObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcollisionObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDcollisionObjects1.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDcollisionObjects1[i].getVariableNumber(gdjs.RoomsCode.GDcollisionObjects1[i].getVariables().getFromIndex(0)) == 5 ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDcollisionObjects1[k] = gdjs.RoomsCode.GDcollisionObjects1[i];
        ++k;
    }
}
gdjs.RoomsCode.GDcollisionObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) < (( gdjs.RoomsCode.GDkey_9595padObjects1.length === 0 ) ? 0 :gdjs.RoomsCode.GDkey_9595padObjects1[0].getBehavior("Animation").getAnimationIndex()) + 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29706964);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause"));
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Rooms"), gdjs.RoomsCode.GDRoomsObjects1);
/* Reuse gdjs.RoomsCode.GDcollisionObjects1 */
gdjs.copyArray(runtimeScene.getObjects("hitbox"), gdjs.RoomsCode.GDhitboxObjects1);
/* Reuse gdjs.RoomsCode.GDkey_9595padObjects1 */
gdjs.copyArray(runtimeScene.getObjects("key_pad2"), gdjs.RoomsCode.GDkey_9595pad2Objects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects1);
{for(var i = 0, len = gdjs.RoomsCode.GDcollisionObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDcollisionObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.RoomsCode.GDcollisionObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDcollisionObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.RoomsCode.GDcollisionObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDcollisionObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.RoomsCode.GDcollisionObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDcollisionObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.RoomsCode.GDcollisionObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDcollisionObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.RoomsCode.GDcollisionObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDcollisionObjects1[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber((( gdjs.RoomsCode.GDkey_9595padObjects1.length === 0 ) ? 0 :gdjs.RoomsCode.GDkey_9595padObjects1[0].getBehavior("Animation").getAnimationIndex()) + 1);
}{for(var i = 0, len = gdjs.RoomsCode.GDRoomsObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDRoomsObjects1[i].addForceTowardPosition((gdjs.RoomsCode.GDRoomsObjects1[i].getCenterXInScene()), -(1000), 1200, 1);
}
}{for(var i = 0, len = gdjs.RoomsCode.GDhitboxObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDhitboxObjects1[i].addForceTowardPosition((gdjs.RoomsCode.GDhitboxObjects1[i].getCenterXInScene()), -(1000), 1200, 1);
}
}{for(var i = 0, len = gdjs.RoomsCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDplayerObjects1[i].addForceTowardPosition((gdjs.RoomsCode.GDplayerObjects1[i].getCenterXInScene()), -(1000), 1200, 1);
}
}{for(var i = 0, len = gdjs.RoomsCode.GDkey_9595padObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDkey_9595padObjects1[i].addForceTowardPosition((gdjs.RoomsCode.GDkey_9595padObjects1[i].getCenterXInScene()), -(1000), 1200, 1);
}
}{for(var i = 0, len = gdjs.RoomsCode.GDkey_9595pad2Objects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDkey_9595pad2Objects1[i].addForceTowardPosition((gdjs.RoomsCode.GDkey_9595pad2Objects1[i].getCenterXInScene()), -(1000), 1200, 1);
}
}
{ //Subevents
gdjs.RoomsCode.eventsList9(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("collision"), gdjs.RoomsCode.GDcollisionObjects1);
gdjs.copyArray(runtimeScene.getObjects("key_pad"), gdjs.RoomsCode.GDkey_9595padObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDcollisionObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDcollisionObjects1.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDcollisionObjects1[i].getVariableNumber(gdjs.RoomsCode.GDcollisionObjects1[i].getVariables().getFromIndex(0)) == 5 ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDcollisionObjects1[k] = gdjs.RoomsCode.GDcollisionObjects1[i];
        ++k;
    }
}
gdjs.RoomsCode.GDcollisionObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) == (( gdjs.RoomsCode.GDkey_9595padObjects1.length === 0 ) ? 0 :gdjs.RoomsCode.GDkey_9595padObjects1[0].getBehavior("Animation").getAnimationIndex()) + 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29711364);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause"));
}
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.RoomsCode.GDcollisionObjects1 */
gdjs.copyArray(runtimeScene.getObjects("transition"), gdjs.RoomsCode.GDtransitionObjects1);
{for(var i = 0, len = gdjs.RoomsCode.GDcollisionObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDcollisionObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.RoomsCode.GDcollisionObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDcollisionObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.RoomsCode.GDcollisionObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDcollisionObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.RoomsCode.GDcollisionObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDcollisionObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.RoomsCode.GDcollisionObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDcollisionObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.RoomsCode.GDcollisionObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDcollisionObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.RoomsCode.GDtransitionObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDtransitionObjects1[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 0.2, "Flash", "Forward", 100, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.RoomsCode.eventsList10(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NewBitmapText"), gdjs.RoomsCode.GDNewBitmapTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("collision"), gdjs.RoomsCode.GDcollisionObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("task_bar"), gdjs.RoomsCode.GDtask_9595barObjects1);
{for(var i = 0, len = gdjs.RoomsCode.GDcollisionObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDcollisionObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.RoomsCode.GDtask_9595barObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDtask_9595barObjects1[i].setPosition((( gdjs.RoomsCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.RoomsCode.GDplayerObjects1[0].getPointX("fly")) - 32,(( gdjs.RoomsCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.RoomsCode.GDplayerObjects1[0].getPointY("fly")) - 16);
}
}{for(var i = 0, len = gdjs.RoomsCode.GDNewBitmapTextObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDNewBitmapTextObjects1[i].setPosition((( gdjs.RoomsCode.GDtask_9595barObjects1.length === 0 ) ? 0 :gdjs.RoomsCode.GDtask_9595barObjects1[0].getCenterXInScene()) - 16,(( gdjs.RoomsCode.GDtask_9595barObjects1.length === 0 ) ? 0 :gdjs.RoomsCode.GDtask_9595barObjects1[0].getCenterYInScene()) - 4);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("doors"), gdjs.RoomsCode.GDdoorsObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Bathroom-2";
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects1Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDdoorsObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDdoorsObjects1.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDdoorsObjects1[i].getBehavior("Animation").getAnimationName() == "tear" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDdoorsObjects1[k] = gdjs.RoomsCode.GDdoorsObjects1[i];
        ++k;
    }
}
gdjs.RoomsCode.GDdoorsObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29715100);
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewBitmapText"), gdjs.RoomsCode.GDNewBitmapTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("task_bar"), gdjs.RoomsCode.GDtask_9595barObjects1);
{for(var i = 0, len = gdjs.RoomsCode.GDtask_9595barObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDtask_9595barObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.RoomsCode.GDNewBitmapTextObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDNewBitmapTextObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.RoomsCode.GDNewBitmapTextObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDNewBitmapTextObjects1[i].getBehavior("Text").setText("Enter?");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("doors"), gdjs.RoomsCode.GDdoorsObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Bathroom-3";
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects1Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDdoorsObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDdoorsObjects1.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDdoorsObjects1[i].getBehavior("Animation").getAnimationName() == "tear" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDdoorsObjects1[k] = gdjs.RoomsCode.GDdoorsObjects1[i];
        ++k;
    }
}
gdjs.RoomsCode.GDdoorsObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29714292);
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewBitmapText"), gdjs.RoomsCode.GDNewBitmapTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("task_bar"), gdjs.RoomsCode.GDtask_9595barObjects1);
{for(var i = 0, len = gdjs.RoomsCode.GDtask_9595barObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDtask_9595barObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.RoomsCode.GDNewBitmapTextObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDNewBitmapTextObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.RoomsCode.GDNewBitmapTextObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDNewBitmapTextObjects1[i].getBehavior("Text").setText("Enter?");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("doors"), gdjs.RoomsCode.GDdoorsObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects1);
gdjs.RoomsCode.GDE_9595buttonObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Bathroom-2";
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects1Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDdoorsObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDdoorsObjects1.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDdoorsObjects1[i].getBehavior("Animation").getAnimationName() == "tear" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDdoorsObjects1[k] = gdjs.RoomsCode.GDdoorsObjects1[i];
        ++k;
    }
}
gdjs.RoomsCode.GDdoorsObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDE_9595buttonObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects2);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDE_9595buttonObjects2.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDE_9595buttonObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDE_9595buttonObjects2[k] = gdjs.RoomsCode.GDE_9595buttonObjects2[i];
        ++k;
    }
}
gdjs.RoomsCode.GDE_9595buttonObjects2.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDE_9595buttonObjects2.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDE_9595buttonObjects1_1final.indexOf(gdjs.RoomsCode.GDE_9595buttonObjects2[j]) === -1 )
            gdjs.RoomsCode.GDE_9595buttonObjects1_1final.push(gdjs.RoomsCode.GDE_9595buttonObjects2[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDE_9595buttonObjects1_1final, gdjs.RoomsCode.GDE_9595buttonObjects1);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29719164);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause"));
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("transition"), gdjs.RoomsCode.GDtransitionObjects1);
{for(var i = 0, len = gdjs.RoomsCode.GDtransitionObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDtransitionObjects1[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 0.2, "Flash", "Forward", 100, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.RoomsCode.eventsList11(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("doors"), gdjs.RoomsCode.GDdoorsObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects1);
gdjs.RoomsCode.GDE_9595buttonObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Bathroom-3";
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects1Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDdoorsObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDdoorsObjects1.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDdoorsObjects1[i].getBehavior("Animation").getAnimationName() == "tear" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDdoorsObjects1[k] = gdjs.RoomsCode.GDdoorsObjects1[i];
        ++k;
    }
}
gdjs.RoomsCode.GDdoorsObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.RoomsCode.GDE_9595buttonObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("E_button"), gdjs.RoomsCode.GDE_9595buttonObjects2);
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDE_9595buttonObjects2.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDE_9595buttonObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.RoomsCode.GDE_9595buttonObjects2[k] = gdjs.RoomsCode.GDE_9595buttonObjects2[i];
        ++k;
    }
}
gdjs.RoomsCode.GDE_9595buttonObjects2.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.RoomsCode.GDE_9595buttonObjects2.length; j < jLen ; ++j) {
        if ( gdjs.RoomsCode.GDE_9595buttonObjects1_1final.indexOf(gdjs.RoomsCode.GDE_9595buttonObjects2[j]) === -1 )
            gdjs.RoomsCode.GDE_9595buttonObjects1_1final.push(gdjs.RoomsCode.GDE_9595buttonObjects2[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.RoomsCode.GDE_9595buttonObjects1_1final, gdjs.RoomsCode.GDE_9595buttonObjects1);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29722116);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "pause"));
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("transition"), gdjs.RoomsCode.GDtransitionObjects1);
{runtimeScene.getGame().getVariables().getFromIndex(0).setString("Bathroom-2");
}{for(var i = 0, len = gdjs.RoomsCode.GDtransitionObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDtransitionObjects1[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 0.2, "Flash", "Forward", 100, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.RoomsCode.eventsList12(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("doors"), gdjs.RoomsCode.GDdoorsObjects1);
gdjs.copyArray(runtimeScene.getObjects("exit"), gdjs.RoomsCode.GDexitObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Bathroom-2";
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects1Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDexitObjects1Objects, 64, true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects1Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDdoorsObjects1Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29724516);
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewBitmapText"), gdjs.RoomsCode.GDNewBitmapTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("task_bar"), gdjs.RoomsCode.GDtask_9595barObjects1);
{for(var i = 0, len = gdjs.RoomsCode.GDtask_9595barObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDtask_9595barObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.RoomsCode.GDNewBitmapTextObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDNewBitmapTextObjects1[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("doors"), gdjs.RoomsCode.GDdoorsObjects1);
gdjs.copyArray(runtimeScene.getObjects("exit"), gdjs.RoomsCode.GDexitObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Bathroom-3";
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects1Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDexitObjects1Objects, 64, true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects1Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDdoorsObjects1Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29725772);
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewBitmapText"), gdjs.RoomsCode.GDNewBitmapTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("task_bar"), gdjs.RoomsCode.GDtask_9595barObjects1);
{for(var i = 0, len = gdjs.RoomsCode.GDtask_9595barObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDtask_9595barObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.RoomsCode.GDNewBitmapTextObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDNewBitmapTextObjects1[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("objects"), gdjs.RoomsCode.GDobjectsObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Generator";
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects1Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDobjectsObjects1Objects, 64, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDobjectsObjects1.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDobjectsObjects1[i].getBehavior("Animation").getAnimationName() == "brokenmoniter" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDobjectsObjects1[k] = gdjs.RoomsCode.GDobjectsObjects1[i];
        ++k;
    }
}
gdjs.RoomsCode.GDobjectsObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(6).getChild("task"), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(0), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(6).getChild("misionstate"), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(1), false, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29727980);
}
}
}
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewBitmapText"), gdjs.RoomsCode.GDNewBitmapTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("task_bar"), gdjs.RoomsCode.GDtask_9595barObjects1);
{for(var i = 0, len = gdjs.RoomsCode.GDtask_9595barObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDtask_9595barObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.RoomsCode.GDNewBitmapTextObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDNewBitmapTextObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.RoomsCode.GDNewBitmapTextObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDNewBitmapTextObjects1[i].getBehavior("Text").setText("Upload");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("objects"), gdjs.RoomsCode.GDobjectsObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.RoomsCode.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Generator";
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDplayerObjects1Objects, gdjs.RoomsCode.mapOfGDgdjs_9546RoomsCode_9546GDobjectsObjects1Objects, 64, true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.RoomsCode.GDobjectsObjects1.length;i<l;++i) {
    if ( gdjs.RoomsCode.GDobjectsObjects1[i].getBehavior("Animation").getAnimationName() == "brokenmoniter" ) {
        isConditionTrue_0 = true;
        gdjs.RoomsCode.GDobjectsObjects1[k] = gdjs.RoomsCode.GDobjectsObjects1[i];
        ++k;
    }
}
gdjs.RoomsCode.GDobjectsObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(6).getChild("task"), true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(29729468);
}
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewBitmapText"), gdjs.RoomsCode.GDNewBitmapTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("task_bar"), gdjs.RoomsCode.GDtask_9595barObjects1);
{for(var i = 0, len = gdjs.RoomsCode.GDtask_9595barObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDtask_9595barObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.RoomsCode.GDNewBitmapTextObjects1.length ;i < len;++i) {
    gdjs.RoomsCode.GDNewBitmapTextObjects1[i].hide();
}
}}

}


{


gdjs.RoomsCode.eventsList13(runtimeScene);
}


{


gdjs.RoomsCode.eventsList34(runtimeScene);
}


{


gdjs.RoomsCode.eventsList35(runtimeScene);
}


{


gdjs.RoomsCode.eventsList37(runtimeScene);
}


{


gdjs.RoomsCode.eventsList43(runtimeScene);
}


{


gdjs.RoomsCode.eventsList44(runtimeScene);
}


{


gdjs.RoomsCode.eventsList46(runtimeScene);
}


{


gdjs.RoomsCode.eventsList47(runtimeScene);
}


{


gdjs.RoomsCode.eventsList49(runtimeScene);
}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.RoomsCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.RoomsCode.GDgrandpa_9595sObjects1.length = 0;
gdjs.RoomsCode.GDgrandpa_9595sObjects2.length = 0;
gdjs.RoomsCode.GDgrandpa_9595sObjects3.length = 0;
gdjs.RoomsCode.GDgrandpa_9595sObjects4.length = 0;
gdjs.RoomsCode.GDgrandpa_9595sObjects5.length = 0;
gdjs.RoomsCode.GDwallObjects1.length = 0;
gdjs.RoomsCode.GDwallObjects2.length = 0;
gdjs.RoomsCode.GDwallObjects3.length = 0;
gdjs.RoomsCode.GDwallObjects4.length = 0;
gdjs.RoomsCode.GDwallObjects5.length = 0;
gdjs.RoomsCode.GDRoomsObjects1.length = 0;
gdjs.RoomsCode.GDRoomsObjects2.length = 0;
gdjs.RoomsCode.GDRoomsObjects3.length = 0;
gdjs.RoomsCode.GDRoomsObjects4.length = 0;
gdjs.RoomsCode.GDRoomsObjects5.length = 0;
gdjs.RoomsCode.GDPixelFlameObjects1.length = 0;
gdjs.RoomsCode.GDPixelFlameObjects2.length = 0;
gdjs.RoomsCode.GDPixelFlameObjects3.length = 0;
gdjs.RoomsCode.GDPixelFlameObjects4.length = 0;
gdjs.RoomsCode.GDPixelFlameObjects5.length = 0;
gdjs.RoomsCode.GDPixelSmokeObjects1.length = 0;
gdjs.RoomsCode.GDPixelSmokeObjects2.length = 0;
gdjs.RoomsCode.GDPixelSmokeObjects3.length = 0;
gdjs.RoomsCode.GDPixelSmokeObjects4.length = 0;
gdjs.RoomsCode.GDPixelSmokeObjects5.length = 0;
gdjs.RoomsCode.GDfireObjects1.length = 0;
gdjs.RoomsCode.GDfireObjects2.length = 0;
gdjs.RoomsCode.GDfireObjects3.length = 0;
gdjs.RoomsCode.GDfireObjects4.length = 0;
gdjs.RoomsCode.GDfireObjects5.length = 0;
gdjs.RoomsCode.GDsmalllight2Objects1.length = 0;
gdjs.RoomsCode.GDsmalllight2Objects2.length = 0;
gdjs.RoomsCode.GDsmalllight2Objects3.length = 0;
gdjs.RoomsCode.GDsmalllight2Objects4.length = 0;
gdjs.RoomsCode.GDsmalllight2Objects5.length = 0;
gdjs.RoomsCode.GDkey_9595padObjects1.length = 0;
gdjs.RoomsCode.GDkey_9595padObjects2.length = 0;
gdjs.RoomsCode.GDkey_9595padObjects3.length = 0;
gdjs.RoomsCode.GDkey_9595padObjects4.length = 0;
gdjs.RoomsCode.GDkey_9595padObjects5.length = 0;
gdjs.RoomsCode.GDcollisionObjects1.length = 0;
gdjs.RoomsCode.GDcollisionObjects2.length = 0;
gdjs.RoomsCode.GDcollisionObjects3.length = 0;
gdjs.RoomsCode.GDcollisionObjects4.length = 0;
gdjs.RoomsCode.GDcollisionObjects5.length = 0;
gdjs.RoomsCode.GDkey_9595pad2Objects1.length = 0;
gdjs.RoomsCode.GDkey_9595pad2Objects2.length = 0;
gdjs.RoomsCode.GDkey_9595pad2Objects3.length = 0;
gdjs.RoomsCode.GDkey_9595pad2Objects4.length = 0;
gdjs.RoomsCode.GDkey_9595pad2Objects5.length = 0;
gdjs.RoomsCode.GDtransitionObjects1.length = 0;
gdjs.RoomsCode.GDtransitionObjects2.length = 0;
gdjs.RoomsCode.GDtransitionObjects3.length = 0;
gdjs.RoomsCode.GDtransitionObjects4.length = 0;
gdjs.RoomsCode.GDtransitionObjects5.length = 0;
gdjs.RoomsCode.GDexitObjects1.length = 0;
gdjs.RoomsCode.GDexitObjects2.length = 0;
gdjs.RoomsCode.GDexitObjects3.length = 0;
gdjs.RoomsCode.GDexitObjects4.length = 0;
gdjs.RoomsCode.GDexitObjects5.length = 0;
gdjs.RoomsCode.GDtext_9595boxObjects1.length = 0;
gdjs.RoomsCode.GDtext_9595boxObjects2.length = 0;
gdjs.RoomsCode.GDtext_9595boxObjects3.length = 0;
gdjs.RoomsCode.GDtext_9595boxObjects4.length = 0;
gdjs.RoomsCode.GDtext_9595boxObjects5.length = 0;
gdjs.RoomsCode.GDcharecters2Objects1.length = 0;
gdjs.RoomsCode.GDcharecters2Objects2.length = 0;
gdjs.RoomsCode.GDcharecters2Objects3.length = 0;
gdjs.RoomsCode.GDcharecters2Objects4.length = 0;
gdjs.RoomsCode.GDcharecters2Objects5.length = 0;
gdjs.RoomsCode.GDNameObjects1.length = 0;
gdjs.RoomsCode.GDNameObjects2.length = 0;
gdjs.RoomsCode.GDNameObjects3.length = 0;
gdjs.RoomsCode.GDNameObjects4.length = 0;
gdjs.RoomsCode.GDNameObjects5.length = 0;
gdjs.RoomsCode.GDDialogeObjects1.length = 0;
gdjs.RoomsCode.GDDialogeObjects2.length = 0;
gdjs.RoomsCode.GDDialogeObjects3.length = 0;
gdjs.RoomsCode.GDDialogeObjects4.length = 0;
gdjs.RoomsCode.GDDialogeObjects5.length = 0;
gdjs.RoomsCode.GDarrowObjects1.length = 0;
gdjs.RoomsCode.GDarrowObjects2.length = 0;
gdjs.RoomsCode.GDarrowObjects3.length = 0;
gdjs.RoomsCode.GDarrowObjects4.length = 0;
gdjs.RoomsCode.GDarrowObjects5.length = 0;
gdjs.RoomsCode.GDoptionsObjects1.length = 0;
gdjs.RoomsCode.GDoptionsObjects2.length = 0;
gdjs.RoomsCode.GDoptionsObjects3.length = 0;
gdjs.RoomsCode.GDoptionsObjects4.length = 0;
gdjs.RoomsCode.GDoptionsObjects5.length = 0;
gdjs.RoomsCode.GDtipObjects1.length = 0;
gdjs.RoomsCode.GDtipObjects2.length = 0;
gdjs.RoomsCode.GDtipObjects3.length = 0;
gdjs.RoomsCode.GDtipObjects4.length = 0;
gdjs.RoomsCode.GDtipObjects5.length = 0;
gdjs.RoomsCode.GDpasswordObjects1.length = 0;
gdjs.RoomsCode.GDpasswordObjects2.length = 0;
gdjs.RoomsCode.GDpasswordObjects3.length = 0;
gdjs.RoomsCode.GDpasswordObjects4.length = 0;
gdjs.RoomsCode.GDpasswordObjects5.length = 0;
gdjs.RoomsCode.GDopenObjects1.length = 0;
gdjs.RoomsCode.GDopenObjects2.length = 0;
gdjs.RoomsCode.GDopenObjects3.length = 0;
gdjs.RoomsCode.GDopenObjects4.length = 0;
gdjs.RoomsCode.GDopenObjects5.length = 0;
gdjs.RoomsCode.GDcloseObjects1.length = 0;
gdjs.RoomsCode.GDcloseObjects2.length = 0;
gdjs.RoomsCode.GDcloseObjects3.length = 0;
gdjs.RoomsCode.GDcloseObjects4.length = 0;
gdjs.RoomsCode.GDcloseObjects5.length = 0;
gdjs.RoomsCode.GDcountdownObjects1.length = 0;
gdjs.RoomsCode.GDcountdownObjects2.length = 0;
gdjs.RoomsCode.GDcountdownObjects3.length = 0;
gdjs.RoomsCode.GDcountdownObjects4.length = 0;
gdjs.RoomsCode.GDcountdownObjects5.length = 0;
gdjs.RoomsCode.GDtip2Objects1.length = 0;
gdjs.RoomsCode.GDtip2Objects2.length = 0;
gdjs.RoomsCode.GDtip2Objects3.length = 0;
gdjs.RoomsCode.GDtip2Objects4.length = 0;
gdjs.RoomsCode.GDtip2Objects5.length = 0;
gdjs.RoomsCode.GDred_9595greenObjects1.length = 0;
gdjs.RoomsCode.GDred_9595greenObjects2.length = 0;
gdjs.RoomsCode.GDred_9595greenObjects3.length = 0;
gdjs.RoomsCode.GDred_9595greenObjects4.length = 0;
gdjs.RoomsCode.GDred_9595greenObjects5.length = 0;
gdjs.RoomsCode.GDtip3Objects1.length = 0;
gdjs.RoomsCode.GDtip3Objects2.length = 0;
gdjs.RoomsCode.GDtip3Objects3.length = 0;
gdjs.RoomsCode.GDtip3Objects4.length = 0;
gdjs.RoomsCode.GDtip3Objects5.length = 0;
gdjs.RoomsCode.GDobjects2Objects1.length = 0;
gdjs.RoomsCode.GDobjects2Objects2.length = 0;
gdjs.RoomsCode.GDobjects2Objects3.length = 0;
gdjs.RoomsCode.GDobjects2Objects4.length = 0;
gdjs.RoomsCode.GDobjects2Objects5.length = 0;
gdjs.RoomsCode.GDWallObjects1.length = 0;
gdjs.RoomsCode.GDWallObjects2.length = 0;
gdjs.RoomsCode.GDWallObjects3.length = 0;
gdjs.RoomsCode.GDWallObjects4.length = 0;
gdjs.RoomsCode.GDWallObjects5.length = 0;
gdjs.RoomsCode.GDfloorObjects1.length = 0;
gdjs.RoomsCode.GDfloorObjects2.length = 0;
gdjs.RoomsCode.GDfloorObjects3.length = 0;
gdjs.RoomsCode.GDfloorObjects4.length = 0;
gdjs.RoomsCode.GDfloorObjects5.length = 0;
gdjs.RoomsCode.GDdoorsObjects1.length = 0;
gdjs.RoomsCode.GDdoorsObjects2.length = 0;
gdjs.RoomsCode.GDdoorsObjects3.length = 0;
gdjs.RoomsCode.GDdoorsObjects4.length = 0;
gdjs.RoomsCode.GDdoorsObjects5.length = 0;
gdjs.RoomsCode.GDobjectsObjects1.length = 0;
gdjs.RoomsCode.GDobjectsObjects2.length = 0;
gdjs.RoomsCode.GDobjectsObjects3.length = 0;
gdjs.RoomsCode.GDobjectsObjects4.length = 0;
gdjs.RoomsCode.GDobjectsObjects5.length = 0;
gdjs.RoomsCode.GDwallobjectObjects1.length = 0;
gdjs.RoomsCode.GDwallobjectObjects2.length = 0;
gdjs.RoomsCode.GDwallobjectObjects3.length = 0;
gdjs.RoomsCode.GDwallobjectObjects4.length = 0;
gdjs.RoomsCode.GDwallobjectObjects5.length = 0;
gdjs.RoomsCode.GDwindowObjects1.length = 0;
gdjs.RoomsCode.GDwindowObjects2.length = 0;
gdjs.RoomsCode.GDwindowObjects3.length = 0;
gdjs.RoomsCode.GDwindowObjects4.length = 0;
gdjs.RoomsCode.GDwindowObjects5.length = 0;
gdjs.RoomsCode.GDrailObjects1.length = 0;
gdjs.RoomsCode.GDrailObjects2.length = 0;
gdjs.RoomsCode.GDrailObjects3.length = 0;
gdjs.RoomsCode.GDrailObjects4.length = 0;
gdjs.RoomsCode.GDrailObjects5.length = 0;
gdjs.RoomsCode.GDplayerObjects1.length = 0;
gdjs.RoomsCode.GDplayerObjects2.length = 0;
gdjs.RoomsCode.GDplayerObjects3.length = 0;
gdjs.RoomsCode.GDplayerObjects4.length = 0;
gdjs.RoomsCode.GDplayerObjects5.length = 0;
gdjs.RoomsCode.GDhitboxObjects1.length = 0;
gdjs.RoomsCode.GDhitboxObjects2.length = 0;
gdjs.RoomsCode.GDhitboxObjects3.length = 0;
gdjs.RoomsCode.GDhitboxObjects4.length = 0;
gdjs.RoomsCode.GDhitboxObjects5.length = 0;
gdjs.RoomsCode.GDMainlightObjects1.length = 0;
gdjs.RoomsCode.GDMainlightObjects2.length = 0;
gdjs.RoomsCode.GDMainlightObjects3.length = 0;
gdjs.RoomsCode.GDMainlightObjects4.length = 0;
gdjs.RoomsCode.GDMainlightObjects5.length = 0;
gdjs.RoomsCode.GDsmalllightObjects1.length = 0;
gdjs.RoomsCode.GDsmalllightObjects2.length = 0;
gdjs.RoomsCode.GDsmalllightObjects3.length = 0;
gdjs.RoomsCode.GDsmalllightObjects4.length = 0;
gdjs.RoomsCode.GDsmalllightObjects5.length = 0;
gdjs.RoomsCode.GDNewBitmapTextObjects1.length = 0;
gdjs.RoomsCode.GDNewBitmapTextObjects2.length = 0;
gdjs.RoomsCode.GDNewBitmapTextObjects3.length = 0;
gdjs.RoomsCode.GDNewBitmapTextObjects4.length = 0;
gdjs.RoomsCode.GDNewBitmapTextObjects5.length = 0;
gdjs.RoomsCode.GDtask_9595barObjects1.length = 0;
gdjs.RoomsCode.GDtask_9595barObjects2.length = 0;
gdjs.RoomsCode.GDtask_9595barObjects3.length = 0;
gdjs.RoomsCode.GDtask_9595barObjects4.length = 0;
gdjs.RoomsCode.GDtask_9595barObjects5.length = 0;
gdjs.RoomsCode.GDcharectersObjects1.length = 0;
gdjs.RoomsCode.GDcharectersObjects2.length = 0;
gdjs.RoomsCode.GDcharectersObjects3.length = 0;
gdjs.RoomsCode.GDcharectersObjects4.length = 0;
gdjs.RoomsCode.GDcharectersObjects5.length = 0;
gdjs.RoomsCode.GDcharecters22Objects1.length = 0;
gdjs.RoomsCode.GDcharecters22Objects2.length = 0;
gdjs.RoomsCode.GDcharecters22Objects3.length = 0;
gdjs.RoomsCode.GDcharecters22Objects4.length = 0;
gdjs.RoomsCode.GDcharecters22Objects5.length = 0;
gdjs.RoomsCode.GDPauseObjects1.length = 0;
gdjs.RoomsCode.GDPauseObjects2.length = 0;
gdjs.RoomsCode.GDPauseObjects3.length = 0;
gdjs.RoomsCode.GDPauseObjects4.length = 0;
gdjs.RoomsCode.GDPauseObjects5.length = 0;
gdjs.RoomsCode.GDresumeObjects1.length = 0;
gdjs.RoomsCode.GDresumeObjects2.length = 0;
gdjs.RoomsCode.GDresumeObjects3.length = 0;
gdjs.RoomsCode.GDresumeObjects4.length = 0;
gdjs.RoomsCode.GDresumeObjects5.length = 0;
gdjs.RoomsCode.GDQuit_95952Objects1.length = 0;
gdjs.RoomsCode.GDQuit_95952Objects2.length = 0;
gdjs.RoomsCode.GDQuit_95952Objects3.length = 0;
gdjs.RoomsCode.GDQuit_95952Objects4.length = 0;
gdjs.RoomsCode.GDQuit_95952Objects5.length = 0;
gdjs.RoomsCode.GDpause_9595menuObjects1.length = 0;
gdjs.RoomsCode.GDpause_9595menuObjects2.length = 0;
gdjs.RoomsCode.GDpause_9595menuObjects3.length = 0;
gdjs.RoomsCode.GDpause_9595menuObjects4.length = 0;
gdjs.RoomsCode.GDpause_9595menuObjects5.length = 0;
gdjs.RoomsCode.GDHimaObjects1.length = 0;
gdjs.RoomsCode.GDHimaObjects2.length = 0;
gdjs.RoomsCode.GDHimaObjects3.length = 0;
gdjs.RoomsCode.GDHimaObjects4.length = 0;
gdjs.RoomsCode.GDHimaObjects5.length = 0;
gdjs.RoomsCode.GDLayaObjects1.length = 0;
gdjs.RoomsCode.GDLayaObjects2.length = 0;
gdjs.RoomsCode.GDLayaObjects3.length = 0;
gdjs.RoomsCode.GDLayaObjects4.length = 0;
gdjs.RoomsCode.GDLayaObjects5.length = 0;
gdjs.RoomsCode.GDJoystickObjects1.length = 0;
gdjs.RoomsCode.GDJoystickObjects2.length = 0;
gdjs.RoomsCode.GDJoystickObjects3.length = 0;
gdjs.RoomsCode.GDJoystickObjects4.length = 0;
gdjs.RoomsCode.GDJoystickObjects5.length = 0;
gdjs.RoomsCode.GDE_9595buttonObjects1.length = 0;
gdjs.RoomsCode.GDE_9595buttonObjects2.length = 0;
gdjs.RoomsCode.GDE_9595buttonObjects3.length = 0;
gdjs.RoomsCode.GDE_9595buttonObjects4.length = 0;
gdjs.RoomsCode.GDE_9595buttonObjects5.length = 0;

gdjs.RoomsCode.eventsList50(runtimeScene);
gdjs.RoomsCode.GDgrandpa_9595sObjects1.length = 0;
gdjs.RoomsCode.GDgrandpa_9595sObjects2.length = 0;
gdjs.RoomsCode.GDgrandpa_9595sObjects3.length = 0;
gdjs.RoomsCode.GDgrandpa_9595sObjects4.length = 0;
gdjs.RoomsCode.GDgrandpa_9595sObjects5.length = 0;
gdjs.RoomsCode.GDwallObjects1.length = 0;
gdjs.RoomsCode.GDwallObjects2.length = 0;
gdjs.RoomsCode.GDwallObjects3.length = 0;
gdjs.RoomsCode.GDwallObjects4.length = 0;
gdjs.RoomsCode.GDwallObjects5.length = 0;
gdjs.RoomsCode.GDRoomsObjects1.length = 0;
gdjs.RoomsCode.GDRoomsObjects2.length = 0;
gdjs.RoomsCode.GDRoomsObjects3.length = 0;
gdjs.RoomsCode.GDRoomsObjects4.length = 0;
gdjs.RoomsCode.GDRoomsObjects5.length = 0;
gdjs.RoomsCode.GDPixelFlameObjects1.length = 0;
gdjs.RoomsCode.GDPixelFlameObjects2.length = 0;
gdjs.RoomsCode.GDPixelFlameObjects3.length = 0;
gdjs.RoomsCode.GDPixelFlameObjects4.length = 0;
gdjs.RoomsCode.GDPixelFlameObjects5.length = 0;
gdjs.RoomsCode.GDPixelSmokeObjects1.length = 0;
gdjs.RoomsCode.GDPixelSmokeObjects2.length = 0;
gdjs.RoomsCode.GDPixelSmokeObjects3.length = 0;
gdjs.RoomsCode.GDPixelSmokeObjects4.length = 0;
gdjs.RoomsCode.GDPixelSmokeObjects5.length = 0;
gdjs.RoomsCode.GDfireObjects1.length = 0;
gdjs.RoomsCode.GDfireObjects2.length = 0;
gdjs.RoomsCode.GDfireObjects3.length = 0;
gdjs.RoomsCode.GDfireObjects4.length = 0;
gdjs.RoomsCode.GDfireObjects5.length = 0;
gdjs.RoomsCode.GDsmalllight2Objects1.length = 0;
gdjs.RoomsCode.GDsmalllight2Objects2.length = 0;
gdjs.RoomsCode.GDsmalllight2Objects3.length = 0;
gdjs.RoomsCode.GDsmalllight2Objects4.length = 0;
gdjs.RoomsCode.GDsmalllight2Objects5.length = 0;
gdjs.RoomsCode.GDkey_9595padObjects1.length = 0;
gdjs.RoomsCode.GDkey_9595padObjects2.length = 0;
gdjs.RoomsCode.GDkey_9595padObjects3.length = 0;
gdjs.RoomsCode.GDkey_9595padObjects4.length = 0;
gdjs.RoomsCode.GDkey_9595padObjects5.length = 0;
gdjs.RoomsCode.GDcollisionObjects1.length = 0;
gdjs.RoomsCode.GDcollisionObjects2.length = 0;
gdjs.RoomsCode.GDcollisionObjects3.length = 0;
gdjs.RoomsCode.GDcollisionObjects4.length = 0;
gdjs.RoomsCode.GDcollisionObjects5.length = 0;
gdjs.RoomsCode.GDkey_9595pad2Objects1.length = 0;
gdjs.RoomsCode.GDkey_9595pad2Objects2.length = 0;
gdjs.RoomsCode.GDkey_9595pad2Objects3.length = 0;
gdjs.RoomsCode.GDkey_9595pad2Objects4.length = 0;
gdjs.RoomsCode.GDkey_9595pad2Objects5.length = 0;
gdjs.RoomsCode.GDtransitionObjects1.length = 0;
gdjs.RoomsCode.GDtransitionObjects2.length = 0;
gdjs.RoomsCode.GDtransitionObjects3.length = 0;
gdjs.RoomsCode.GDtransitionObjects4.length = 0;
gdjs.RoomsCode.GDtransitionObjects5.length = 0;
gdjs.RoomsCode.GDexitObjects1.length = 0;
gdjs.RoomsCode.GDexitObjects2.length = 0;
gdjs.RoomsCode.GDexitObjects3.length = 0;
gdjs.RoomsCode.GDexitObjects4.length = 0;
gdjs.RoomsCode.GDexitObjects5.length = 0;
gdjs.RoomsCode.GDtext_9595boxObjects1.length = 0;
gdjs.RoomsCode.GDtext_9595boxObjects2.length = 0;
gdjs.RoomsCode.GDtext_9595boxObjects3.length = 0;
gdjs.RoomsCode.GDtext_9595boxObjects4.length = 0;
gdjs.RoomsCode.GDtext_9595boxObjects5.length = 0;
gdjs.RoomsCode.GDcharecters2Objects1.length = 0;
gdjs.RoomsCode.GDcharecters2Objects2.length = 0;
gdjs.RoomsCode.GDcharecters2Objects3.length = 0;
gdjs.RoomsCode.GDcharecters2Objects4.length = 0;
gdjs.RoomsCode.GDcharecters2Objects5.length = 0;
gdjs.RoomsCode.GDNameObjects1.length = 0;
gdjs.RoomsCode.GDNameObjects2.length = 0;
gdjs.RoomsCode.GDNameObjects3.length = 0;
gdjs.RoomsCode.GDNameObjects4.length = 0;
gdjs.RoomsCode.GDNameObjects5.length = 0;
gdjs.RoomsCode.GDDialogeObjects1.length = 0;
gdjs.RoomsCode.GDDialogeObjects2.length = 0;
gdjs.RoomsCode.GDDialogeObjects3.length = 0;
gdjs.RoomsCode.GDDialogeObjects4.length = 0;
gdjs.RoomsCode.GDDialogeObjects5.length = 0;
gdjs.RoomsCode.GDarrowObjects1.length = 0;
gdjs.RoomsCode.GDarrowObjects2.length = 0;
gdjs.RoomsCode.GDarrowObjects3.length = 0;
gdjs.RoomsCode.GDarrowObjects4.length = 0;
gdjs.RoomsCode.GDarrowObjects5.length = 0;
gdjs.RoomsCode.GDoptionsObjects1.length = 0;
gdjs.RoomsCode.GDoptionsObjects2.length = 0;
gdjs.RoomsCode.GDoptionsObjects3.length = 0;
gdjs.RoomsCode.GDoptionsObjects4.length = 0;
gdjs.RoomsCode.GDoptionsObjects5.length = 0;
gdjs.RoomsCode.GDtipObjects1.length = 0;
gdjs.RoomsCode.GDtipObjects2.length = 0;
gdjs.RoomsCode.GDtipObjects3.length = 0;
gdjs.RoomsCode.GDtipObjects4.length = 0;
gdjs.RoomsCode.GDtipObjects5.length = 0;
gdjs.RoomsCode.GDpasswordObjects1.length = 0;
gdjs.RoomsCode.GDpasswordObjects2.length = 0;
gdjs.RoomsCode.GDpasswordObjects3.length = 0;
gdjs.RoomsCode.GDpasswordObjects4.length = 0;
gdjs.RoomsCode.GDpasswordObjects5.length = 0;
gdjs.RoomsCode.GDopenObjects1.length = 0;
gdjs.RoomsCode.GDopenObjects2.length = 0;
gdjs.RoomsCode.GDopenObjects3.length = 0;
gdjs.RoomsCode.GDopenObjects4.length = 0;
gdjs.RoomsCode.GDopenObjects5.length = 0;
gdjs.RoomsCode.GDcloseObjects1.length = 0;
gdjs.RoomsCode.GDcloseObjects2.length = 0;
gdjs.RoomsCode.GDcloseObjects3.length = 0;
gdjs.RoomsCode.GDcloseObjects4.length = 0;
gdjs.RoomsCode.GDcloseObjects5.length = 0;
gdjs.RoomsCode.GDcountdownObjects1.length = 0;
gdjs.RoomsCode.GDcountdownObjects2.length = 0;
gdjs.RoomsCode.GDcountdownObjects3.length = 0;
gdjs.RoomsCode.GDcountdownObjects4.length = 0;
gdjs.RoomsCode.GDcountdownObjects5.length = 0;
gdjs.RoomsCode.GDtip2Objects1.length = 0;
gdjs.RoomsCode.GDtip2Objects2.length = 0;
gdjs.RoomsCode.GDtip2Objects3.length = 0;
gdjs.RoomsCode.GDtip2Objects4.length = 0;
gdjs.RoomsCode.GDtip2Objects5.length = 0;
gdjs.RoomsCode.GDred_9595greenObjects1.length = 0;
gdjs.RoomsCode.GDred_9595greenObjects2.length = 0;
gdjs.RoomsCode.GDred_9595greenObjects3.length = 0;
gdjs.RoomsCode.GDred_9595greenObjects4.length = 0;
gdjs.RoomsCode.GDred_9595greenObjects5.length = 0;
gdjs.RoomsCode.GDtip3Objects1.length = 0;
gdjs.RoomsCode.GDtip3Objects2.length = 0;
gdjs.RoomsCode.GDtip3Objects3.length = 0;
gdjs.RoomsCode.GDtip3Objects4.length = 0;
gdjs.RoomsCode.GDtip3Objects5.length = 0;
gdjs.RoomsCode.GDobjects2Objects1.length = 0;
gdjs.RoomsCode.GDobjects2Objects2.length = 0;
gdjs.RoomsCode.GDobjects2Objects3.length = 0;
gdjs.RoomsCode.GDobjects2Objects4.length = 0;
gdjs.RoomsCode.GDobjects2Objects5.length = 0;
gdjs.RoomsCode.GDWallObjects1.length = 0;
gdjs.RoomsCode.GDWallObjects2.length = 0;
gdjs.RoomsCode.GDWallObjects3.length = 0;
gdjs.RoomsCode.GDWallObjects4.length = 0;
gdjs.RoomsCode.GDWallObjects5.length = 0;
gdjs.RoomsCode.GDfloorObjects1.length = 0;
gdjs.RoomsCode.GDfloorObjects2.length = 0;
gdjs.RoomsCode.GDfloorObjects3.length = 0;
gdjs.RoomsCode.GDfloorObjects4.length = 0;
gdjs.RoomsCode.GDfloorObjects5.length = 0;
gdjs.RoomsCode.GDdoorsObjects1.length = 0;
gdjs.RoomsCode.GDdoorsObjects2.length = 0;
gdjs.RoomsCode.GDdoorsObjects3.length = 0;
gdjs.RoomsCode.GDdoorsObjects4.length = 0;
gdjs.RoomsCode.GDdoorsObjects5.length = 0;
gdjs.RoomsCode.GDobjectsObjects1.length = 0;
gdjs.RoomsCode.GDobjectsObjects2.length = 0;
gdjs.RoomsCode.GDobjectsObjects3.length = 0;
gdjs.RoomsCode.GDobjectsObjects4.length = 0;
gdjs.RoomsCode.GDobjectsObjects5.length = 0;
gdjs.RoomsCode.GDwallobjectObjects1.length = 0;
gdjs.RoomsCode.GDwallobjectObjects2.length = 0;
gdjs.RoomsCode.GDwallobjectObjects3.length = 0;
gdjs.RoomsCode.GDwallobjectObjects4.length = 0;
gdjs.RoomsCode.GDwallobjectObjects5.length = 0;
gdjs.RoomsCode.GDwindowObjects1.length = 0;
gdjs.RoomsCode.GDwindowObjects2.length = 0;
gdjs.RoomsCode.GDwindowObjects3.length = 0;
gdjs.RoomsCode.GDwindowObjects4.length = 0;
gdjs.RoomsCode.GDwindowObjects5.length = 0;
gdjs.RoomsCode.GDrailObjects1.length = 0;
gdjs.RoomsCode.GDrailObjects2.length = 0;
gdjs.RoomsCode.GDrailObjects3.length = 0;
gdjs.RoomsCode.GDrailObjects4.length = 0;
gdjs.RoomsCode.GDrailObjects5.length = 0;
gdjs.RoomsCode.GDplayerObjects1.length = 0;
gdjs.RoomsCode.GDplayerObjects2.length = 0;
gdjs.RoomsCode.GDplayerObjects3.length = 0;
gdjs.RoomsCode.GDplayerObjects4.length = 0;
gdjs.RoomsCode.GDplayerObjects5.length = 0;
gdjs.RoomsCode.GDhitboxObjects1.length = 0;
gdjs.RoomsCode.GDhitboxObjects2.length = 0;
gdjs.RoomsCode.GDhitboxObjects3.length = 0;
gdjs.RoomsCode.GDhitboxObjects4.length = 0;
gdjs.RoomsCode.GDhitboxObjects5.length = 0;
gdjs.RoomsCode.GDMainlightObjects1.length = 0;
gdjs.RoomsCode.GDMainlightObjects2.length = 0;
gdjs.RoomsCode.GDMainlightObjects3.length = 0;
gdjs.RoomsCode.GDMainlightObjects4.length = 0;
gdjs.RoomsCode.GDMainlightObjects5.length = 0;
gdjs.RoomsCode.GDsmalllightObjects1.length = 0;
gdjs.RoomsCode.GDsmalllightObjects2.length = 0;
gdjs.RoomsCode.GDsmalllightObjects3.length = 0;
gdjs.RoomsCode.GDsmalllightObjects4.length = 0;
gdjs.RoomsCode.GDsmalllightObjects5.length = 0;
gdjs.RoomsCode.GDNewBitmapTextObjects1.length = 0;
gdjs.RoomsCode.GDNewBitmapTextObjects2.length = 0;
gdjs.RoomsCode.GDNewBitmapTextObjects3.length = 0;
gdjs.RoomsCode.GDNewBitmapTextObjects4.length = 0;
gdjs.RoomsCode.GDNewBitmapTextObjects5.length = 0;
gdjs.RoomsCode.GDtask_9595barObjects1.length = 0;
gdjs.RoomsCode.GDtask_9595barObjects2.length = 0;
gdjs.RoomsCode.GDtask_9595barObjects3.length = 0;
gdjs.RoomsCode.GDtask_9595barObjects4.length = 0;
gdjs.RoomsCode.GDtask_9595barObjects5.length = 0;
gdjs.RoomsCode.GDcharectersObjects1.length = 0;
gdjs.RoomsCode.GDcharectersObjects2.length = 0;
gdjs.RoomsCode.GDcharectersObjects3.length = 0;
gdjs.RoomsCode.GDcharectersObjects4.length = 0;
gdjs.RoomsCode.GDcharectersObjects5.length = 0;
gdjs.RoomsCode.GDcharecters22Objects1.length = 0;
gdjs.RoomsCode.GDcharecters22Objects2.length = 0;
gdjs.RoomsCode.GDcharecters22Objects3.length = 0;
gdjs.RoomsCode.GDcharecters22Objects4.length = 0;
gdjs.RoomsCode.GDcharecters22Objects5.length = 0;
gdjs.RoomsCode.GDPauseObjects1.length = 0;
gdjs.RoomsCode.GDPauseObjects2.length = 0;
gdjs.RoomsCode.GDPauseObjects3.length = 0;
gdjs.RoomsCode.GDPauseObjects4.length = 0;
gdjs.RoomsCode.GDPauseObjects5.length = 0;
gdjs.RoomsCode.GDresumeObjects1.length = 0;
gdjs.RoomsCode.GDresumeObjects2.length = 0;
gdjs.RoomsCode.GDresumeObjects3.length = 0;
gdjs.RoomsCode.GDresumeObjects4.length = 0;
gdjs.RoomsCode.GDresumeObjects5.length = 0;
gdjs.RoomsCode.GDQuit_95952Objects1.length = 0;
gdjs.RoomsCode.GDQuit_95952Objects2.length = 0;
gdjs.RoomsCode.GDQuit_95952Objects3.length = 0;
gdjs.RoomsCode.GDQuit_95952Objects4.length = 0;
gdjs.RoomsCode.GDQuit_95952Objects5.length = 0;
gdjs.RoomsCode.GDpause_9595menuObjects1.length = 0;
gdjs.RoomsCode.GDpause_9595menuObjects2.length = 0;
gdjs.RoomsCode.GDpause_9595menuObjects3.length = 0;
gdjs.RoomsCode.GDpause_9595menuObjects4.length = 0;
gdjs.RoomsCode.GDpause_9595menuObjects5.length = 0;
gdjs.RoomsCode.GDHimaObjects1.length = 0;
gdjs.RoomsCode.GDHimaObjects2.length = 0;
gdjs.RoomsCode.GDHimaObjects3.length = 0;
gdjs.RoomsCode.GDHimaObjects4.length = 0;
gdjs.RoomsCode.GDHimaObjects5.length = 0;
gdjs.RoomsCode.GDLayaObjects1.length = 0;
gdjs.RoomsCode.GDLayaObjects2.length = 0;
gdjs.RoomsCode.GDLayaObjects3.length = 0;
gdjs.RoomsCode.GDLayaObjects4.length = 0;
gdjs.RoomsCode.GDLayaObjects5.length = 0;
gdjs.RoomsCode.GDJoystickObjects1.length = 0;
gdjs.RoomsCode.GDJoystickObjects2.length = 0;
gdjs.RoomsCode.GDJoystickObjects3.length = 0;
gdjs.RoomsCode.GDJoystickObjects4.length = 0;
gdjs.RoomsCode.GDJoystickObjects5.length = 0;
gdjs.RoomsCode.GDE_9595buttonObjects1.length = 0;
gdjs.RoomsCode.GDE_9595buttonObjects2.length = 0;
gdjs.RoomsCode.GDE_9595buttonObjects3.length = 0;
gdjs.RoomsCode.GDE_9595buttonObjects4.length = 0;
gdjs.RoomsCode.GDE_9595buttonObjects5.length = 0;


return;

}

gdjs['RoomsCode'] = gdjs.RoomsCode;
