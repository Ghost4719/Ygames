gdjs.diedCode = {};
gdjs.diedCode.localVariables = [];
gdjs.diedCode.GDWallObjects1= [];
gdjs.diedCode.GDWallObjects2= [];
gdjs.diedCode.GDfloorObjects1= [];
gdjs.diedCode.GDfloorObjects2= [];
gdjs.diedCode.GDdoorsObjects1= [];
gdjs.diedCode.GDdoorsObjects2= [];
gdjs.diedCode.GDobjectsObjects1= [];
gdjs.diedCode.GDobjectsObjects2= [];
gdjs.diedCode.GDwallobjectObjects1= [];
gdjs.diedCode.GDwallobjectObjects2= [];
gdjs.diedCode.GDwindowObjects1= [];
gdjs.diedCode.GDwindowObjects2= [];
gdjs.diedCode.GDrailObjects1= [];
gdjs.diedCode.GDrailObjects2= [];
gdjs.diedCode.GDplayerObjects1= [];
gdjs.diedCode.GDplayerObjects2= [];
gdjs.diedCode.GDhitboxObjects1= [];
gdjs.diedCode.GDhitboxObjects2= [];
gdjs.diedCode.GDMainlightObjects1= [];
gdjs.diedCode.GDMainlightObjects2= [];
gdjs.diedCode.GDsmalllightObjects1= [];
gdjs.diedCode.GDsmalllightObjects2= [];
gdjs.diedCode.GDNewBitmapTextObjects1= [];
gdjs.diedCode.GDNewBitmapTextObjects2= [];
gdjs.diedCode.GDtask_9595barObjects1= [];
gdjs.diedCode.GDtask_9595barObjects2= [];
gdjs.diedCode.GDcharectersObjects1= [];
gdjs.diedCode.GDcharectersObjects2= [];
gdjs.diedCode.GDcharecters22Objects1= [];
gdjs.diedCode.GDcharecters22Objects2= [];
gdjs.diedCode.GDPauseObjects1= [];
gdjs.diedCode.GDPauseObjects2= [];
gdjs.diedCode.GDresumeObjects1= [];
gdjs.diedCode.GDresumeObjects2= [];
gdjs.diedCode.GDQuit_95952Objects1= [];
gdjs.diedCode.GDQuit_95952Objects2= [];
gdjs.diedCode.GDpause_9595menuObjects1= [];
gdjs.diedCode.GDpause_9595menuObjects2= [];
gdjs.diedCode.GDHimaObjects1= [];
gdjs.diedCode.GDHimaObjects2= [];
gdjs.diedCode.GDLayaObjects1= [];
gdjs.diedCode.GDLayaObjects2= [];
gdjs.diedCode.GDJoystickObjects1= [];
gdjs.diedCode.GDJoystickObjects2= [];
gdjs.diedCode.GDE_9595buttonObjects1= [];
gdjs.diedCode.GDE_9595buttonObjects2= [];


gdjs.diedCode.asyncCallback30174924 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.diedCode.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Main Menu", false);
}gdjs.diedCode.localVariables.length = 0;
}
gdjs.diedCode.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.diedCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.diedCode.asyncCallback30174924(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.diedCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Hima"), gdjs.diedCode.GDHimaObjects1);
{gdjs.evtTools.sound.playSound(runtimeScene, "horror-jump-scare-sound-effect-1-241498(1)2.mp3", false, 100, 1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "squeaky-jumpscare-2-102254(1).mp3", false, 100, 1);
}{for(var i = 0, len = gdjs.diedCode.GDHimaObjects1.length ;i < len;++i) {
    gdjs.diedCode.GDHimaObjects1[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(2, 20, 20, 20, 10, 0.08, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.diedCode.eventsList0(runtimeScene);} //End of subevents
}

}


};

gdjs.diedCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.diedCode.GDWallObjects1.length = 0;
gdjs.diedCode.GDWallObjects2.length = 0;
gdjs.diedCode.GDfloorObjects1.length = 0;
gdjs.diedCode.GDfloorObjects2.length = 0;
gdjs.diedCode.GDdoorsObjects1.length = 0;
gdjs.diedCode.GDdoorsObjects2.length = 0;
gdjs.diedCode.GDobjectsObjects1.length = 0;
gdjs.diedCode.GDobjectsObjects2.length = 0;
gdjs.diedCode.GDwallobjectObjects1.length = 0;
gdjs.diedCode.GDwallobjectObjects2.length = 0;
gdjs.diedCode.GDwindowObjects1.length = 0;
gdjs.diedCode.GDwindowObjects2.length = 0;
gdjs.diedCode.GDrailObjects1.length = 0;
gdjs.diedCode.GDrailObjects2.length = 0;
gdjs.diedCode.GDplayerObjects1.length = 0;
gdjs.diedCode.GDplayerObjects2.length = 0;
gdjs.diedCode.GDhitboxObjects1.length = 0;
gdjs.diedCode.GDhitboxObjects2.length = 0;
gdjs.diedCode.GDMainlightObjects1.length = 0;
gdjs.diedCode.GDMainlightObjects2.length = 0;
gdjs.diedCode.GDsmalllightObjects1.length = 0;
gdjs.diedCode.GDsmalllightObjects2.length = 0;
gdjs.diedCode.GDNewBitmapTextObjects1.length = 0;
gdjs.diedCode.GDNewBitmapTextObjects2.length = 0;
gdjs.diedCode.GDtask_9595barObjects1.length = 0;
gdjs.diedCode.GDtask_9595barObjects2.length = 0;
gdjs.diedCode.GDcharectersObjects1.length = 0;
gdjs.diedCode.GDcharectersObjects2.length = 0;
gdjs.diedCode.GDcharecters22Objects1.length = 0;
gdjs.diedCode.GDcharecters22Objects2.length = 0;
gdjs.diedCode.GDPauseObjects1.length = 0;
gdjs.diedCode.GDPauseObjects2.length = 0;
gdjs.diedCode.GDresumeObjects1.length = 0;
gdjs.diedCode.GDresumeObjects2.length = 0;
gdjs.diedCode.GDQuit_95952Objects1.length = 0;
gdjs.diedCode.GDQuit_95952Objects2.length = 0;
gdjs.diedCode.GDpause_9595menuObjects1.length = 0;
gdjs.diedCode.GDpause_9595menuObjects2.length = 0;
gdjs.diedCode.GDHimaObjects1.length = 0;
gdjs.diedCode.GDHimaObjects2.length = 0;
gdjs.diedCode.GDLayaObjects1.length = 0;
gdjs.diedCode.GDLayaObjects2.length = 0;
gdjs.diedCode.GDJoystickObjects1.length = 0;
gdjs.diedCode.GDJoystickObjects2.length = 0;
gdjs.diedCode.GDE_9595buttonObjects1.length = 0;
gdjs.diedCode.GDE_9595buttonObjects2.length = 0;

gdjs.diedCode.eventsList1(runtimeScene);
gdjs.diedCode.GDWallObjects1.length = 0;
gdjs.diedCode.GDWallObjects2.length = 0;
gdjs.diedCode.GDfloorObjects1.length = 0;
gdjs.diedCode.GDfloorObjects2.length = 0;
gdjs.diedCode.GDdoorsObjects1.length = 0;
gdjs.diedCode.GDdoorsObjects2.length = 0;
gdjs.diedCode.GDobjectsObjects1.length = 0;
gdjs.diedCode.GDobjectsObjects2.length = 0;
gdjs.diedCode.GDwallobjectObjects1.length = 0;
gdjs.diedCode.GDwallobjectObjects2.length = 0;
gdjs.diedCode.GDwindowObjects1.length = 0;
gdjs.diedCode.GDwindowObjects2.length = 0;
gdjs.diedCode.GDrailObjects1.length = 0;
gdjs.diedCode.GDrailObjects2.length = 0;
gdjs.diedCode.GDplayerObjects1.length = 0;
gdjs.diedCode.GDplayerObjects2.length = 0;
gdjs.diedCode.GDhitboxObjects1.length = 0;
gdjs.diedCode.GDhitboxObjects2.length = 0;
gdjs.diedCode.GDMainlightObjects1.length = 0;
gdjs.diedCode.GDMainlightObjects2.length = 0;
gdjs.diedCode.GDsmalllightObjects1.length = 0;
gdjs.diedCode.GDsmalllightObjects2.length = 0;
gdjs.diedCode.GDNewBitmapTextObjects1.length = 0;
gdjs.diedCode.GDNewBitmapTextObjects2.length = 0;
gdjs.diedCode.GDtask_9595barObjects1.length = 0;
gdjs.diedCode.GDtask_9595barObjects2.length = 0;
gdjs.diedCode.GDcharectersObjects1.length = 0;
gdjs.diedCode.GDcharectersObjects2.length = 0;
gdjs.diedCode.GDcharecters22Objects1.length = 0;
gdjs.diedCode.GDcharecters22Objects2.length = 0;
gdjs.diedCode.GDPauseObjects1.length = 0;
gdjs.diedCode.GDPauseObjects2.length = 0;
gdjs.diedCode.GDresumeObjects1.length = 0;
gdjs.diedCode.GDresumeObjects2.length = 0;
gdjs.diedCode.GDQuit_95952Objects1.length = 0;
gdjs.diedCode.GDQuit_95952Objects2.length = 0;
gdjs.diedCode.GDpause_9595menuObjects1.length = 0;
gdjs.diedCode.GDpause_9595menuObjects2.length = 0;
gdjs.diedCode.GDHimaObjects1.length = 0;
gdjs.diedCode.GDHimaObjects2.length = 0;
gdjs.diedCode.GDLayaObjects1.length = 0;
gdjs.diedCode.GDLayaObjects2.length = 0;
gdjs.diedCode.GDJoystickObjects1.length = 0;
gdjs.diedCode.GDJoystickObjects2.length = 0;
gdjs.diedCode.GDE_9595buttonObjects1.length = 0;
gdjs.diedCode.GDE_9595buttonObjects2.length = 0;


return;

}

gdjs['diedCode'] = gdjs.diedCode;
