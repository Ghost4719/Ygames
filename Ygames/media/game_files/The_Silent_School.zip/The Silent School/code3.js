gdjs.Main_32MenuCode = {};
gdjs.Main_32MenuCode.localVariables = [];
gdjs.Main_32MenuCode.GDPlayObjects1= [];
gdjs.Main_32MenuCode.GDPlayObjects2= [];
gdjs.Main_32MenuCode.GDPlayObjects3= [];
gdjs.Main_32MenuCode.GDPlayObjects4= [];
gdjs.Main_32MenuCode.GDLightObjects1= [];
gdjs.Main_32MenuCode.GDLightObjects2= [];
gdjs.Main_32MenuCode.GDLightObjects3= [];
gdjs.Main_32MenuCode.GDLightObjects4= [];
gdjs.Main_32MenuCode.GDLight2Objects1= [];
gdjs.Main_32MenuCode.GDLight2Objects2= [];
gdjs.Main_32MenuCode.GDLight2Objects3= [];
gdjs.Main_32MenuCode.GDLight2Objects4= [];
gdjs.Main_32MenuCode.GDNewParticlesEmitterObjects1= [];
gdjs.Main_32MenuCode.GDNewParticlesEmitterObjects2= [];
gdjs.Main_32MenuCode.GDNewParticlesEmitterObjects3= [];
gdjs.Main_32MenuCode.GDNewParticlesEmitterObjects4= [];
gdjs.Main_32MenuCode.GDNewParticlesEmitter2Objects1= [];
gdjs.Main_32MenuCode.GDNewParticlesEmitter2Objects2= [];
gdjs.Main_32MenuCode.GDNewParticlesEmitter2Objects3= [];
gdjs.Main_32MenuCode.GDNewParticlesEmitter2Objects4= [];
gdjs.Main_32MenuCode.GDNewButtonObjects1= [];
gdjs.Main_32MenuCode.GDNewButtonObjects2= [];
gdjs.Main_32MenuCode.GDNewButtonObjects3= [];
gdjs.Main_32MenuCode.GDNewButtonObjects4= [];
gdjs.Main_32MenuCode.GDQuitObjects1= [];
gdjs.Main_32MenuCode.GDQuitObjects2= [];
gdjs.Main_32MenuCode.GDQuitObjects3= [];
gdjs.Main_32MenuCode.GDQuitObjects4= [];
gdjs.Main_32MenuCode.GDplaysObjects1= [];
gdjs.Main_32MenuCode.GDplaysObjects2= [];
gdjs.Main_32MenuCode.GDplaysObjects3= [];
gdjs.Main_32MenuCode.GDplaysObjects4= [];
gdjs.Main_32MenuCode.GDquitsObjects1= [];
gdjs.Main_32MenuCode.GDquitsObjects2= [];
gdjs.Main_32MenuCode.GDquitsObjects3= [];
gdjs.Main_32MenuCode.GDquitsObjects4= [];
gdjs.Main_32MenuCode.GDNameObjects1= [];
gdjs.Main_32MenuCode.GDNameObjects2= [];
gdjs.Main_32MenuCode.GDNameObjects3= [];
gdjs.Main_32MenuCode.GDNameObjects4= [];
gdjs.Main_32MenuCode.GDNewShapePainterObjects1= [];
gdjs.Main_32MenuCode.GDNewShapePainterObjects2= [];
gdjs.Main_32MenuCode.GDNewShapePainterObjects3= [];
gdjs.Main_32MenuCode.GDNewShapePainterObjects4= [];
gdjs.Main_32MenuCode.GDWallObjects1= [];
gdjs.Main_32MenuCode.GDWallObjects2= [];
gdjs.Main_32MenuCode.GDWallObjects3= [];
gdjs.Main_32MenuCode.GDWallObjects4= [];
gdjs.Main_32MenuCode.GDfloorObjects1= [];
gdjs.Main_32MenuCode.GDfloorObjects2= [];
gdjs.Main_32MenuCode.GDfloorObjects3= [];
gdjs.Main_32MenuCode.GDfloorObjects4= [];
gdjs.Main_32MenuCode.GDdoorsObjects1= [];
gdjs.Main_32MenuCode.GDdoorsObjects2= [];
gdjs.Main_32MenuCode.GDdoorsObjects3= [];
gdjs.Main_32MenuCode.GDdoorsObjects4= [];
gdjs.Main_32MenuCode.GDobjectsObjects1= [];
gdjs.Main_32MenuCode.GDobjectsObjects2= [];
gdjs.Main_32MenuCode.GDobjectsObjects3= [];
gdjs.Main_32MenuCode.GDobjectsObjects4= [];
gdjs.Main_32MenuCode.GDwallobjectObjects1= [];
gdjs.Main_32MenuCode.GDwallobjectObjects2= [];
gdjs.Main_32MenuCode.GDwallobjectObjects3= [];
gdjs.Main_32MenuCode.GDwallobjectObjects4= [];
gdjs.Main_32MenuCode.GDwindowObjects1= [];
gdjs.Main_32MenuCode.GDwindowObjects2= [];
gdjs.Main_32MenuCode.GDwindowObjects3= [];
gdjs.Main_32MenuCode.GDwindowObjects4= [];
gdjs.Main_32MenuCode.GDrailObjects1= [];
gdjs.Main_32MenuCode.GDrailObjects2= [];
gdjs.Main_32MenuCode.GDrailObjects3= [];
gdjs.Main_32MenuCode.GDrailObjects4= [];
gdjs.Main_32MenuCode.GDplayerObjects1= [];
gdjs.Main_32MenuCode.GDplayerObjects2= [];
gdjs.Main_32MenuCode.GDplayerObjects3= [];
gdjs.Main_32MenuCode.GDplayerObjects4= [];
gdjs.Main_32MenuCode.GDhitboxObjects1= [];
gdjs.Main_32MenuCode.GDhitboxObjects2= [];
gdjs.Main_32MenuCode.GDhitboxObjects3= [];
gdjs.Main_32MenuCode.GDhitboxObjects4= [];
gdjs.Main_32MenuCode.GDMainlightObjects1= [];
gdjs.Main_32MenuCode.GDMainlightObjects2= [];
gdjs.Main_32MenuCode.GDMainlightObjects3= [];
gdjs.Main_32MenuCode.GDMainlightObjects4= [];
gdjs.Main_32MenuCode.GDsmalllightObjects1= [];
gdjs.Main_32MenuCode.GDsmalllightObjects2= [];
gdjs.Main_32MenuCode.GDsmalllightObjects3= [];
gdjs.Main_32MenuCode.GDsmalllightObjects4= [];
gdjs.Main_32MenuCode.GDNewBitmapTextObjects1= [];
gdjs.Main_32MenuCode.GDNewBitmapTextObjects2= [];
gdjs.Main_32MenuCode.GDNewBitmapTextObjects3= [];
gdjs.Main_32MenuCode.GDNewBitmapTextObjects4= [];
gdjs.Main_32MenuCode.GDtask_9595barObjects1= [];
gdjs.Main_32MenuCode.GDtask_9595barObjects2= [];
gdjs.Main_32MenuCode.GDtask_9595barObjects3= [];
gdjs.Main_32MenuCode.GDtask_9595barObjects4= [];
gdjs.Main_32MenuCode.GDcharectersObjects1= [];
gdjs.Main_32MenuCode.GDcharectersObjects2= [];
gdjs.Main_32MenuCode.GDcharectersObjects3= [];
gdjs.Main_32MenuCode.GDcharectersObjects4= [];
gdjs.Main_32MenuCode.GDcharecters22Objects1= [];
gdjs.Main_32MenuCode.GDcharecters22Objects2= [];
gdjs.Main_32MenuCode.GDcharecters22Objects3= [];
gdjs.Main_32MenuCode.GDcharecters22Objects4= [];
gdjs.Main_32MenuCode.GDPauseObjects1= [];
gdjs.Main_32MenuCode.GDPauseObjects2= [];
gdjs.Main_32MenuCode.GDPauseObjects3= [];
gdjs.Main_32MenuCode.GDPauseObjects4= [];
gdjs.Main_32MenuCode.GDresumeObjects1= [];
gdjs.Main_32MenuCode.GDresumeObjects2= [];
gdjs.Main_32MenuCode.GDresumeObjects3= [];
gdjs.Main_32MenuCode.GDresumeObjects4= [];
gdjs.Main_32MenuCode.GDQuit_95952Objects1= [];
gdjs.Main_32MenuCode.GDQuit_95952Objects2= [];
gdjs.Main_32MenuCode.GDQuit_95952Objects3= [];
gdjs.Main_32MenuCode.GDQuit_95952Objects4= [];
gdjs.Main_32MenuCode.GDpause_9595menuObjects1= [];
gdjs.Main_32MenuCode.GDpause_9595menuObjects2= [];
gdjs.Main_32MenuCode.GDpause_9595menuObjects3= [];
gdjs.Main_32MenuCode.GDpause_9595menuObjects4= [];
gdjs.Main_32MenuCode.GDHimaObjects1= [];
gdjs.Main_32MenuCode.GDHimaObjects2= [];
gdjs.Main_32MenuCode.GDHimaObjects3= [];
gdjs.Main_32MenuCode.GDHimaObjects4= [];
gdjs.Main_32MenuCode.GDLayaObjects1= [];
gdjs.Main_32MenuCode.GDLayaObjects2= [];
gdjs.Main_32MenuCode.GDLayaObjects3= [];
gdjs.Main_32MenuCode.GDLayaObjects4= [];
gdjs.Main_32MenuCode.GDJoystickObjects1= [];
gdjs.Main_32MenuCode.GDJoystickObjects2= [];
gdjs.Main_32MenuCode.GDJoystickObjects3= [];
gdjs.Main_32MenuCode.GDJoystickObjects4= [];
gdjs.Main_32MenuCode.GDE_9595buttonObjects1= [];
gdjs.Main_32MenuCode.GDE_9595buttonObjects2= [];
gdjs.Main_32MenuCode.GDE_9595buttonObjects3= [];
gdjs.Main_32MenuCode.GDE_9595buttonObjects4= [];


gdjs.Main_32MenuCode.asyncCallback30119132 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Main_32MenuCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("NewShapePainter"), gdjs.Main_32MenuCode.GDNewShapePainterObjects4);

{for(var i = 0, len = gdjs.Main_32MenuCode.GDNewShapePainterObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNewShapePainterObjects4[i].getBehavior("FlashTransitionPainter").PaintEffect("240;240;240", 0.1, "Flash", "Both", 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDNewShapePainterObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNewShapePainterObjects4[i].resetTimer("lightning");
}
}gdjs.Main_32MenuCode.localVariables.length = 0;
}
gdjs.Main_32MenuCode.eventsList0 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.Main_32MenuCode.localVariables);
for (const obj of gdjs.Main_32MenuCode.GDNewShapePainterObjects3) asyncObjectsList.addObject("NewShapePainter", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.Main_32MenuCode.asyncCallback30119132(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Main_32MenuCode.asyncCallback30117876 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Main_32MenuCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("NewShapePainter"), gdjs.Main_32MenuCode.GDNewShapePainterObjects3);

{for(var i = 0, len = gdjs.Main_32MenuCode.GDNewShapePainterObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNewShapePainterObjects3[i].getBehavior("FlashTransitionPainter").PaintEffect("240;240;240", 0.5, "Flash", "Both", 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.Main_32MenuCode.eventsList0(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.Main_32MenuCode.localVariables.length = 0;
}
gdjs.Main_32MenuCode.eventsList1 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.Main_32MenuCode.localVariables);
for (const obj of gdjs.Main_32MenuCode.GDNewShapePainterObjects2) asyncObjectsList.addObject("NewShapePainter", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.Main_32MenuCode.asyncCallback30117876(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Main_32MenuCode.asyncCallback30112620 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Main_32MenuCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("NewShapePainter"), gdjs.Main_32MenuCode.GDNewShapePainterObjects2);

{for(var i = 0, len = gdjs.Main_32MenuCode.GDNewShapePainterObjects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNewShapePainterObjects2[i].getBehavior("FlashTransitionPainter").PaintEffect("240;240;240", 0.1, "Flash", "Both", 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.Main_32MenuCode.eventsList1(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.Main_32MenuCode.localVariables.length = 0;
}
gdjs.Main_32MenuCode.eventsList2 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.Main_32MenuCode.localVariables);
for (const obj of gdjs.Main_32MenuCode.GDNewShapePainterObjects1) asyncObjectsList.addObject("NewShapePainter", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.Main_32MenuCode.asyncCallback30112620(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDPlayObjects1Objects = Hashtable.newFrom({"Play": gdjs.Main_32MenuCode.GDPlayObjects1});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDQuitObjects1Objects = Hashtable.newFrom({"Quit": gdjs.Main_32MenuCode.GDQuitObjects1});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDPlayObjects1Objects = Hashtable.newFrom({"Play": gdjs.Main_32MenuCode.GDPlayObjects1});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDQuitObjects1Objects = Hashtable.newFrom({"Quit": gdjs.Main_32MenuCode.GDQuitObjects1});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDQuitObjects1Objects = Hashtable.newFrom({"Quit": gdjs.Main_32MenuCode.GDQuitObjects1});
gdjs.Main_32MenuCode.asyncCallback30127372 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Main_32MenuCode.localVariables);
{gdjs.evtTools.runtimeScene.stopGame(runtimeScene);
}gdjs.Main_32MenuCode.localVariables.length = 0;
}
gdjs.Main_32MenuCode.eventsList3 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.Main_32MenuCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.Main_32MenuCode.asyncCallback30127372(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDPlayObjects1Objects = Hashtable.newFrom({"Play": gdjs.Main_32MenuCode.GDPlayObjects1});
gdjs.Main_32MenuCode.asyncCallback30128772 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Main_32MenuCode.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Rooms", false);
}{runtimeScene.getGame().getVariables().getFromIndex(10).getChild("blue").setNumber(0);
}{runtimeScene.getGame().getVariables().getFromIndex(10).getChild("green").setNumber(0);
}{runtimeScene.getGame().getVariables().getFromIndex(10).getChild("red").setNumber(0);
}{runtimeScene.getGame().getVariables().getFromIndex(6).getChild("misionstate").setBoolean(false);
}{runtimeScene.getGame().getVariables().getFromIndex(12).getChild("misionstate").setBoolean(false);
}{runtimeScene.getGame().getVariables().getFromIndex(3).getChild("misionstate").setBoolean(false);
}{runtimeScene.getGame().getVariables().getFromIndex(5).getChild("misionstate").setBoolean(false);
}{runtimeScene.getGame().getVariables().getFromIndex(9).getChild("misionstate").setBoolean(false);
}{runtimeScene.getGame().getVariables().getFromIndex(6).getChild("task").setBoolean(false);
}{runtimeScene.getGame().getVariables().getFromIndex(12).getChild("task").setBoolean(false);
}{runtimeScene.getGame().getVariables().getFromIndex(3).getChild("task").setBoolean(false);
}{runtimeScene.getGame().getVariables().getFromIndex(5).getChild("task").setBoolean(false);
}{runtimeScene.getGame().getVariables().getFromIndex(9).getChild("task").setBoolean(false);
}{runtimeScene.getGame().getVariables().getFromIndex(6).getChild("state").setNumber(0);
}{runtimeScene.getGame().getVariables().getFromIndex(7).getChild("state").setNumber(0);
}{runtimeScene.getGame().getVariables().getFromIndex(12).getChild("state").setNumber(0);
}{runtimeScene.getGame().getVariables().getFromIndex(13).getChild("state").setNumber(0);
}{runtimeScene.getGame().getVariables().getFromIndex(3).getChild("state").setNumber(0);
}{runtimeScene.getGame().getVariables().getFromIndex(5).getChild("state").setNumber(0);
}{runtimeScene.getGame().getVariables().getFromIndex(14).getChild("state").setNumber(0);
}{runtimeScene.getGame().getVariables().getFromIndex(11).getChild("state").setNumber(0);
}{runtimeScene.getGame().getVariables().getFromIndex(9).getChild("state").setNumber(0);
}{runtimeScene.getGame().getVariables().getFromIndex(4).getChild("state").setNumber(0);
}{runtimeScene.getGame().getVariables().getFromIndex(8).getChild("state").setNumber(0);
}{runtimeScene.getGame().getVariables().getFromIndex(18).setNumber(0);
}{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(4);
}{runtimeScene.getGame().getVariables().getFromIndex(15).setNumber(0);
}{runtimeScene.getGame().getVariables().getFromIndex(16).setNumber(0);
}{runtimeScene.getGame().getVariables().getFromIndex(8).getChild("race").setBoolean(false);
}{runtimeScene.getGame().getVariables().getFromIndex(0).setString("The Night");
}{runtimeScene.getGame().getVariables().getFromIndex(17).setNumber(0);
}gdjs.Main_32MenuCode.localVariables.length = 0;
}
gdjs.Main_32MenuCode.eventsList4 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.Main_32MenuCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.Main_32MenuCode.asyncCallback30128772(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Main_32MenuCode.eventsList5 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewShapePainter"), gdjs.Main_32MenuCode.GDNewShapePainterObjects1);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDNewShapePainterObjects1.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNewShapePainterObjects1[i].resetTimer("lightning");
}
}{gdjs.evtTools.sound.playMusic(runtimeScene, "rain-110508.mp3", true, 65, 1);
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 2.6, "", 0);
}{gdjs.evtTools.runtimeScene.prioritizeLoadingOfScene(runtimeScene, "Rooms");
}{gdjs.evtTools.runtimeScene.prioritizeLoadingOfScene(runtimeScene, "School");
}{gdjs.evtTools.window.setFullScreen(runtimeScene, true, true);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewShapePainter"), gdjs.Main_32MenuCode.GDNewShapePainterObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNewShapePainterObjects1.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNewShapePainterObjects1[i].getTimerElapsedTimeInSecondsOrNaN("lightning") >= gdjs.randomInRange(5, 15) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNewShapePainterObjects1[k] = gdjs.Main_32MenuCode.GDNewShapePainterObjects1[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNewShapePainterObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(30115276);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "thunder-124463.mp3", true, 100, 1);
}
{ //Subevents
gdjs.Main_32MenuCode.eventsList2(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.Main_32MenuCode.GDplayerObjects1);
{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.Main_32MenuCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDplayerObjects1[0].getPointX("")) + (gdjs.evtTools.input.getCursorX(runtimeScene, "", 0) / gdjs.evtTools.window.getWindowInnerWidth()) * 16, "", 0);
}{gdjs.evtTools.camera.setCameraY(runtimeScene, ((( gdjs.Main_32MenuCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDplayerObjects1[0].getPointY("")) - 32) + (gdjs.evtTools.input.getCursorY(runtimeScene, "", 0) / gdjs.evtTools.window.getWindowInnerHeight()) * 16, "", 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Play"), gdjs.Main_32MenuCode.GDPlayObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDPlayObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDPlayObjects1 */
{for(var i = 0, len = gdjs.Main_32MenuCode.GDPlayObjects1.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDPlayObjects1[i].getBehavior("Tween").addObjectScaleTween3("1", 1.5, "linear", 0.1, false, true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Quit"), gdjs.Main_32MenuCode.GDQuitObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDQuitObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDQuitObjects1 */
{for(var i = 0, len = gdjs.Main_32MenuCode.GDQuitObjects1.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDQuitObjects1[i].getBehavior("Tween").addObjectScaleTween3("1", 1.5, "linear", 0.1, false, true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Play"), gdjs.Main_32MenuCode.GDPlayObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDPlayObjects1Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDPlayObjects1 */
{for(var i = 0, len = gdjs.Main_32MenuCode.GDPlayObjects1.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDPlayObjects1[i].getBehavior("Tween").addObjectScaleTween3("1", 1, "linear", 0.1, false, true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Quit"), gdjs.Main_32MenuCode.GDQuitObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDQuitObjects1Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDQuitObjects1 */
{for(var i = 0, len = gdjs.Main_32MenuCode.GDQuitObjects1.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDQuitObjects1[i].getBehavior("Tween").addObjectScaleTween3("1", 1, "linear", 0.1, false, true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Quit"), gdjs.Main_32MenuCode.GDQuitObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDQuitObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(30127076);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDQuitObjects1 */
{for(var i = 0, len = gdjs.Main_32MenuCode.GDQuitObjects1.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDQuitObjects1[i].getBehavior("Tween").addObjectScaleTween3("1", 0.8, "linear", 0.1, false, true);
}
}
{ //Subevents
gdjs.Main_32MenuCode.eventsList3(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Play"), gdjs.Main_32MenuCode.GDPlayObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDPlayObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(30128084);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Quit"), gdjs.Main_32MenuCode.GDQuitObjects1);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDQuitObjects1.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDQuitObjects1[i].getBehavior("Tween").addObjectScaleTween3("1", 0.8, "linear", 0.1, false, true);
}
}
{ //Subevents
gdjs.Main_32MenuCode.eventsList4(runtimeScene);} //End of subevents
}

}


};

gdjs.Main_32MenuCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Main_32MenuCode.GDPlayObjects1.length = 0;
gdjs.Main_32MenuCode.GDPlayObjects2.length = 0;
gdjs.Main_32MenuCode.GDPlayObjects3.length = 0;
gdjs.Main_32MenuCode.GDPlayObjects4.length = 0;
gdjs.Main_32MenuCode.GDLightObjects1.length = 0;
gdjs.Main_32MenuCode.GDLightObjects2.length = 0;
gdjs.Main_32MenuCode.GDLightObjects3.length = 0;
gdjs.Main_32MenuCode.GDLightObjects4.length = 0;
gdjs.Main_32MenuCode.GDLight2Objects1.length = 0;
gdjs.Main_32MenuCode.GDLight2Objects2.length = 0;
gdjs.Main_32MenuCode.GDLight2Objects3.length = 0;
gdjs.Main_32MenuCode.GDLight2Objects4.length = 0;
gdjs.Main_32MenuCode.GDNewParticlesEmitterObjects1.length = 0;
gdjs.Main_32MenuCode.GDNewParticlesEmitterObjects2.length = 0;
gdjs.Main_32MenuCode.GDNewParticlesEmitterObjects3.length = 0;
gdjs.Main_32MenuCode.GDNewParticlesEmitterObjects4.length = 0;
gdjs.Main_32MenuCode.GDNewParticlesEmitter2Objects1.length = 0;
gdjs.Main_32MenuCode.GDNewParticlesEmitter2Objects2.length = 0;
gdjs.Main_32MenuCode.GDNewParticlesEmitter2Objects3.length = 0;
gdjs.Main_32MenuCode.GDNewParticlesEmitter2Objects4.length = 0;
gdjs.Main_32MenuCode.GDNewButtonObjects1.length = 0;
gdjs.Main_32MenuCode.GDNewButtonObjects2.length = 0;
gdjs.Main_32MenuCode.GDNewButtonObjects3.length = 0;
gdjs.Main_32MenuCode.GDNewButtonObjects4.length = 0;
gdjs.Main_32MenuCode.GDQuitObjects1.length = 0;
gdjs.Main_32MenuCode.GDQuitObjects2.length = 0;
gdjs.Main_32MenuCode.GDQuitObjects3.length = 0;
gdjs.Main_32MenuCode.GDQuitObjects4.length = 0;
gdjs.Main_32MenuCode.GDplaysObjects1.length = 0;
gdjs.Main_32MenuCode.GDplaysObjects2.length = 0;
gdjs.Main_32MenuCode.GDplaysObjects3.length = 0;
gdjs.Main_32MenuCode.GDplaysObjects4.length = 0;
gdjs.Main_32MenuCode.GDquitsObjects1.length = 0;
gdjs.Main_32MenuCode.GDquitsObjects2.length = 0;
gdjs.Main_32MenuCode.GDquitsObjects3.length = 0;
gdjs.Main_32MenuCode.GDquitsObjects4.length = 0;
gdjs.Main_32MenuCode.GDNameObjects1.length = 0;
gdjs.Main_32MenuCode.GDNameObjects2.length = 0;
gdjs.Main_32MenuCode.GDNameObjects3.length = 0;
gdjs.Main_32MenuCode.GDNameObjects4.length = 0;
gdjs.Main_32MenuCode.GDNewShapePainterObjects1.length = 0;
gdjs.Main_32MenuCode.GDNewShapePainterObjects2.length = 0;
gdjs.Main_32MenuCode.GDNewShapePainterObjects3.length = 0;
gdjs.Main_32MenuCode.GDNewShapePainterObjects4.length = 0;
gdjs.Main_32MenuCode.GDWallObjects1.length = 0;
gdjs.Main_32MenuCode.GDWallObjects2.length = 0;
gdjs.Main_32MenuCode.GDWallObjects3.length = 0;
gdjs.Main_32MenuCode.GDWallObjects4.length = 0;
gdjs.Main_32MenuCode.GDfloorObjects1.length = 0;
gdjs.Main_32MenuCode.GDfloorObjects2.length = 0;
gdjs.Main_32MenuCode.GDfloorObjects3.length = 0;
gdjs.Main_32MenuCode.GDfloorObjects4.length = 0;
gdjs.Main_32MenuCode.GDdoorsObjects1.length = 0;
gdjs.Main_32MenuCode.GDdoorsObjects2.length = 0;
gdjs.Main_32MenuCode.GDdoorsObjects3.length = 0;
gdjs.Main_32MenuCode.GDdoorsObjects4.length = 0;
gdjs.Main_32MenuCode.GDobjectsObjects1.length = 0;
gdjs.Main_32MenuCode.GDobjectsObjects2.length = 0;
gdjs.Main_32MenuCode.GDobjectsObjects3.length = 0;
gdjs.Main_32MenuCode.GDobjectsObjects4.length = 0;
gdjs.Main_32MenuCode.GDwallobjectObjects1.length = 0;
gdjs.Main_32MenuCode.GDwallobjectObjects2.length = 0;
gdjs.Main_32MenuCode.GDwallobjectObjects3.length = 0;
gdjs.Main_32MenuCode.GDwallobjectObjects4.length = 0;
gdjs.Main_32MenuCode.GDwindowObjects1.length = 0;
gdjs.Main_32MenuCode.GDwindowObjects2.length = 0;
gdjs.Main_32MenuCode.GDwindowObjects3.length = 0;
gdjs.Main_32MenuCode.GDwindowObjects4.length = 0;
gdjs.Main_32MenuCode.GDrailObjects1.length = 0;
gdjs.Main_32MenuCode.GDrailObjects2.length = 0;
gdjs.Main_32MenuCode.GDrailObjects3.length = 0;
gdjs.Main_32MenuCode.GDrailObjects4.length = 0;
gdjs.Main_32MenuCode.GDplayerObjects1.length = 0;
gdjs.Main_32MenuCode.GDplayerObjects2.length = 0;
gdjs.Main_32MenuCode.GDplayerObjects3.length = 0;
gdjs.Main_32MenuCode.GDplayerObjects4.length = 0;
gdjs.Main_32MenuCode.GDhitboxObjects1.length = 0;
gdjs.Main_32MenuCode.GDhitboxObjects2.length = 0;
gdjs.Main_32MenuCode.GDhitboxObjects3.length = 0;
gdjs.Main_32MenuCode.GDhitboxObjects4.length = 0;
gdjs.Main_32MenuCode.GDMainlightObjects1.length = 0;
gdjs.Main_32MenuCode.GDMainlightObjects2.length = 0;
gdjs.Main_32MenuCode.GDMainlightObjects3.length = 0;
gdjs.Main_32MenuCode.GDMainlightObjects4.length = 0;
gdjs.Main_32MenuCode.GDsmalllightObjects1.length = 0;
gdjs.Main_32MenuCode.GDsmalllightObjects2.length = 0;
gdjs.Main_32MenuCode.GDsmalllightObjects3.length = 0;
gdjs.Main_32MenuCode.GDsmalllightObjects4.length = 0;
gdjs.Main_32MenuCode.GDNewBitmapTextObjects1.length = 0;
gdjs.Main_32MenuCode.GDNewBitmapTextObjects2.length = 0;
gdjs.Main_32MenuCode.GDNewBitmapTextObjects3.length = 0;
gdjs.Main_32MenuCode.GDNewBitmapTextObjects4.length = 0;
gdjs.Main_32MenuCode.GDtask_9595barObjects1.length = 0;
gdjs.Main_32MenuCode.GDtask_9595barObjects2.length = 0;
gdjs.Main_32MenuCode.GDtask_9595barObjects3.length = 0;
gdjs.Main_32MenuCode.GDtask_9595barObjects4.length = 0;
gdjs.Main_32MenuCode.GDcharectersObjects1.length = 0;
gdjs.Main_32MenuCode.GDcharectersObjects2.length = 0;
gdjs.Main_32MenuCode.GDcharectersObjects3.length = 0;
gdjs.Main_32MenuCode.GDcharectersObjects4.length = 0;
gdjs.Main_32MenuCode.GDcharecters22Objects1.length = 0;
gdjs.Main_32MenuCode.GDcharecters22Objects2.length = 0;
gdjs.Main_32MenuCode.GDcharecters22Objects3.length = 0;
gdjs.Main_32MenuCode.GDcharecters22Objects4.length = 0;
gdjs.Main_32MenuCode.GDPauseObjects1.length = 0;
gdjs.Main_32MenuCode.GDPauseObjects2.length = 0;
gdjs.Main_32MenuCode.GDPauseObjects3.length = 0;
gdjs.Main_32MenuCode.GDPauseObjects4.length = 0;
gdjs.Main_32MenuCode.GDresumeObjects1.length = 0;
gdjs.Main_32MenuCode.GDresumeObjects2.length = 0;
gdjs.Main_32MenuCode.GDresumeObjects3.length = 0;
gdjs.Main_32MenuCode.GDresumeObjects4.length = 0;
gdjs.Main_32MenuCode.GDQuit_95952Objects1.length = 0;
gdjs.Main_32MenuCode.GDQuit_95952Objects2.length = 0;
gdjs.Main_32MenuCode.GDQuit_95952Objects3.length = 0;
gdjs.Main_32MenuCode.GDQuit_95952Objects4.length = 0;
gdjs.Main_32MenuCode.GDpause_9595menuObjects1.length = 0;
gdjs.Main_32MenuCode.GDpause_9595menuObjects2.length = 0;
gdjs.Main_32MenuCode.GDpause_9595menuObjects3.length = 0;
gdjs.Main_32MenuCode.GDpause_9595menuObjects4.length = 0;
gdjs.Main_32MenuCode.GDHimaObjects1.length = 0;
gdjs.Main_32MenuCode.GDHimaObjects2.length = 0;
gdjs.Main_32MenuCode.GDHimaObjects3.length = 0;
gdjs.Main_32MenuCode.GDHimaObjects4.length = 0;
gdjs.Main_32MenuCode.GDLayaObjects1.length = 0;
gdjs.Main_32MenuCode.GDLayaObjects2.length = 0;
gdjs.Main_32MenuCode.GDLayaObjects3.length = 0;
gdjs.Main_32MenuCode.GDLayaObjects4.length = 0;
gdjs.Main_32MenuCode.GDJoystickObjects1.length = 0;
gdjs.Main_32MenuCode.GDJoystickObjects2.length = 0;
gdjs.Main_32MenuCode.GDJoystickObjects3.length = 0;
gdjs.Main_32MenuCode.GDJoystickObjects4.length = 0;
gdjs.Main_32MenuCode.GDE_9595buttonObjects1.length = 0;
gdjs.Main_32MenuCode.GDE_9595buttonObjects2.length = 0;
gdjs.Main_32MenuCode.GDE_9595buttonObjects3.length = 0;
gdjs.Main_32MenuCode.GDE_9595buttonObjects4.length = 0;

gdjs.Main_32MenuCode.eventsList5(runtimeScene);
gdjs.Main_32MenuCode.GDPlayObjects1.length = 0;
gdjs.Main_32MenuCode.GDPlayObjects2.length = 0;
gdjs.Main_32MenuCode.GDPlayObjects3.length = 0;
gdjs.Main_32MenuCode.GDPlayObjects4.length = 0;
gdjs.Main_32MenuCode.GDLightObjects1.length = 0;
gdjs.Main_32MenuCode.GDLightObjects2.length = 0;
gdjs.Main_32MenuCode.GDLightObjects3.length = 0;
gdjs.Main_32MenuCode.GDLightObjects4.length = 0;
gdjs.Main_32MenuCode.GDLight2Objects1.length = 0;
gdjs.Main_32MenuCode.GDLight2Objects2.length = 0;
gdjs.Main_32MenuCode.GDLight2Objects3.length = 0;
gdjs.Main_32MenuCode.GDLight2Objects4.length = 0;
gdjs.Main_32MenuCode.GDNewParticlesEmitterObjects1.length = 0;
gdjs.Main_32MenuCode.GDNewParticlesEmitterObjects2.length = 0;
gdjs.Main_32MenuCode.GDNewParticlesEmitterObjects3.length = 0;
gdjs.Main_32MenuCode.GDNewParticlesEmitterObjects4.length = 0;
gdjs.Main_32MenuCode.GDNewParticlesEmitter2Objects1.length = 0;
gdjs.Main_32MenuCode.GDNewParticlesEmitter2Objects2.length = 0;
gdjs.Main_32MenuCode.GDNewParticlesEmitter2Objects3.length = 0;
gdjs.Main_32MenuCode.GDNewParticlesEmitter2Objects4.length = 0;
gdjs.Main_32MenuCode.GDNewButtonObjects1.length = 0;
gdjs.Main_32MenuCode.GDNewButtonObjects2.length = 0;
gdjs.Main_32MenuCode.GDNewButtonObjects3.length = 0;
gdjs.Main_32MenuCode.GDNewButtonObjects4.length = 0;
gdjs.Main_32MenuCode.GDQuitObjects1.length = 0;
gdjs.Main_32MenuCode.GDQuitObjects2.length = 0;
gdjs.Main_32MenuCode.GDQuitObjects3.length = 0;
gdjs.Main_32MenuCode.GDQuitObjects4.length = 0;
gdjs.Main_32MenuCode.GDplaysObjects1.length = 0;
gdjs.Main_32MenuCode.GDplaysObjects2.length = 0;
gdjs.Main_32MenuCode.GDplaysObjects3.length = 0;
gdjs.Main_32MenuCode.GDplaysObjects4.length = 0;
gdjs.Main_32MenuCode.GDquitsObjects1.length = 0;
gdjs.Main_32MenuCode.GDquitsObjects2.length = 0;
gdjs.Main_32MenuCode.GDquitsObjects3.length = 0;
gdjs.Main_32MenuCode.GDquitsObjects4.length = 0;
gdjs.Main_32MenuCode.GDNameObjects1.length = 0;
gdjs.Main_32MenuCode.GDNameObjects2.length = 0;
gdjs.Main_32MenuCode.GDNameObjects3.length = 0;
gdjs.Main_32MenuCode.GDNameObjects4.length = 0;
gdjs.Main_32MenuCode.GDNewShapePainterObjects1.length = 0;
gdjs.Main_32MenuCode.GDNewShapePainterObjects2.length = 0;
gdjs.Main_32MenuCode.GDNewShapePainterObjects3.length = 0;
gdjs.Main_32MenuCode.GDNewShapePainterObjects4.length = 0;
gdjs.Main_32MenuCode.GDWallObjects1.length = 0;
gdjs.Main_32MenuCode.GDWallObjects2.length = 0;
gdjs.Main_32MenuCode.GDWallObjects3.length = 0;
gdjs.Main_32MenuCode.GDWallObjects4.length = 0;
gdjs.Main_32MenuCode.GDfloorObjects1.length = 0;
gdjs.Main_32MenuCode.GDfloorObjects2.length = 0;
gdjs.Main_32MenuCode.GDfloorObjects3.length = 0;
gdjs.Main_32MenuCode.GDfloorObjects4.length = 0;
gdjs.Main_32MenuCode.GDdoorsObjects1.length = 0;
gdjs.Main_32MenuCode.GDdoorsObjects2.length = 0;
gdjs.Main_32MenuCode.GDdoorsObjects3.length = 0;
gdjs.Main_32MenuCode.GDdoorsObjects4.length = 0;
gdjs.Main_32MenuCode.GDobjectsObjects1.length = 0;
gdjs.Main_32MenuCode.GDobjectsObjects2.length = 0;
gdjs.Main_32MenuCode.GDobjectsObjects3.length = 0;
gdjs.Main_32MenuCode.GDobjectsObjects4.length = 0;
gdjs.Main_32MenuCode.GDwallobjectObjects1.length = 0;
gdjs.Main_32MenuCode.GDwallobjectObjects2.length = 0;
gdjs.Main_32MenuCode.GDwallobjectObjects3.length = 0;
gdjs.Main_32MenuCode.GDwallobjectObjects4.length = 0;
gdjs.Main_32MenuCode.GDwindowObjects1.length = 0;
gdjs.Main_32MenuCode.GDwindowObjects2.length = 0;
gdjs.Main_32MenuCode.GDwindowObjects3.length = 0;
gdjs.Main_32MenuCode.GDwindowObjects4.length = 0;
gdjs.Main_32MenuCode.GDrailObjects1.length = 0;
gdjs.Main_32MenuCode.GDrailObjects2.length = 0;
gdjs.Main_32MenuCode.GDrailObjects3.length = 0;
gdjs.Main_32MenuCode.GDrailObjects4.length = 0;
gdjs.Main_32MenuCode.GDplayerObjects1.length = 0;
gdjs.Main_32MenuCode.GDplayerObjects2.length = 0;
gdjs.Main_32MenuCode.GDplayerObjects3.length = 0;
gdjs.Main_32MenuCode.GDplayerObjects4.length = 0;
gdjs.Main_32MenuCode.GDhitboxObjects1.length = 0;
gdjs.Main_32MenuCode.GDhitboxObjects2.length = 0;
gdjs.Main_32MenuCode.GDhitboxObjects3.length = 0;
gdjs.Main_32MenuCode.GDhitboxObjects4.length = 0;
gdjs.Main_32MenuCode.GDMainlightObjects1.length = 0;
gdjs.Main_32MenuCode.GDMainlightObjects2.length = 0;
gdjs.Main_32MenuCode.GDMainlightObjects3.length = 0;
gdjs.Main_32MenuCode.GDMainlightObjects4.length = 0;
gdjs.Main_32MenuCode.GDsmalllightObjects1.length = 0;
gdjs.Main_32MenuCode.GDsmalllightObjects2.length = 0;
gdjs.Main_32MenuCode.GDsmalllightObjects3.length = 0;
gdjs.Main_32MenuCode.GDsmalllightObjects4.length = 0;
gdjs.Main_32MenuCode.GDNewBitmapTextObjects1.length = 0;
gdjs.Main_32MenuCode.GDNewBitmapTextObjects2.length = 0;
gdjs.Main_32MenuCode.GDNewBitmapTextObjects3.length = 0;
gdjs.Main_32MenuCode.GDNewBitmapTextObjects4.length = 0;
gdjs.Main_32MenuCode.GDtask_9595barObjects1.length = 0;
gdjs.Main_32MenuCode.GDtask_9595barObjects2.length = 0;
gdjs.Main_32MenuCode.GDtask_9595barObjects3.length = 0;
gdjs.Main_32MenuCode.GDtask_9595barObjects4.length = 0;
gdjs.Main_32MenuCode.GDcharectersObjects1.length = 0;
gdjs.Main_32MenuCode.GDcharectersObjects2.length = 0;
gdjs.Main_32MenuCode.GDcharectersObjects3.length = 0;
gdjs.Main_32MenuCode.GDcharectersObjects4.length = 0;
gdjs.Main_32MenuCode.GDcharecters22Objects1.length = 0;
gdjs.Main_32MenuCode.GDcharecters22Objects2.length = 0;
gdjs.Main_32MenuCode.GDcharecters22Objects3.length = 0;
gdjs.Main_32MenuCode.GDcharecters22Objects4.length = 0;
gdjs.Main_32MenuCode.GDPauseObjects1.length = 0;
gdjs.Main_32MenuCode.GDPauseObjects2.length = 0;
gdjs.Main_32MenuCode.GDPauseObjects3.length = 0;
gdjs.Main_32MenuCode.GDPauseObjects4.length = 0;
gdjs.Main_32MenuCode.GDresumeObjects1.length = 0;
gdjs.Main_32MenuCode.GDresumeObjects2.length = 0;
gdjs.Main_32MenuCode.GDresumeObjects3.length = 0;
gdjs.Main_32MenuCode.GDresumeObjects4.length = 0;
gdjs.Main_32MenuCode.GDQuit_95952Objects1.length = 0;
gdjs.Main_32MenuCode.GDQuit_95952Objects2.length = 0;
gdjs.Main_32MenuCode.GDQuit_95952Objects3.length = 0;
gdjs.Main_32MenuCode.GDQuit_95952Objects4.length = 0;
gdjs.Main_32MenuCode.GDpause_9595menuObjects1.length = 0;
gdjs.Main_32MenuCode.GDpause_9595menuObjects2.length = 0;
gdjs.Main_32MenuCode.GDpause_9595menuObjects3.length = 0;
gdjs.Main_32MenuCode.GDpause_9595menuObjects4.length = 0;
gdjs.Main_32MenuCode.GDHimaObjects1.length = 0;
gdjs.Main_32MenuCode.GDHimaObjects2.length = 0;
gdjs.Main_32MenuCode.GDHimaObjects3.length = 0;
gdjs.Main_32MenuCode.GDHimaObjects4.length = 0;
gdjs.Main_32MenuCode.GDLayaObjects1.length = 0;
gdjs.Main_32MenuCode.GDLayaObjects2.length = 0;
gdjs.Main_32MenuCode.GDLayaObjects3.length = 0;
gdjs.Main_32MenuCode.GDLayaObjects4.length = 0;
gdjs.Main_32MenuCode.GDJoystickObjects1.length = 0;
gdjs.Main_32MenuCode.GDJoystickObjects2.length = 0;
gdjs.Main_32MenuCode.GDJoystickObjects3.length = 0;
gdjs.Main_32MenuCode.GDJoystickObjects4.length = 0;
gdjs.Main_32MenuCode.GDE_9595buttonObjects1.length = 0;
gdjs.Main_32MenuCode.GDE_9595buttonObjects2.length = 0;
gdjs.Main_32MenuCode.GDE_9595buttonObjects3.length = 0;
gdjs.Main_32MenuCode.GDE_9595buttonObjects4.length = 0;


return;

}

gdjs['Main_32MenuCode'] = gdjs.Main_32MenuCode;
